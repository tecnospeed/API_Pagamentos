﻿
namespace Demo_Pagamentos
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.label9 = new System.Windows.Forms.Label();
            this.rdambiente = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.edttokensh = new System.Windows.Forms.TextBox();
            this.edtcnpjsh = new System.Windows.Forms.TextBox();
            this.edtpayercpfcnpj = new System.Windows.Forms.TextBox();
            this.mmosaida = new System.Windows.Forms.TextBox();
            this.mmoentrada = new System.Windows.Forms.TextBox();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.btnconsultarextratobancario = new System.Windows.Forms.Button();
            this.button22 = new System.Windows.Forms.Button();
            this.btnenviarextratobancario = new System.Windows.Forms.Button();
            this.button28 = new System.Windows.Forms.Button();
            this.tabconciextratos = new System.Windows.Forms.TabPage();
            this.btnatualizarnotificacao = new System.Windows.Forms.Button();
            this.button18 = new System.Windows.Forms.Button();
            this.btnlistarnotificacao = new System.Windows.Forms.Button();
            this.button30 = new System.Windows.Forms.Button();
            this.btncriarnotificacao = new System.Windows.Forms.Button();
            this.button32 = new System.Windows.Forms.Button();
            this.tabpagnotificacao = new System.Windows.Forms.TabPage();
            this.btnconsultarbilhetagem = new System.Windows.Forms.Button();
            this.button12 = new System.Windows.Forms.Button();
            this.btnconsultarcomprovantedepagamento = new System.Windows.Forms.Button();
            this.button20 = new System.Windows.Forms.Button();
            this.btnsolicitarcomprovantedepagamento = new System.Windows.Forms.Button();
            this.button24 = new System.Windows.Forms.Button();
            this.tabpagtaxas = new System.Windows.Forms.TabPage();
            this.btnconsultararquivoderetorno = new System.Windows.Forms.Button();
            this.button16 = new System.Windows.Forms.Button();
            this.btnenviararquivoderetorno = new System.Windows.Forms.Button();
            this.button21 = new System.Windows.Forms.Button();
            this.btnconsultarpagador = new System.Windows.Forms.Button();
            this.button10 = new System.Windows.Forms.Button();
            this.btngerarremessa = new System.Windows.Forms.Button();
            this.button14 = new System.Windows.Forms.Button();
            this.tabpaggerais = new System.Windows.Forms.TabPage();
            this.label25 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.btnsalários = new System.Windows.Forms.Button();
            this.button25 = new System.Windows.Forms.Button();
            this.btntransferênciabancaria = new System.Windows.Forms.Button();
            this.button27 = new System.Windows.Forms.Button();
            this.btntitulosconcessionariasetributos = new System.Windows.Forms.Button();
            this.button29 = new System.Windows.Forms.Button();
            this.btndarf = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.btndpvat = new System.Windows.Forms.Button();
            this.button11 = new System.Windows.Forms.Button();
            this.btnipva = new System.Windows.Forms.Button();
            this.button13 = new System.Windows.Forms.Button();
            this.btngare = new System.Windows.Forms.Button();
            this.button23 = new System.Windows.Forms.Button();
            this.btnconsultadepagamamentos = new System.Windows.Forms.Button();
            this.button19 = new System.Windows.Forms.Button();
            this.btndiversos = new System.Windows.Forms.Button();
            this.button17 = new System.Windows.Forms.Button();
            this.btngps = new System.Windows.Forms.Button();
            this.button15 = new System.Windows.Forms.Button();
            this.tabcontas = new System.Windows.Forms.TabPage();
            this.btnalterandocontas = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.btnconsultarconta = new System.Windows.Forms.Button();
            this.jsonexemploconsultarconta = new System.Windows.Forms.Button();
            this.btncriarconta = new System.Windows.Forms.Button();
            this.jsonexemplocriarconta = new System.Windows.Forms.Button();
            this.tabpagadores = new System.Windows.Forms.TabPage();
            this.btnatualizardadosdopagador = new System.Windows.Forms.Button();
            this.jsonexemploatualizardadosdopagador = new System.Windows.Forms.Button();
            this.btnconsultapagador = new System.Windows.Forms.Button();
            this.jsonexemploconsultapagador = new System.Windows.Forms.Button();
            this.btncadastropagador = new System.Windows.Forms.Button();
            this.jsonexemplocadastropagador = new System.Windows.Forms.Button();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.mmoajuda = new System.Windows.Forms.TextBox();
            this.label41 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.tabPage1.SuspendLayout();
            this.tabconciextratos.SuspendLayout();
            this.tabpagnotificacao.SuspendLayout();
            this.tabpagtaxas.SuspendLayout();
            this.tabpaggerais.SuspendLayout();
            this.tabcontas.SuspendLayout();
            this.tabpagadores.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.ForeColor = System.Drawing.SystemColors.Window;
            this.label9.Location = new System.Drawing.Point(14, 20);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(91, 20);
            this.label9.TabIndex = 71;
            this.label9.Text = "AMBIENTE";
            // 
            // rdambiente
            // 
            this.rdambiente.FormattingEnabled = true;
            this.rdambiente.Items.AddRange(new object[] {
            "homologação",
            "produção"});
            this.rdambiente.Location = new System.Drawing.Point(170, 15);
            this.rdambiente.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.rdambiente.Name = "rdambiente";
            this.rdambiente.Size = new System.Drawing.Size(544, 28);
            this.rdambiente.TabIndex = 70;
            this.rdambiente.SelectedIndexChanged += new System.EventHandler(this.rdambiente_SelectedIndexChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.ForeColor = System.Drawing.SystemColors.Window;
            this.label3.Location = new System.Drawing.Point(14, 142);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(143, 20);
            this.label3.TabIndex = 65;
            this.label3.Text = "PAYER CPF CNPJ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.ForeColor = System.Drawing.SystemColors.Window;
            this.label2.Location = new System.Drawing.Point(14, 102);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(89, 20);
            this.label2.TabIndex = 64;
            this.label2.Text = "TOKEN SH";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.SystemColors.Window;
            this.label1.Location = new System.Drawing.Point(14, 62);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(76, 20);
            this.label1.TabIndex = 63;
            this.label1.Text = "CNPJ SH";
            // 
            // edttokensh
            // 
            this.edttokensh.Location = new System.Drawing.Point(170, 97);
            this.edttokensh.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.edttokensh.Name = "edttokensh";
            this.edttokensh.Size = new System.Drawing.Size(544, 26);
            this.edttokensh.TabIndex = 62;
            this.edttokensh.Text = "CdEZhJcQJS9rRdkLnx2Kl67GhAeBx89X2hzgVQ8i";
            this.edttokensh.TextChanged += new System.EventHandler(this.edttokensh_TextChanged);
            // 
            // edtcnpjsh
            // 
            this.edtcnpjsh.Location = new System.Drawing.Point(170, 57);
            this.edtcnpjsh.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.edtcnpjsh.Name = "edtcnpjsh";
            this.edtcnpjsh.Size = new System.Drawing.Size(544, 26);
            this.edtcnpjsh.TabIndex = 61;
            this.edtcnpjsh.Text = "01001001000113";
            this.edtcnpjsh.TextChanged += new System.EventHandler(this.edtcnpjsh_TextChanged);
            // 
            // edtpayercpfcnpj
            // 
            this.edtpayercpfcnpj.Location = new System.Drawing.Point(170, 137);
            this.edtpayercpfcnpj.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.edtpayercpfcnpj.Name = "edtpayercpfcnpj";
            this.edtpayercpfcnpj.Size = new System.Drawing.Size(544, 26);
            this.edtpayercpfcnpj.TabIndex = 60;
            this.edtpayercpfcnpj.Text = "01001001000113";
            this.edtpayercpfcnpj.TextChanged += new System.EventHandler(this.edtcnpjusuario_TextChanged);
            // 
            // mmosaida
            // 
            this.mmosaida.Location = new System.Drawing.Point(1274, 567);
            this.mmosaida.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.mmosaida.Multiline = true;
            this.mmosaida.Name = "mmosaida";
            this.mmosaida.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.mmosaida.Size = new System.Drawing.Size(894, 498);
            this.mmosaida.TabIndex = 77;
            // 
            // mmoentrada
            // 
            this.mmoentrada.BackColor = System.Drawing.SystemColors.Window;
            this.mmoentrada.Location = new System.Drawing.Point(1274, 32);
            this.mmoentrada.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.mmoentrada.Multiline = true;
            this.mmoentrada.Name = "mmoentrada";
            this.mmoentrada.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.mmoentrada.Size = new System.Drawing.Size(894, 507);
            this.mmoentrada.TabIndex = 76;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.btnconsultarextratobancario);
            this.tabPage1.Controls.Add(this.button22);
            this.tabPage1.Controls.Add(this.btnenviarextratobancario);
            this.tabPage1.Controls.Add(this.button28);
            this.tabPage1.Location = new System.Drawing.Point(4, 29);
            this.tabPage1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.tabPage1.Size = new System.Drawing.Size(696, 581);
            this.tabPage1.TabIndex = 6;
            this.tabPage1.Text = "EXTRATO";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // btnconsultarextratobancario
            // 
            this.btnconsultarextratobancario.Location = new System.Drawing.Point(168, 223);
            this.btnconsultarextratobancario.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnconsultarextratobancario.Name = "btnconsultarextratobancario";
            this.btnconsultarextratobancario.Size = new System.Drawing.Size(393, 35);
            this.btnconsultarextratobancario.TabIndex = 21;
            this.btnconsultarextratobancario.Text = "CONSULTAR EXTRATO BANCÁRIO";
            this.btnconsultarextratobancario.UseVisualStyleBackColor = true;
            this.btnconsultarextratobancario.Click += new System.EventHandler(this.btnconsultarextratobancario_Click);
            // 
            // button22
            // 
            this.button22.Location = new System.Drawing.Point(12, 223);
            this.button22.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.button22.Name = "button22";
            this.button22.Size = new System.Drawing.Size(147, 35);
            this.button22.TabIndex = 20;
            this.button22.Text = "JSON EXEMPLO";
            this.button22.UseVisualStyleBackColor = true;
            this.button22.Click += new System.EventHandler(this.button22_Click);
            // 
            // btnenviarextratobancario
            // 
            this.btnenviarextratobancario.Location = new System.Drawing.Point(168, 109);
            this.btnenviarextratobancario.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnenviarextratobancario.Name = "btnenviarextratobancario";
            this.btnenviarextratobancario.Size = new System.Drawing.Size(393, 35);
            this.btnenviarextratobancario.TabIndex = 19;
            this.btnenviarextratobancario.Text = "ENVIAR EXTRATO BANCÁRIO";
            this.btnenviarextratobancario.UseVisualStyleBackColor = true;
            this.btnenviarextratobancario.Click += new System.EventHandler(this.btnenviarextratobancario_Click);
            // 
            // button28
            // 
            this.button28.Location = new System.Drawing.Point(12, 109);
            this.button28.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.button28.Name = "button28";
            this.button28.Size = new System.Drawing.Size(147, 35);
            this.button28.TabIndex = 18;
            this.button28.Text = "JSON EXEMPLO";
            this.button28.UseVisualStyleBackColor = true;
            this.button28.Click += new System.EventHandler(this.button28_Click_2);
            // 
            // tabconciextratos
            // 
            this.tabconciextratos.Controls.Add(this.btnatualizarnotificacao);
            this.tabconciextratos.Controls.Add(this.button18);
            this.tabconciextratos.Controls.Add(this.btnlistarnotificacao);
            this.tabconciextratos.Controls.Add(this.button30);
            this.tabconciextratos.Controls.Add(this.btncriarnotificacao);
            this.tabconciextratos.Controls.Add(this.button32);
            this.tabconciextratos.Location = new System.Drawing.Point(4, 29);
            this.tabconciextratos.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.tabconciextratos.Name = "tabconciextratos";
            this.tabconciextratos.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.tabconciextratos.Size = new System.Drawing.Size(696, 581);
            this.tabconciextratos.TabIndex = 5;
            this.tabconciextratos.Text = "NOTIFICAÇÃO";
            this.tabconciextratos.UseVisualStyleBackColor = true;
            // 
            // btnatualizarnotificacao
            // 
            this.btnatualizarnotificacao.Location = new System.Drawing.Point(168, 342);
            this.btnatualizarnotificacao.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnatualizarnotificacao.Name = "btnatualizarnotificacao";
            this.btnatualizarnotificacao.Size = new System.Drawing.Size(380, 35);
            this.btnatualizarnotificacao.TabIndex = 23;
            this.btnatualizarnotificacao.Text = "ATUALIZAR NOTIFICAÇÃO";
            this.btnatualizarnotificacao.UseVisualStyleBackColor = true;
            this.btnatualizarnotificacao.Click += new System.EventHandler(this.btnatualizarnotificacao_Click);
            // 
            // button18
            // 
            this.button18.Location = new System.Drawing.Point(12, 342);
            this.button18.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.button18.Name = "button18";
            this.button18.Size = new System.Drawing.Size(147, 35);
            this.button18.TabIndex = 22;
            this.button18.Text = "JSON EXEMPLO";
            this.button18.UseVisualStyleBackColor = true;
            this.button18.Click += new System.EventHandler(this.button18_Click);
            // 
            // btnlistarnotificacao
            // 
            this.btnlistarnotificacao.Location = new System.Drawing.Point(168, 223);
            this.btnlistarnotificacao.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnlistarnotificacao.Name = "btnlistarnotificacao";
            this.btnlistarnotificacao.Size = new System.Drawing.Size(380, 35);
            this.btnlistarnotificacao.TabIndex = 19;
            this.btnlistarnotificacao.Text = "LISTAR NOTIFICAÇÕES";
            this.btnlistarnotificacao.UseVisualStyleBackColor = true;
            this.btnlistarnotificacao.Click += new System.EventHandler(this.button28_Click_1);
            // 
            // button30
            // 
            this.button30.Location = new System.Drawing.Point(12, 223);
            this.button30.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.button30.Name = "button30";
            this.button30.Size = new System.Drawing.Size(147, 35);
            this.button30.TabIndex = 18;
            this.button30.Text = "JSON EXEMPLO";
            this.button30.UseVisualStyleBackColor = true;
            this.button30.Click += new System.EventHandler(this.button30_Click);
            // 
            // btncriarnotificacao
            // 
            this.btncriarnotificacao.Location = new System.Drawing.Point(168, 109);
            this.btncriarnotificacao.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btncriarnotificacao.Name = "btncriarnotificacao";
            this.btncriarnotificacao.Size = new System.Drawing.Size(380, 35);
            this.btncriarnotificacao.TabIndex = 17;
            this.btncriarnotificacao.Text = "CRIAR NOTIFICAÇÃO";
            this.btncriarnotificacao.UseVisualStyleBackColor = true;
            this.btncriarnotificacao.Click += new System.EventHandler(this.button31_Click);
            // 
            // button32
            // 
            this.button32.Location = new System.Drawing.Point(12, 109);
            this.button32.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.button32.Name = "button32";
            this.button32.Size = new System.Drawing.Size(147, 35);
            this.button32.TabIndex = 16;
            this.button32.Text = "JSON EXEMPLO";
            this.button32.UseVisualStyleBackColor = true;
            this.button32.Click += new System.EventHandler(this.button32_Click);
            // 
            // tabpagnotificacao
            // 
            this.tabpagnotificacao.Controls.Add(this.btnconsultarbilhetagem);
            this.tabpagnotificacao.Controls.Add(this.button12);
            this.tabpagnotificacao.Controls.Add(this.btnconsultarcomprovantedepagamento);
            this.tabpagnotificacao.Controls.Add(this.button20);
            this.tabpagnotificacao.Controls.Add(this.btnsolicitarcomprovantedepagamento);
            this.tabpagnotificacao.Controls.Add(this.button24);
            this.tabpagnotificacao.Location = new System.Drawing.Point(4, 29);
            this.tabpagnotificacao.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.tabpagnotificacao.Name = "tabpagnotificacao";
            this.tabpagnotificacao.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.tabpagnotificacao.Size = new System.Drawing.Size(696, 581);
            this.tabpagnotificacao.TabIndex = 4;
            this.tabpagnotificacao.Text = "COMPROVANTE/BILHETAGEM";
            this.tabpagnotificacao.UseVisualStyleBackColor = true;
            this.tabpagnotificacao.Click += new System.EventHandler(this.tabpagnotificacao_Click);
            // 
            // btnconsultarbilhetagem
            // 
            this.btnconsultarbilhetagem.Location = new System.Drawing.Point(168, 342);
            this.btnconsultarbilhetagem.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnconsultarbilhetagem.Name = "btnconsultarbilhetagem";
            this.btnconsultarbilhetagem.Size = new System.Drawing.Size(393, 35);
            this.btnconsultarbilhetagem.TabIndex = 19;
            this.btnconsultarbilhetagem.Text = "CONSULTAR BILHETAGEM";
            this.btnconsultarbilhetagem.UseVisualStyleBackColor = true;
            this.btnconsultarbilhetagem.Click += new System.EventHandler(this.btnconsultarbilhetagem_Click);
            // 
            // button12
            // 
            this.button12.Location = new System.Drawing.Point(12, 342);
            this.button12.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(147, 35);
            this.button12.TabIndex = 18;
            this.button12.Text = "JSON EXEMPLO";
            this.button12.UseVisualStyleBackColor = true;
            this.button12.Click += new System.EventHandler(this.button12_Click);
            // 
            // btnconsultarcomprovantedepagamento
            // 
            this.btnconsultarcomprovantedepagamento.Location = new System.Drawing.Point(168, 223);
            this.btnconsultarcomprovantedepagamento.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnconsultarcomprovantedepagamento.Name = "btnconsultarcomprovantedepagamento";
            this.btnconsultarcomprovantedepagamento.Size = new System.Drawing.Size(393, 35);
            this.btnconsultarcomprovantedepagamento.TabIndex = 17;
            this.btnconsultarcomprovantedepagamento.Text = "CONSULTAR COMPROVANTE DE PAGAMENTO";
            this.btnconsultarcomprovantedepagamento.UseVisualStyleBackColor = true;
            this.btnconsultarcomprovantedepagamento.Click += new System.EventHandler(this.btnconsultarcomprovantedepagamento_Click);
            // 
            // button20
            // 
            this.button20.Location = new System.Drawing.Point(12, 223);
            this.button20.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.button20.Name = "button20";
            this.button20.Size = new System.Drawing.Size(147, 35);
            this.button20.TabIndex = 16;
            this.button20.Text = "JSON EXEMPLO";
            this.button20.UseVisualStyleBackColor = true;
            this.button20.Click += new System.EventHandler(this.button20_Click_2);
            // 
            // btnsolicitarcomprovantedepagamento
            // 
            this.btnsolicitarcomprovantedepagamento.Location = new System.Drawing.Point(168, 109);
            this.btnsolicitarcomprovantedepagamento.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnsolicitarcomprovantedepagamento.Name = "btnsolicitarcomprovantedepagamento";
            this.btnsolicitarcomprovantedepagamento.Size = new System.Drawing.Size(393, 35);
            this.btnsolicitarcomprovantedepagamento.TabIndex = 15;
            this.btnsolicitarcomprovantedepagamento.Text = "SOLICITAR COMPROVANTE DE PAGAMENTO";
            this.btnsolicitarcomprovantedepagamento.UseVisualStyleBackColor = true;
            this.btnsolicitarcomprovantedepagamento.Click += new System.EventHandler(this.btnsolicitarcomprovantedepagamento_Click);
            // 
            // button24
            // 
            this.button24.Location = new System.Drawing.Point(12, 109);
            this.button24.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.button24.Name = "button24";
            this.button24.Size = new System.Drawing.Size(147, 35);
            this.button24.TabIndex = 14;
            this.button24.Text = "JSON EXEMPLO";
            this.button24.UseVisualStyleBackColor = true;
            this.button24.Click += new System.EventHandler(this.button24_Click);
            // 
            // tabpagtaxas
            // 
            this.tabpagtaxas.Controls.Add(this.btnconsultararquivoderetorno);
            this.tabpagtaxas.Controls.Add(this.button16);
            this.tabpagtaxas.Controls.Add(this.btnenviararquivoderetorno);
            this.tabpagtaxas.Controls.Add(this.button21);
            this.tabpagtaxas.Controls.Add(this.btnconsultarpagador);
            this.tabpagtaxas.Controls.Add(this.button10);
            this.tabpagtaxas.Controls.Add(this.btngerarremessa);
            this.tabpagtaxas.Controls.Add(this.button14);
            this.tabpagtaxas.Location = new System.Drawing.Point(4, 29);
            this.tabpagtaxas.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.tabpagtaxas.Name = "tabpagtaxas";
            this.tabpagtaxas.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.tabpagtaxas.Size = new System.Drawing.Size(696, 797);
            this.tabpagtaxas.TabIndex = 3;
            this.tabpagtaxas.Text = "REMESSA/RETORNO";
            this.tabpagtaxas.UseVisualStyleBackColor = true;
            this.tabpagtaxas.Click += new System.EventHandler(this.tabpagtaxas_Click);
            // 
            // btnconsultararquivoderetorno
            // 
            this.btnconsultararquivoderetorno.Location = new System.Drawing.Point(168, 455);
            this.btnconsultararquivoderetorno.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnconsultararquivoderetorno.Name = "btnconsultararquivoderetorno";
            this.btnconsultararquivoderetorno.Size = new System.Drawing.Size(380, 35);
            this.btnconsultararquivoderetorno.TabIndex = 15;
            this.btnconsultararquivoderetorno.Text = "CONSULTAR ARQUIVO DE RETORNO";
            this.btnconsultararquivoderetorno.UseVisualStyleBackColor = true;
            this.btnconsultararquivoderetorno.Click += new System.EventHandler(this.button6_Click);
            // 
            // button16
            // 
            this.button16.Location = new System.Drawing.Point(12, 455);
            this.button16.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.button16.Name = "button16";
            this.button16.Size = new System.Drawing.Size(147, 35);
            this.button16.TabIndex = 14;
            this.button16.Text = "JSON EXEMPLO";
            this.button16.UseVisualStyleBackColor = true;
            this.button16.Click += new System.EventHandler(this.button16_Click);
            // 
            // btnenviararquivoderetorno
            // 
            this.btnenviararquivoderetorno.Location = new System.Drawing.Point(168, 342);
            this.btnenviararquivoderetorno.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnenviararquivoderetorno.Name = "btnenviararquivoderetorno";
            this.btnenviararquivoderetorno.Size = new System.Drawing.Size(380, 35);
            this.btnenviararquivoderetorno.TabIndex = 13;
            this.btnenviararquivoderetorno.Text = "ENVIAR ARQUIVO DE RETORNO";
            this.btnenviararquivoderetorno.UseVisualStyleBackColor = true;
            this.btnenviararquivoderetorno.Click += new System.EventHandler(this.button20_Click_1);
            // 
            // button21
            // 
            this.button21.Location = new System.Drawing.Point(12, 342);
            this.button21.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.button21.Name = "button21";
            this.button21.Size = new System.Drawing.Size(147, 35);
            this.button21.TabIndex = 12;
            this.button21.Text = "JSON EXEMPLO";
            this.button21.UseVisualStyleBackColor = true;
            this.button21.Click += new System.EventHandler(this.button21_Click);
            // 
            // btnconsultarpagador
            // 
            this.btnconsultarpagador.Location = new System.Drawing.Point(168, 223);
            this.btnconsultarpagador.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnconsultarpagador.Name = "btnconsultarpagador";
            this.btnconsultarpagador.Size = new System.Drawing.Size(380, 35);
            this.btnconsultarpagador.TabIndex = 7;
            this.btnconsultarpagador.Text = "CONSULTAR REMESSA";
            this.btnconsultarpagador.UseVisualStyleBackColor = true;
            this.btnconsultarpagador.Click += new System.EventHandler(this.btnconsultarpagador_Click);
            // 
            // button10
            // 
            this.button10.Location = new System.Drawing.Point(12, 223);
            this.button10.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(147, 35);
            this.button10.TabIndex = 6;
            this.button10.Text = "JSON EXEMPLO";
            this.button10.UseVisualStyleBackColor = true;
            this.button10.Click += new System.EventHandler(this.button10_Click_1);
            // 
            // btngerarremessa
            // 
            this.btngerarremessa.Location = new System.Drawing.Point(168, 109);
            this.btngerarremessa.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btngerarremessa.Name = "btngerarremessa";
            this.btngerarremessa.Size = new System.Drawing.Size(380, 35);
            this.btngerarremessa.TabIndex = 5;
            this.btngerarremessa.Text = "GERAR REMESSA";
            this.btngerarremessa.UseVisualStyleBackColor = true;
            this.btngerarremessa.Click += new System.EventHandler(this.btngerarremessa_Click);
            // 
            // button14
            // 
            this.button14.Location = new System.Drawing.Point(12, 109);
            this.button14.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(147, 35);
            this.button14.TabIndex = 4;
            this.button14.Text = "JSON EXEMPLO";
            this.button14.UseVisualStyleBackColor = true;
            this.button14.Click += new System.EventHandler(this.button14_Click);
            // 
            // tabpaggerais
            // 
            this.tabpaggerais.Controls.Add(this.label25);
            this.tabpaggerais.Controls.Add(this.label27);
            this.tabpaggerais.Controls.Add(this.label28);
            this.tabpaggerais.Controls.Add(this.label29);
            this.tabpaggerais.Controls.Add(this.label30);
            this.tabpaggerais.Controls.Add(this.label31);
            this.tabpaggerais.Controls.Add(this.label32);
            this.tabpaggerais.Controls.Add(this.label33);
            this.tabpaggerais.Controls.Add(this.label34);
            this.tabpaggerais.Controls.Add(this.label35);
            this.tabpaggerais.Controls.Add(this.label36);
            this.tabpaggerais.Controls.Add(this.label37);
            this.tabpaggerais.Controls.Add(this.label38);
            this.tabpaggerais.Controls.Add(this.label39);
            this.tabpaggerais.Controls.Add(this.label40);
            this.tabpaggerais.Controls.Add(this.label24);
            this.tabpaggerais.Controls.Add(this.label23);
            this.tabpaggerais.Controls.Add(this.label22);
            this.tabpaggerais.Controls.Add(this.label21);
            this.tabpaggerais.Controls.Add(this.label20);
            this.tabpaggerais.Controls.Add(this.label19);
            this.tabpaggerais.Controls.Add(this.label18);
            this.tabpaggerais.Controls.Add(this.label17);
            this.tabpaggerais.Controls.Add(this.label16);
            this.tabpaggerais.Controls.Add(this.label15);
            this.tabpaggerais.Controls.Add(this.label14);
            this.tabpaggerais.Controls.Add(this.label13);
            this.tabpaggerais.Controls.Add(this.label12);
            this.tabpaggerais.Controls.Add(this.label11);
            this.tabpaggerais.Controls.Add(this.label10);
            this.tabpaggerais.Controls.Add(this.label8);
            this.tabpaggerais.Controls.Add(this.label7);
            this.tabpaggerais.Controls.Add(this.label6);
            this.tabpaggerais.Controls.Add(this.label5);
            this.tabpaggerais.Controls.Add(this.label4);
            this.tabpaggerais.Controls.Add(this.btnsalários);
            this.tabpaggerais.Controls.Add(this.button25);
            this.tabpaggerais.Controls.Add(this.btntransferênciabancaria);
            this.tabpaggerais.Controls.Add(this.button27);
            this.tabpaggerais.Controls.Add(this.btntitulosconcessionariasetributos);
            this.tabpaggerais.Controls.Add(this.button29);
            this.tabpaggerais.Controls.Add(this.btndarf);
            this.tabpaggerais.Controls.Add(this.button9);
            this.tabpaggerais.Controls.Add(this.btndpvat);
            this.tabpaggerais.Controls.Add(this.button11);
            this.tabpaggerais.Controls.Add(this.btnipva);
            this.tabpaggerais.Controls.Add(this.button13);
            this.tabpaggerais.Controls.Add(this.btngare);
            this.tabpaggerais.Controls.Add(this.button23);
            this.tabpaggerais.Controls.Add(this.btnconsultadepagamamentos);
            this.tabpaggerais.Controls.Add(this.button19);
            this.tabpaggerais.Controls.Add(this.btndiversos);
            this.tabpaggerais.Controls.Add(this.button17);
            this.tabpaggerais.Controls.Add(this.btngps);
            this.tabpaggerais.Controls.Add(this.button15);
            this.tabpaggerais.Location = new System.Drawing.Point(4, 29);
            this.tabpaggerais.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.tabpaggerais.Name = "tabpaggerais";
            this.tabpaggerais.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.tabpaggerais.Size = new System.Drawing.Size(696, 797);
            this.tabpaggerais.TabIndex = 2;
            this.tabpaggerais.Text = "PAGAMENTO";
            this.tabpaggerais.UseVisualStyleBackColor = true;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(654, 517);
            this.label25.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(20, 20);
            this.label25.TabIndex = 73;
            this.label25.Text = "S";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(654, 495);
            this.label27.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(20, 20);
            this.label27.TabIndex = 71;
            this.label27.Text = "A";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(654, 455);
            this.label28.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(20, 20);
            this.label28.TabIndex = 70;
            this.label28.Text = "A";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(654, 475);
            this.label29.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(20, 20);
            this.label29.TabIndex = 69;
            this.label29.Text = "X";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(654, 435);
            this.label30.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(18, 20);
            this.label30.TabIndex = 68;
            this.label30.Text = "T";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(621, 557);
            this.label31.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(20, 20);
            this.label31.TabIndex = 67;
            this.label31.Text = "S";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(621, 537);
            this.label32.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(21, 20);
            this.label32.TabIndex = 66;
            this.label32.Text = "O";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(621, 517);
            this.label33.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(18, 20);
            this.label33.TabIndex = 65;
            this.label33.Text = "T";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(621, 495);
            this.label34.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(20, 20);
            this.label34.TabIndex = 64;
            this.label34.Text = "N";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(621, 475);
            this.label35.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(20, 20);
            this.label35.TabIndex = 63;
            this.label35.Text = "E";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(621, 455);
            this.label36.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(22, 20);
            this.label36.TabIndex = 62;
            this.label36.Text = "M";
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(621, 431);
            this.label37.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(20, 20);
            this.label37.TabIndex = 61;
            this.label37.Text = "A";
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Location = new System.Drawing.Point(621, 411);
            this.label38.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(22, 20);
            this.label38.TabIndex = 60;
            this.label38.Text = "G";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Location = new System.Drawing.Point(621, 391);
            this.label39.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(20, 20);
            this.label39.TabIndex = 59;
            this.label39.Text = "A";
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Location = new System.Drawing.Point(621, 371);
            this.label40.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(19, 20);
            this.label40.TabIndex = 58;
            this.label40.Text = "P";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(303, 665);
            this.label24.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(261, 20);
            this.label24.TabIndex = 57;
            this.label24.Text = "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(303, 331);
            this.label23.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(261, 20);
            this.label23.TabIndex = 56;
            this.label23.Text = "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(303, 5);
            this.label22.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(261, 20);
            this.label22.TabIndex = 55;
            this.label22.Text = "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(303, 294);
            this.label21.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(261, 20);
            this.label21.TabIndex = 54;
            this.label21.Text = "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛";
            this.label21.Click += new System.EventHandler(this.label21_Click);
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(652, 215);
            this.label20.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(20, 20);
            this.label20.TabIndex = 53;
            this.label20.Text = "S";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(652, 195);
            this.label19.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(18, 20);
            this.label19.TabIndex = 52;
            this.label19.Text = " I";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(652, 171);
            this.label18.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(20, 20);
            this.label18.TabIndex = 51;
            this.label18.Text = "A";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(652, 131);
            this.label17.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(20, 20);
            this.label17.TabIndex = 50;
            this.label17.Text = "E";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(652, 151);
            this.label16.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(21, 20);
            this.label16.TabIndex = 49;
            this.label16.Text = "R";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(652, 111);
            this.label15.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(22, 20);
            this.label15.TabIndex = 48;
            this.label15.Text = "G";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(620, 232);
            this.label14.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(20, 20);
            this.label14.TabIndex = 47;
            this.label14.Text = "S";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(620, 212);
            this.label13.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(21, 20);
            this.label13.TabIndex = 46;
            this.label13.Text = "O";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(620, 192);
            this.label12.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(18, 20);
            this.label12.TabIndex = 45;
            this.label12.Text = "T";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(620, 171);
            this.label11.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(20, 20);
            this.label11.TabIndex = 44;
            this.label11.Text = "N";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(620, 151);
            this.label10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(20, 20);
            this.label10.TabIndex = 43;
            this.label10.Text = "E";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(620, 131);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(22, 20);
            this.label8.TabIndex = 42;
            this.label8.Text = "M";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(620, 106);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(20, 20);
            this.label7.TabIndex = 41;
            this.label7.Text = "A";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(620, 86);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(22, 20);
            this.label6.TabIndex = 40;
            this.label6.Text = "G";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(620, 66);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(20, 20);
            this.label5.TabIndex = 39;
            this.label5.Text = "A";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(620, 46);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(19, 20);
            this.label4.TabIndex = 38;
            this.label4.Text = "P";
            // 
            // btnsalários
            // 
            this.btnsalários.Location = new System.Drawing.Point(168, 188);
            this.btnsalários.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnsalários.Name = "btnsalários";
            this.btnsalários.Size = new System.Drawing.Size(380, 35);
            this.btnsalários.TabIndex = 37;
            this.btnsalários.Text = "SALÁRIOS";
            this.btnsalários.UseVisualStyleBackColor = true;
            this.btnsalários.Click += new System.EventHandler(this.btnsalários_Click);
            // 
            // button25
            // 
            this.button25.Location = new System.Drawing.Point(12, 188);
            this.button25.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.button25.Name = "button25";
            this.button25.Size = new System.Drawing.Size(147, 35);
            this.button25.TabIndex = 36;
            this.button25.Text = "JSON EXEMPLO";
            this.button25.UseVisualStyleBackColor = true;
            this.button25.Click += new System.EventHandler(this.button25_Click);
            // 
            // btntransferênciabancaria
            // 
            this.btntransferênciabancaria.Location = new System.Drawing.Point(168, 118);
            this.btntransferênciabancaria.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btntransferênciabancaria.Name = "btntransferênciabancaria";
            this.btntransferênciabancaria.Size = new System.Drawing.Size(380, 35);
            this.btntransferênciabancaria.TabIndex = 35;
            this.btntransferênciabancaria.Text = "TRANSFERÊNCIA BANCÁRIA";
            this.btntransferênciabancaria.UseVisualStyleBackColor = true;
            this.btntransferênciabancaria.Click += new System.EventHandler(this.button26_Click);
            // 
            // button27
            // 
            this.button27.Location = new System.Drawing.Point(12, 118);
            this.button27.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.button27.Name = "button27";
            this.button27.Size = new System.Drawing.Size(147, 35);
            this.button27.TabIndex = 34;
            this.button27.Text = "JSON EXEMPLO";
            this.button27.UseVisualStyleBackColor = true;
            this.button27.Click += new System.EventHandler(this.button27_Click);
            // 
            // btntitulosconcessionariasetributos
            // 
            this.btntitulosconcessionariasetributos.Location = new System.Drawing.Point(168, 49);
            this.btntitulosconcessionariasetributos.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btntitulosconcessionariasetributos.Name = "btntitulosconcessionariasetributos";
            this.btntitulosconcessionariasetributos.Size = new System.Drawing.Size(380, 35);
            this.btntitulosconcessionariasetributos.TabIndex = 33;
            this.btntitulosconcessionariasetributos.Text = "TÍTULOS,CONCESSIONÁRIAS E TRIBUTOS";
            this.btntitulosconcessionariasetributos.UseVisualStyleBackColor = true;
            this.btntitulosconcessionariasetributos.Click += new System.EventHandler(this.button28_Click);
            // 
            // button29
            // 
            this.button29.Location = new System.Drawing.Point(12, 49);
            this.button29.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.button29.Name = "button29";
            this.button29.Size = new System.Drawing.Size(147, 35);
            this.button29.TabIndex = 32;
            this.button29.Text = "JSON EXEMPLO";
            this.button29.UseVisualStyleBackColor = true;
            this.button29.Click += new System.EventHandler(this.button29_Click);
            // 
            // btndarf
            // 
            this.btndarf.Location = new System.Drawing.Point(168, 555);
            this.btndarf.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btndarf.Name = "btndarf";
            this.btndarf.Size = new System.Drawing.Size(380, 35);
            this.btndarf.TabIndex = 31;
            this.btndarf.Text = "DARF";
            this.btndarf.UseVisualStyleBackColor = true;
            this.btndarf.Click += new System.EventHandler(this.btndarf_Click);
            // 
            // button9
            // 
            this.button9.Location = new System.Drawing.Point(12, 555);
            this.button9.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(147, 35);
            this.button9.TabIndex = 30;
            this.button9.Text = "JSON EXEMPLO";
            this.button9.UseVisualStyleBackColor = true;
            this.button9.Click += new System.EventHandler(this.button9_Click);
            // 
            // btndpvat
            // 
            this.btndpvat.Location = new System.Drawing.Point(168, 480);
            this.btndpvat.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btndpvat.Name = "btndpvat";
            this.btndpvat.Size = new System.Drawing.Size(380, 35);
            this.btndpvat.TabIndex = 29;
            this.btndpvat.Text = "DPVAT";
            this.btndpvat.UseVisualStyleBackColor = true;
            this.btndpvat.Click += new System.EventHandler(this.button10_Click);
            // 
            // button11
            // 
            this.button11.Location = new System.Drawing.Point(12, 480);
            this.button11.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(147, 35);
            this.button11.TabIndex = 28;
            this.button11.Text = "JSON EXEMPLO";
            this.button11.UseVisualStyleBackColor = true;
            this.button11.Click += new System.EventHandler(this.button11_Click);
            // 
            // btnipva
            // 
            this.btnipva.Location = new System.Drawing.Point(168, 420);
            this.btnipva.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnipva.Name = "btnipva";
            this.btnipva.Size = new System.Drawing.Size(380, 35);
            this.btnipva.TabIndex = 27;
            this.btnipva.Text = "IPVA";
            this.btnipva.UseVisualStyleBackColor = true;
            this.btnipva.Click += new System.EventHandler(this.btnipva_Click);
            // 
            // button13
            // 
            this.button13.Location = new System.Drawing.Point(12, 420);
            this.button13.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(147, 35);
            this.button13.TabIndex = 26;
            this.button13.Text = "JSON EXEMPLO";
            this.button13.UseVisualStyleBackColor = true;
            this.button13.Click += new System.EventHandler(this.button13_Click);
            // 
            // btngare
            // 
            this.btngare.Location = new System.Drawing.Point(168, 355);
            this.btngare.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btngare.Name = "btngare";
            this.btngare.Size = new System.Drawing.Size(380, 35);
            this.btngare.TabIndex = 25;
            this.btngare.Text = "GARE";
            this.btngare.UseVisualStyleBackColor = true;
            this.btngare.Click += new System.EventHandler(this.btngare_Click);
            // 
            // button23
            // 
            this.button23.Location = new System.Drawing.Point(12, 355);
            this.button23.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.button23.Name = "button23";
            this.button23.Size = new System.Drawing.Size(147, 35);
            this.button23.TabIndex = 24;
            this.button23.Text = "JSON EXEMPLO";
            this.button23.UseVisualStyleBackColor = true;
            this.button23.Click += new System.EventHandler(this.button23_Click);
            // 
            // btnconsultadepagamamentos
            // 
            this.btnconsultadepagamamentos.Location = new System.Drawing.Point(168, 694);
            this.btnconsultadepagamamentos.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnconsultadepagamamentos.Name = "btnconsultadepagamamentos";
            this.btnconsultadepagamamentos.Size = new System.Drawing.Size(380, 35);
            this.btnconsultadepagamamentos.TabIndex = 21;
            this.btnconsultadepagamamentos.Text = "CONSULTA DE PAGAMENTOS";
            this.btnconsultadepagamamentos.UseVisualStyleBackColor = true;
            this.btnconsultadepagamamentos.Click += new System.EventHandler(this.btnconsultadepagamamentos_Click);
            // 
            // button19
            // 
            this.button19.Location = new System.Drawing.Point(12, 694);
            this.button19.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.button19.Name = "button19";
            this.button19.Size = new System.Drawing.Size(147, 35);
            this.button19.TabIndex = 20;
            this.button19.Text = "JSON EXEMPLO";
            this.button19.UseVisualStyleBackColor = true;
            this.button19.Click += new System.EventHandler(this.button19_Click);
            // 
            // btndiversos
            // 
            this.btndiversos.Location = new System.Drawing.Point(168, 254);
            this.btndiversos.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btndiversos.Name = "btndiversos";
            this.btndiversos.Size = new System.Drawing.Size(380, 35);
            this.btndiversos.TabIndex = 19;
            this.btndiversos.Text = "DIVERSOS";
            this.btndiversos.UseVisualStyleBackColor = true;
            this.btndiversos.Click += new System.EventHandler(this.btndiversos_Click);
            // 
            // button17
            // 
            this.button17.Location = new System.Drawing.Point(12, 254);
            this.button17.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.button17.Name = "button17";
            this.button17.Size = new System.Drawing.Size(147, 35);
            this.button17.TabIndex = 18;
            this.button17.Text = "JSON EXEMPLO";
            this.button17.UseVisualStyleBackColor = true;
            this.button17.Click += new System.EventHandler(this.button17_Click);
            // 
            // btngps
            // 
            this.btngps.Location = new System.Drawing.Point(168, 625);
            this.btngps.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btngps.Name = "btngps";
            this.btngps.Size = new System.Drawing.Size(380, 35);
            this.btngps.TabIndex = 17;
            this.btngps.Text = "GPS";
            this.btngps.UseVisualStyleBackColor = true;
            this.btngps.Click += new System.EventHandler(this.btngps_Click);
            // 
            // button15
            // 
            this.button15.Location = new System.Drawing.Point(12, 625);
            this.button15.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.button15.Name = "button15";
            this.button15.Size = new System.Drawing.Size(147, 35);
            this.button15.TabIndex = 16;
            this.button15.Text = "JSON EXEMPLO";
            this.button15.UseVisualStyleBackColor = true;
            this.button15.Click += new System.EventHandler(this.button15_Click);
            // 
            // tabcontas
            // 
            this.tabcontas.Controls.Add(this.btnalterandocontas);
            this.tabcontas.Controls.Add(this.button7);
            this.tabcontas.Controls.Add(this.btnconsultarconta);
            this.tabcontas.Controls.Add(this.jsonexemploconsultarconta);
            this.tabcontas.Controls.Add(this.btncriarconta);
            this.tabcontas.Controls.Add(this.jsonexemplocriarconta);
            this.tabcontas.Location = new System.Drawing.Point(4, 29);
            this.tabcontas.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.tabcontas.Name = "tabcontas";
            this.tabcontas.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.tabcontas.Size = new System.Drawing.Size(696, 797);
            this.tabcontas.TabIndex = 1;
            this.tabcontas.Text = "CONTAS";
            this.tabcontas.UseVisualStyleBackColor = true;
            this.tabcontas.Click += new System.EventHandler(this.tabcontas_Click);
            // 
            // btnalterandocontas
            // 
            this.btnalterandocontas.Location = new System.Drawing.Point(168, 342);
            this.btnalterandocontas.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnalterandocontas.Name = "btnalterandocontas";
            this.btnalterandocontas.Size = new System.Drawing.Size(380, 35);
            this.btnalterandocontas.TabIndex = 9;
            this.btnalterandocontas.Text = "ALTERANDO CONTAS";
            this.btnalterandocontas.UseVisualStyleBackColor = true;
            this.btnalterandocontas.Click += new System.EventHandler(this.btnalterandocontas_Click);
            // 
            // button7
            // 
            this.button7.Location = new System.Drawing.Point(12, 342);
            this.button7.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(147, 35);
            this.button7.TabIndex = 8;
            this.button7.Text = "JSON EXEMPLO";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // btnconsultarconta
            // 
            this.btnconsultarconta.Location = new System.Drawing.Point(168, 223);
            this.btnconsultarconta.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnconsultarconta.Name = "btnconsultarconta";
            this.btnconsultarconta.Size = new System.Drawing.Size(380, 35);
            this.btnconsultarconta.TabIndex = 7;
            this.btnconsultarconta.Text = "CONSULTAR CONTAS";
            this.btnconsultarconta.UseVisualStyleBackColor = true;
            this.btnconsultarconta.Click += new System.EventHandler(this.btnconsultarconta_Click);
            // 
            // jsonexemploconsultarconta
            // 
            this.jsonexemploconsultarconta.Location = new System.Drawing.Point(12, 223);
            this.jsonexemploconsultarconta.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.jsonexemploconsultarconta.Name = "jsonexemploconsultarconta";
            this.jsonexemploconsultarconta.Size = new System.Drawing.Size(147, 35);
            this.jsonexemploconsultarconta.TabIndex = 6;
            this.jsonexemploconsultarconta.Text = "JSON EXEMPLO";
            this.jsonexemploconsultarconta.UseVisualStyleBackColor = true;
            this.jsonexemploconsultarconta.Click += new System.EventHandler(this.jsonexemploconsultarconta_Click);
            // 
            // btncriarconta
            // 
            this.btncriarconta.Location = new System.Drawing.Point(168, 109);
            this.btncriarconta.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btncriarconta.Name = "btncriarconta";
            this.btncriarconta.Size = new System.Drawing.Size(380, 35);
            this.btncriarconta.TabIndex = 5;
            this.btncriarconta.Text = "CRIAR CONTA";
            this.btncriarconta.UseVisualStyleBackColor = true;
            this.btncriarconta.Click += new System.EventHandler(this.button8_Click);
            // 
            // jsonexemplocriarconta
            // 
            this.jsonexemplocriarconta.Location = new System.Drawing.Point(12, 109);
            this.jsonexemplocriarconta.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.jsonexemplocriarconta.Name = "jsonexemplocriarconta";
            this.jsonexemplocriarconta.Size = new System.Drawing.Size(147, 35);
            this.jsonexemplocriarconta.TabIndex = 4;
            this.jsonexemplocriarconta.Text = "JSON EXEMPLO";
            this.jsonexemplocriarconta.UseVisualStyleBackColor = true;
            this.jsonexemplocriarconta.Click += new System.EventHandler(this.jsonexemplocriarconta_Click);
            // 
            // tabpagadores
            // 
            this.tabpagadores.Controls.Add(this.btnatualizardadosdopagador);
            this.tabpagadores.Controls.Add(this.jsonexemploatualizardadosdopagador);
            this.tabpagadores.Controls.Add(this.btnconsultapagador);
            this.tabpagadores.Controls.Add(this.jsonexemploconsultapagador);
            this.tabpagadores.Controls.Add(this.btncadastropagador);
            this.tabpagadores.Controls.Add(this.jsonexemplocadastropagador);
            this.tabpagadores.Location = new System.Drawing.Point(4, 29);
            this.tabpagadores.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.tabpagadores.Name = "tabpagadores";
            this.tabpagadores.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.tabpagadores.Size = new System.Drawing.Size(696, 797);
            this.tabpagadores.TabIndex = 0;
            this.tabpagadores.Text = "PAGADORES";
            this.tabpagadores.UseVisualStyleBackColor = true;
            this.tabpagadores.Click += new System.EventHandler(this.tabPage1_Click);
            // 
            // btnatualizardadosdopagador
            // 
            this.btnatualizardadosdopagador.Location = new System.Drawing.Point(168, 342);
            this.btnatualizardadosdopagador.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnatualizardadosdopagador.Name = "btnatualizardadosdopagador";
            this.btnatualizardadosdopagador.Size = new System.Drawing.Size(380, 35);
            this.btnatualizardadosdopagador.TabIndex = 5;
            this.btnatualizardadosdopagador.Text = "ATUALIZAR DADOS DO PAGADOR";
            this.btnatualizardadosdopagador.UseVisualStyleBackColor = true;
            this.btnatualizardadosdopagador.Click += new System.EventHandler(this.btnatualizardadosdopagador_Click);
            // 
            // jsonexemploatualizardadosdopagador
            // 
            this.jsonexemploatualizardadosdopagador.Location = new System.Drawing.Point(12, 342);
            this.jsonexemploatualizardadosdopagador.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.jsonexemploatualizardadosdopagador.Name = "jsonexemploatualizardadosdopagador";
            this.jsonexemploatualizardadosdopagador.Size = new System.Drawing.Size(147, 35);
            this.jsonexemploatualizardadosdopagador.TabIndex = 4;
            this.jsonexemploatualizardadosdopagador.Text = "JSON EXEMPLO";
            this.jsonexemploatualizardadosdopagador.UseVisualStyleBackColor = true;
            this.jsonexemploatualizardadosdopagador.Click += new System.EventHandler(this.jsonexemploatualizardadosdopagador_Click);
            // 
            // btnconsultapagador
            // 
            this.btnconsultapagador.Location = new System.Drawing.Point(168, 223);
            this.btnconsultapagador.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnconsultapagador.Name = "btnconsultapagador";
            this.btnconsultapagador.Size = new System.Drawing.Size(380, 35);
            this.btnconsultapagador.TabIndex = 3;
            this.btnconsultapagador.Text = "CONSULTAR PAGADOR";
            this.btnconsultapagador.UseVisualStyleBackColor = true;
            this.btnconsultapagador.Click += new System.EventHandler(this.btnconsultapagador_Click);
            // 
            // jsonexemploconsultapagador
            // 
            this.jsonexemploconsultapagador.Location = new System.Drawing.Point(12, 223);
            this.jsonexemploconsultapagador.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.jsonexemploconsultapagador.Name = "jsonexemploconsultapagador";
            this.jsonexemploconsultapagador.Size = new System.Drawing.Size(147, 35);
            this.jsonexemploconsultapagador.TabIndex = 2;
            this.jsonexemploconsultapagador.Text = "JSON EXEMPLO";
            this.jsonexemploconsultapagador.UseVisualStyleBackColor = true;
            this.jsonexemploconsultapagador.Click += new System.EventHandler(this.jsonexemploconsultapagador_Click);
            // 
            // btncadastropagador
            // 
            this.btncadastropagador.Location = new System.Drawing.Point(168, 109);
            this.btncadastropagador.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btncadastropagador.Name = "btncadastropagador";
            this.btncadastropagador.Size = new System.Drawing.Size(380, 35);
            this.btncadastropagador.TabIndex = 1;
            this.btncadastropagador.Text = "CADASTRAR PAGADOR";
            this.btncadastropagador.UseVisualStyleBackColor = true;
            this.btncadastropagador.Click += new System.EventHandler(this.btncadastropagador_Click);
            // 
            // jsonexemplocadastropagador
            // 
            this.jsonexemplocadastropagador.Location = new System.Drawing.Point(12, 109);
            this.jsonexemplocadastropagador.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.jsonexemplocadastropagador.Name = "jsonexemplocadastropagador";
            this.jsonexemplocadastropagador.Size = new System.Drawing.Size(147, 35);
            this.jsonexemplocadastropagador.TabIndex = 0;
            this.jsonexemplocadastropagador.Text = "JSON EXEMPLO";
            this.jsonexemplocadastropagador.UseVisualStyleBackColor = true;
            this.jsonexemplocadastropagador.Click += new System.EventHandler(this.jsonexemplocadastropagador_Click);
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabpagadores);
            this.tabControl1.Controls.Add(this.tabcontas);
            this.tabControl1.Controls.Add(this.tabpaggerais);
            this.tabControl1.Controls.Add(this.tabpagtaxas);
            this.tabControl1.Controls.Add(this.tabpagnotificacao);
            this.tabControl1.Controls.Add(this.tabconciextratos);
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Location = new System.Drawing.Point(18, 235);
            this.tabControl1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(704, 830);
            this.tabControl1.TabIndex = 75;
            // 
            // mmoajuda
            // 
            this.mmoajuda.BackColor = System.Drawing.SystemColors.Window;
            this.mmoajuda.Location = new System.Drawing.Point(730, 32);
            this.mmoajuda.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.mmoajuda.Multiline = true;
            this.mmoajuda.Name = "mmoajuda";
            this.mmoajuda.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.mmoajuda.Size = new System.Drawing.Size(536, 1033);
            this.mmoajuda.TabIndex = 78;
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, ((System.Drawing.FontStyle)(((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic) 
                | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label41.ForeColor = System.Drawing.SystemColors.Window;
            this.label41.Location = new System.Drawing.Point(1274, 9);
            this.label41.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(240, 20);
            this.label41.TabIndex = 80;
            this.label41.Text = "ENTRADA DA REQUISIÇÃO";
            this.label41.Click += new System.EventHandler(this.label41_Click);
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, ((System.Drawing.FontStyle)(((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic) 
                | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.ForeColor = System.Drawing.SystemColors.Window;
            this.label26.Location = new System.Drawing.Point(1274, 542);
            this.label26.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(211, 20);
            this.label26.TabIndex = 81;
            this.label26.Text = "SAIDA DA REQUISIÇÃO";
            this.label26.Click += new System.EventHandler(this.label26_Click_1);
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, ((System.Drawing.FontStyle)(((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic) 
                | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label42.ForeColor = System.Drawing.SystemColors.Window;
            this.label42.Location = new System.Drawing.Point(726, 9);
            this.label42.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(214, 20);
            this.label42.TabIndex = 82;
            this.label42.Text = "AUXILIO DE EXECUÇÃO";
            this.label42.Click += new System.EventHandler(this.label42_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.ClientSize = new System.Drawing.Size(2190, 1086);
            this.Controls.Add(this.label42);
            this.Controls.Add(this.label26);
            this.Controls.Add(this.label41);
            this.Controls.Add(this.mmoajuda);
            this.Controls.Add(this.mmosaida);
            this.Controls.Add(this.mmoentrada);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.rdambiente);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.edttokensh);
            this.Controls.Add(this.edtcnpjsh);
            this.Controls.Add(this.edtpayercpfcnpj);
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "Form1";
            this.Text = "APLICAÇÃO DE PAGAMENTO";
            this.tabPage1.ResumeLayout(false);
            this.tabconciextratos.ResumeLayout(false);
            this.tabpagnotificacao.ResumeLayout(false);
            this.tabpagtaxas.ResumeLayout(false);
            this.tabpaggerais.ResumeLayout(false);
            this.tabpaggerais.PerformLayout();
            this.tabcontas.ResumeLayout(false);
            this.tabpagadores.ResumeLayout(false);
            this.tabControl1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.ComboBox rdambiente;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox edttokensh;
        private System.Windows.Forms.TextBox edtcnpjsh;
        private System.Windows.Forms.TextBox edtpayercpfcnpj;
        private System.Windows.Forms.TextBox mmosaida;
        private System.Windows.Forms.TextBox mmoentrada;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.Button btnconsultarextratobancario;
        private System.Windows.Forms.Button button22;
        private System.Windows.Forms.Button btnenviarextratobancario;
        private System.Windows.Forms.Button button28;
        private System.Windows.Forms.TabPage tabconciextratos;
        private System.Windows.Forms.Button btnatualizarnotificacao;
        private System.Windows.Forms.Button button18;
        private System.Windows.Forms.Button btnlistarnotificacao;
        private System.Windows.Forms.Button button30;
        private System.Windows.Forms.Button btncriarnotificacao;
        private System.Windows.Forms.Button button32;
        private System.Windows.Forms.TabPage tabpagnotificacao;
        private System.Windows.Forms.Button btnconsultarbilhetagem;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.Button btnconsultarcomprovantedepagamento;
        private System.Windows.Forms.Button button20;
        private System.Windows.Forms.Button btnsolicitarcomprovantedepagamento;
        private System.Windows.Forms.Button button24;
        private System.Windows.Forms.TabPage tabpagtaxas;
        private System.Windows.Forms.Button btnconsultararquivoderetorno;
        private System.Windows.Forms.Button button16;
        private System.Windows.Forms.Button btnenviararquivoderetorno;
        private System.Windows.Forms.Button button21;
        private System.Windows.Forms.Button btnconsultarpagador;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Button btngerarremessa;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.TabPage tabpaggerais;
        private System.Windows.Forms.Button btnsalários;
        private System.Windows.Forms.Button button25;
        private System.Windows.Forms.Button btntransferênciabancaria;
        private System.Windows.Forms.Button button27;
        private System.Windows.Forms.Button btntitulosconcessionariasetributos;
        private System.Windows.Forms.Button button29;
        private System.Windows.Forms.Button btndarf;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button btndpvat;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.Button btnipva;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.Button btngare;
        private System.Windows.Forms.Button button23;
        private System.Windows.Forms.Button btnconsultadepagamamentos;
        private System.Windows.Forms.Button button19;
        private System.Windows.Forms.Button btndiversos;
        private System.Windows.Forms.Button button17;
        private System.Windows.Forms.Button btngps;
        private System.Windows.Forms.Button button15;
        private System.Windows.Forms.TabPage tabcontas;
        private System.Windows.Forms.Button btnalterandocontas;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button btnconsultarconta;
        private System.Windows.Forms.Button jsonexemploconsultarconta;
        private System.Windows.Forms.Button btncriarconta;
        private System.Windows.Forms.Button jsonexemplocriarconta;
        private System.Windows.Forms.TabPage tabpagadores;
        private System.Windows.Forms.Button btnatualizardadosdopagador;
        private System.Windows.Forms.Button jsonexemploatualizardadosdopagador;
        private System.Windows.Forms.Button btnconsultapagador;
        private System.Windows.Forms.Button jsonexemploconsultapagador;
        private System.Windows.Forms.Button btncadastropagador;
        private System.Windows.Forms.Button jsonexemplocadastropagador;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.TextBox mmoajuda;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label42;
    }
}

