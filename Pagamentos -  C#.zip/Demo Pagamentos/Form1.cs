﻿using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using RestSharp;
using System;
using System.Net;
using System.Windows.Forms;
//using System.Runtime.Serialization.Json;

namespace Demo_Pagamentos
{

    public partial class Form1 : Form
    {
        public Form1()
        {

            ServicePointManager.Expect100Continue = true;
            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls
                   | SecurityProtocolType.Tls11
                   | SecurityProtocolType.Tls12;
                   

            InitializeComponent();


        }

        private void rdambiente_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void edtcnpjsh_TextChanged(object sender, EventArgs e)
        {

        }

        private void edttokensh_TextChanged(object sender, EventArgs e)
        {

        }

        private void edtcnpjusuario_TextChanged(object sender, EventArgs e)
        {

        }

        private void edtlogin_TextChanged(object sender, EventArgs e)
        {

        }

        private void edtsenha_TextChanged(object sender, EventArgs e)
        {

        }

        private void painelpagadores_Enter(object sender, EventArgs e)
        {

        }

        private void painelcontas_Enter(object sender, EventArgs e)
        {

        }

        private void painelnotificacao_Enter(object sender, EventArgs e)
        {

        }

        private void painelpagamentosgerais_Enter(object sender, EventArgs e)
        {

        }

        private void painelpagamentodetaxas_Enter(object sender, EventArgs e)
        {

        }

        private void painelconciliacaodeextratos_Enter(object sender, EventArgs e)
        {

        }



        private void tabPage1_Click(object sender, EventArgs e)
        {

        }



        private void btncadastropagador_Click(object sender, EventArgs e)
        {
           
            string url;


            if (rdambiente.Text == "homologação")
            {
                url = "http://staging.pagamentobancario.com.br/api/v1/payer";
            }
            else
                url = "https://api.pagamentobancario.com.br/api/v1/payer";

            if (edtcnpjsh.Text == "" | edttokensh.Text == "" | edtpayercpfcnpj.Text == "")
            {
                MessageBox.Show("Dados obrigatórios não preenchidos!", "Alerta", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }

            var teste = JObject.Parse(mmoentrada.Text);
            var client = new RestClient(url);
            var request = new RestRequest(Method.POST);
            request.AddHeader("cache-control", "no-cache");
            request.AddHeader("content-type", "application/json");
            request.AddHeader("tokenSh", edttokensh.Text);
            request.AddHeader("cnpjSh", edtcnpjsh.Text);
            request.AddHeader("payercpfcnpj", edtpayercpfcnpj.Text);
            request.AddParameter("application/json", (mmoentrada.Text), ParameterType.RequestBody);

            var h = client.Execute(request);



            dynamic json = JObject.Parse(h.Content);
            mmosaida.Text = JsonConvert.SerializeObject(json, Formatting.Indented);


        }

        private void btnconsultapagador_Click(object sender, EventArgs e)
        {
            string url;

            if (rdambiente.Text == "homologação")
            {
                url = "https://staging.pagamentobancario.com.br/api/v1/payer";
            }
            else
                url = "https://api.pagamentobancario.com.br/api/v1/payer";

            if (edtcnpjsh.Text == "" | edttokensh.Text == "" | edtpayercpfcnpj.Text == "")
            {
                MessageBox.Show("Dados obrigatórios não preenchidos!", "Alerta", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }


            var client = new RestClient(url);
            var request = new RestRequest(Method.GET);
            request.AddHeader("cache-control", "no-cache");
            request.AddHeader("content-type", "application/json");
            request.AddHeader("tokenSh", edttokensh.Text);
            request.AddHeader("cnpjSh", edtcnpjsh.Text);
            request.AddHeader("payercpfcnpj", edtpayercpfcnpj.Text);
            request.AddParameter("application/json", (mmoentrada.Text), ParameterType.RequestBody);


            dynamic json = JObject.Parse(client.Execute(request).Content);
            mmosaida.Text = JsonConvert.SerializeObject(json, Formatting.Indented);
        }

        private void button8_Click(object sender, EventArgs e)
        {
            string url;

            if (rdambiente.Text == "homologação")
            {
                url = "https://staging.pagamentobancario.com.br/api/v1/account";
            }
            else
                url = "https://api.pagamentobancario.com.br/api/v1/account";

            if (edtcnpjsh.Text == "" | edttokensh.Text == "" | edtpayercpfcnpj.Text == "")
            {
                MessageBox.Show("Dados obrigatórios não preenchidos!", "Alerta", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            };



            var client = new RestClient(url);
            var request = new RestRequest(Method.POST);
            request.AddHeader("cache-control", "no-cache");
            request.AddHeader("content-type", "application/json");
            request.AddHeader("tokenSh", edttokensh.Text);
            request.AddHeader("cnpjSh", edtcnpjsh.Text);
            request.AddHeader("payercpfcnpj", edtpayercpfcnpj.Text);
            request.AddParameter("application/json", (mmoentrada.Text), ParameterType.RequestBody);

            dynamic json = JObject.Parse(client.Execute(request).Content);
            mmosaida.Text = JsonConvert.SerializeObject(json, Formatting.Indented);

        }

        private void btnconsultarconta_Click(object sender, EventArgs e)
        {
            string url;

            if (rdambiente.Text == "homologação")
            {
                url = "https://staging.pagamentobancario.com.br/api/v1/account";
            }
            else
                url = "https://api.pagamentobancario.com.br/api/v1/account";

            if (edtcnpjsh.Text == "" | edttokensh.Text == "" | edtpayercpfcnpj.Text == "")
            {
                MessageBox.Show("Dados obrigatórios não preenchidos!", "Alerta", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }


            var client = new RestClient(url);
            var request = new RestRequest(Method.GET);
            request.AddHeader("cache-control", "no-cache");
            request.AddHeader("content-type", "application/json");
            request.AddHeader("tokenSh", edttokensh.Text);
            request.AddHeader("cnpjSh", edtcnpjsh.Text);
            request.AddHeader("payercpfcnpj", edtpayercpfcnpj.Text);
            request.AddParameter("application/json", (mmoentrada.Text), ParameterType.RequestBody);


            dynamic json = JObject.Parse(client.Execute(request).Content);
            mmosaida.Text = JsonConvert.SerializeObject(json, Formatting.Indented);
        }

        private void btnatualizardadosdopagador_Click(object sender, EventArgs e)
        {
            string url;

            if (rdambiente.Text == "homologação")
            {
                url = "https://staging.pagamentobancario.com.br/api/v1/payer";
            }
            else
                url = "https://api.pagamentobancario.com.br/api/v1/payer";

            if (edtcnpjsh.Text == "" | edttokensh.Text == "" | edtpayercpfcnpj.Text == "")
            {
                MessageBox.Show("Dados obrigatórios não preenchidos!", "Alerta", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }


            var client = new RestClient(url);
            var request = new RestRequest(Method.PUT);
            request.AddHeader("cache-control", "no-cache");
            request.AddHeader("content-type", "application/json");
            request.AddHeader("tokenSh", edttokensh.Text);
            request.AddHeader("cnpjSh", edtcnpjsh.Text);
            request.AddHeader("payercpfcnpj", edtpayercpfcnpj.Text);
            request.AddParameter("application/json", (mmoentrada.Text), ParameterType.RequestBody);


            dynamic json = JObject.Parse(client.Execute(request).Content);
            mmosaida.Text = JsonConvert.SerializeObject(json, Formatting.Indented);


        }

        private void jsonexemplocriarconta_Click(object sender, EventArgs e)
        {
            mmoajuda.Text = String.Empty;
            mmoentrada.Text = String.Empty;

            mmoentrada.Text += "["; _ = Environment.NewLine;
            mmoentrada.Text += "{"; _ = Environment.NewLine;
            mmoentrada.Text += "bankCode: 001"; _ = Environment.NewLine;
            mmoentrada.Text += "agency: 1111"; _ = Environment.NewLine;
            mmoentrada.Text += "agencyDigit: "; _ = Environment.NewLine;
            mmoentrada.Text += "accountNumber: 0001"; _ = Environment.NewLine;
            mmoentrada.Text += "accountDac: 1"; _ = Environment.NewLine;
            mmoentrada.Text += "convenioAgency: "; _ = Environment.NewLine;
            mmoentrada.Text += "convenioNumber: 22"; _ = Environment.NewLine;
            mmoentrada.Text += "remessaSequential: 0"; _ = Environment.NewLine;
            mmoentrada.Text += "van: false"; _ = Environment.NewLine;
            mmoentrada.Text += "}"; _ = Environment.NewLine;
            mmoentrada.Text += "]"; _ = Environment.NewLine;

            mmoajuda.Text += "Criar conta" + "\r\n"; _ = Environment.NewLine;

            mmoajuda.Text += "\tA documentação https://docs.pagamentobancario.com.br/#operation/createAccount mostrará como efetuar o cadastro de contas." + "\r\n"; _ = Environment.NewLine;

        }

        private void btnalterandocontas_Click(object sender, EventArgs e)
        {
            string url;

            if (rdambiente.Text == "homologação")
            {
                url = "https://staging.pagamentobancario.com.br/api/v1/account/";
            }
            else
                url = "https://api.pagamentobancario.com.br/api/v1/account/";

            if (edtcnpjsh.Text == "" | edttokensh.Text == "" | edtpayercpfcnpj.Text == "")
            {
                MessageBox.Show("Dados obrigatórios não preenchidos!", "Alerta", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }


            var client = new RestClient(url + mmoentrada.Text);
            var request = new RestRequest(Method.PUT);
            request.AddHeader("cache-control", "no-cache");
            request.AddHeader("content-type", "application/json");
            request.AddHeader("tokenSh", edttokensh.Text);
            request.AddHeader("cnpjSh", edtcnpjsh.Text);
            request.AddHeader("payercpfcnpj", edtpayercpfcnpj.Text);
            request.AddParameter("application/json", (mmoentrada.Text), ParameterType.RequestBody);


            dynamic json = JObject.Parse(client.Execute(request).Content);
            mmosaida.Text = JsonConvert.SerializeObject(json, Formatting.Indented);


        }

        private void button28_Click(object sender, EventArgs e)
        {
            string url;

            if (rdambiente.Text == "homologação")
            {
                url = "https://staging.pagamentobancario.com.br/api/v1/payment/billet";
            }
            else
                url = "https://api.pagamentobancario.com.br/api/v1/payment/billet";

            if (edtcnpjsh.Text == "" | edttokensh.Text == "" | edtpayercpfcnpj.Text == "")
            {
                MessageBox.Show("Dados obrigatórios não preenchidos!", "Alerta", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }


            var client = new RestClient(url);
            var request = new RestRequest(Method.POST);
            request.AddHeader("cache-control", "no-cache");
            request.AddHeader("content-type", "application/json");
            request.AddHeader("tokenSh", edttokensh.Text);
            request.AddHeader("cnpjSh", edtcnpjsh.Text);
            request.AddHeader("payercpfcnpj", edtpayercpfcnpj.Text);
            request.AddParameter("application/json", (mmoentrada.Text), ParameterType.RequestBody);


            dynamic json = JObject.Parse(client.Execute(request).Content);
            mmosaida.Text = JsonConvert.SerializeObject(json, Formatting.Indented);

        }

        private void button26_Click(object sender, EventArgs e)
        {
            string url;

            if (rdambiente.Text == "homologação")
            {
                url = "https://staging.pagamentobancario.com.br/api/v1/payment/transfer";
            }
            else
                url = "https://api.pagamentobancario.com.br/api/v1/payment/transfer";

            if (edtcnpjsh.Text == "" | edttokensh.Text == "" | edtpayercpfcnpj.Text == "")
            {
                MessageBox.Show("Dados obrigatórios não preenchidos!", "Alerta", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }


            var client = new RestClient(url);
            var request = new RestRequest(Method.POST);
            request.AddHeader("cache-control", "no-cache");
            request.AddHeader("content-type", "application/json");
            request.AddHeader("tokenSh", edttokensh.Text);
            request.AddHeader("cnpjSh", edtcnpjsh.Text);
            request.AddHeader("payercpfcnpj", edtpayercpfcnpj.Text);
            request.AddParameter("application/json", (mmoentrada.Text), ParameterType.RequestBody);


            dynamic json = JObject.Parse(client.Execute(request).Content);
            mmosaida.Text = JsonConvert.SerializeObject(json, Formatting.Indented);

        }

        private void btnsalários_Click(object sender, EventArgs e)
        {

            string url;

            if (rdambiente.Text == "homologação")
            {
                url = "https://staging.pagamentobancario.com.br/api/v1/payment/paycheck";
            }
            else
                url = "https://api.pagamentobancario.com.br/api/v1/payment/paycheck";

            if (edtcnpjsh.Text == "" | edttokensh.Text == "" | edtpayercpfcnpj.Text == "")
            {
                MessageBox.Show("Dados obrigatórios não preenchidos!", "Alerta", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }


            var client = new RestClient(url);
            var request = new RestRequest(Method.POST);
            request.AddHeader("cache-control", "no-cache");
            request.AddHeader("content-type", "application/json");
            request.AddHeader("tokenSh", edttokensh.Text);
            request.AddHeader("cnpjSh", edtcnpjsh.Text);
            request.AddHeader("payercpfcnpj", edtpayercpfcnpj.Text);
            request.AddParameter("application/json", (mmoentrada.Text), ParameterType.RequestBody);


            dynamic json = JObject.Parse(client.Execute(request).Content);
            mmosaida.Text = JsonConvert.SerializeObject(json, Formatting.Indented);

        }

        private void btngare_Click(object sender, EventArgs e)
        {

            string url;

            if (rdambiente.Text == "homologação")
            {
                url = "https://staging.pagamentobancario.com.br/api/v1/payment/taxes/gare";
            }
            else
                url = "https://api.pagamentobancario.com.br/api/v1/payment/taxes/gare";

            if (edtcnpjsh.Text == "" | edttokensh.Text == "" | edtpayercpfcnpj.Text == "")
            {
                MessageBox.Show("Dados obrigatórios não preenchidos!", "Alerta", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }


            var client = new RestClient(url);
            var request = new RestRequest(Method.POST);
            request.AddHeader("cache-control", "no-cache");
            request.AddHeader("content-type", "application/json");
            request.AddHeader("tokenSh", edttokensh.Text);
            request.AddHeader("cnpjSh", edtcnpjsh.Text);
            request.AddHeader("payercpfcnpj", edtpayercpfcnpj.Text);
            request.AddParameter("application/json", (mmoentrada.Text), ParameterType.RequestBody);


            dynamic json = JObject.Parse(client.Execute(request).Content);
            mmosaida.Text = JsonConvert.SerializeObject(json, Formatting.Indented);

        }

        private void btnipva_Click(object sender, EventArgs e)
        {
            string url;

            if (rdambiente.Text == "homologação")
            {
                url = "https://staging.pagamentobancario.com.br/api/v1/payment/taxes/ipva";
            }
            else
                url = "https://api.pagamentobancario.com.br/api/v1/payment/taxes/ipva";

            if (edtcnpjsh.Text == "" | edttokensh.Text == "" | edtpayercpfcnpj.Text == "")
            {
                MessageBox.Show("Dados obrigatórios não preenchidos!", "Alerta", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }


            var client = new RestClient(url);
            var request = new RestRequest(Method.POST);
            request.AddHeader("cache-control", "no-cache");
            request.AddHeader("content-type", "application/json");
            request.AddHeader("tokenSh", edttokensh.Text);
            request.AddHeader("cnpjSh", edtcnpjsh.Text);
            request.AddHeader("payercpfcnpj", edtpayercpfcnpj.Text);
            request.AddParameter("application/json", (mmoentrada.Text), ParameterType.RequestBody);


            dynamic json = JObject.Parse(client.Execute(request).Content);
            mmosaida.Text = JsonConvert.SerializeObject(json, Formatting.Indented);
        }

        private void button10_Click(object sender, EventArgs e)
        {
            string url;

            if (rdambiente.Text == "homologação")
            {
                url = "https://staging.pagamentobancario.com.br/api/v1/payment/taxes/dpvat";
            }
            else
                url = "https://api.pagamentobancario.com.br/api/v1/payment/taxes/dpvat";

            if (edtcnpjsh.Text == "" | edttokensh.Text == "" | edtpayercpfcnpj.Text == "")
            {
                MessageBox.Show("Dados obrigatórios não preenchidos!", "Alerta", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }


            var client = new RestClient(url);
            var request = new RestRequest(Method.POST);
            request.AddHeader("cache-control", "no-cache");
            request.AddHeader("content-type", "application/json");
            request.AddHeader("tokenSh", edttokensh.Text);
            request.AddHeader("cnpjSh", edtcnpjsh.Text);
            request.AddHeader("payercpfcnpj", edtpayercpfcnpj.Text);
            request.AddParameter("application/json", (mmoentrada.Text), ParameterType.RequestBody);


            dynamic json = JObject.Parse(client.Execute(request).Content);
            mmosaida.Text = JsonConvert.SerializeObject(json, Formatting.Indented);
        }

        private void btndarf_Click(object sender, EventArgs e)
        {
            string url;

            if (rdambiente.Text == "homologação")
            {
                url = "https://staging.pagamentobancario.com.br/api/v1/payment/taxes/darf";
            }
            else
                url = "https://api.pagamentobancario.com.br/api/v1/payment/taxes/darf";

            if (edtcnpjsh.Text == "" | edttokensh.Text == "" | edtpayercpfcnpj.Text == "")
            {
                MessageBox.Show("Dados obrigatórios não preenchidos!", "Alerta", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }


            var client = new RestClient(url);
            var request = new RestRequest(Method.POST);
            request.AddHeader("cache-control", "no-cache");
            request.AddHeader("content-type", "application/json");
            request.AddHeader("tokenSh", edttokensh.Text);
            request.AddHeader("cnpjSh", edtcnpjsh.Text);
            request.AddHeader("payercpfcnpj", edtpayercpfcnpj.Text);
            request.AddParameter("application/json", (mmoentrada.Text), ParameterType.RequestBody);


            dynamic json = JObject.Parse(client.Execute(request).Content);
            mmosaida.Text = JsonConvert.SerializeObject(json, Formatting.Indented);
        }

        private void btngps_Click(object sender, EventArgs e)
        {
            string url;

            if (rdambiente.Text == "homologação")
            {
                url = "https://staging.pagamentobancario.com.br/api/v1/payment/taxes/gps";
            }
            else
                url = "https://api.pagamentobancario.com.br/api/v1/payment/taxes/gps";

            if (edtcnpjsh.Text == "" | edttokensh.Text == "" | edtpayercpfcnpj.Text == "")
            {
                MessageBox.Show("Dados obrigatórios não preenchidos!", "Alerta", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }


            var client = new RestClient(url);
            var request = new RestRequest(Method.POST);
            request.AddHeader("cache-control", "no-cache");
            request.AddHeader("content-type", "application/json");
            request.AddHeader("tokenSh", edttokensh.Text);
            request.AddHeader("cnpjSh", edtcnpjsh.Text);
            request.AddHeader("payercpfcnpj", edtpayercpfcnpj.Text);
            request.AddParameter("application/json", (mmoentrada.Text), ParameterType.RequestBody);


            dynamic json = JObject.Parse(client.Execute(request).Content);
            mmosaida.Text = JsonConvert.SerializeObject(json, Formatting.Indented);
        }

        private void btndiversos_Click(object sender, EventArgs e)
        {
            string url;

            if (rdambiente.Text == "homologação")
            {
                url = "https://staging.pagamentobancario.com.br/api/v1/payment/various";
            }
            else
                url = "https://api.pagamentobancario.com.br/api/v1/payment/various";

            if (edtcnpjsh.Text == "" | edttokensh.Text == "" | edtpayercpfcnpj.Text == "")
            {
                MessageBox.Show("Dados obrigatórios não preenchidos!", "Alerta", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }


            var client = new RestClient(url);
            var request = new RestRequest(Method.POST);
            request.AddHeader("cache-control", "no-cache");
            request.AddHeader("content-type", "application/json");
            request.AddHeader("tokenSh", edttokensh.Text);
            request.AddHeader("cnpjSh", edtcnpjsh.Text);
            request.AddHeader("payercpfcnpj", edtpayercpfcnpj.Text);
            request.AddParameter("application/json", (mmoentrada.Text), ParameterType.RequestBody);


            dynamic json = JObject.Parse(client.Execute(request).Content);
            mmosaida.Text = JsonConvert.SerializeObject(json, Formatting.Indented);
        }

        private void btnconsultadepagamamentos_Click(object sender, EventArgs e)
        {
            string url;

            if (rdambiente.Text == "homologação")
            {
                url = "https://staging.pagamentobancario.com.br/api/v1/payment";
            }
            else
                url = "https://api.pagamentobancario.com.br/api/v1/payment";

            if (edtcnpjsh.Text == "" | edttokensh.Text == "" | edtpayercpfcnpj.Text == "")
            {
                MessageBox.Show("Dados obrigatórios não preenchidos!", "Alerta", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }


            var client = new RestClient(url + mmoentrada.Text);
            var request = new RestRequest(Method.GET);
            request.AddHeader("cache-control", "no-cache");
            request.AddHeader("content-type", "application/json");
            request.AddHeader("tokenSh", edttokensh.Text);
            request.AddHeader("cnpjSh", edtcnpjsh.Text);
            request.AddHeader("payercpfcnpj", edtpayercpfcnpj.Text);
            request.AddParameter("application/json", (mmoentrada.Text), ParameterType.RequestBody);


            dynamic json = JObject.Parse(client.Execute(request).Content);
            mmosaida.Text = JsonConvert.SerializeObject(json, Formatting.Indented);
        }

        private void button20_Click(object sender, EventArgs e)
        {

        }

        private void btngerarremessa_Click(object sender, EventArgs e)
        {
            string url;

            if (rdambiente.Text == "homologação")
            {
                url = "https://staging.pagamentobancario.com.br/api/v1/remittance";
            }
            else
                url = "https://api.pagamentobancario.com.br/api/v1/remittance";

            if (edtcnpjsh.Text == "" | edttokensh.Text == "" | edtpayercpfcnpj.Text == "")
            {
                MessageBox.Show("Dados obrigatórios não preenchidos!", "Alerta", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }


            var client = new RestClient(url);
            var request = new RestRequest(Method.POST);
            request.AddHeader("cache-control", "no-cache");
            request.AddHeader("content-type", "application/json");
            request.AddHeader("tokenSh", edttokensh.Text);
            request.AddHeader("cnpjSh", edtcnpjsh.Text);
            request.AddHeader("payercpfcnpj", edtpayercpfcnpj.Text);
            request.AddParameter("application/json", (mmoentrada.Text), ParameterType.RequestBody);


            dynamic json = JObject.Parse(client.Execute(request).Content);
            mmosaida.Text = JsonConvert.SerializeObject(json, Formatting.Indented);
        }

        private void btnconsultarpagador_Click(object sender, EventArgs e)
        {

            string url;

            if (rdambiente.Text == "homologação")
            {
                url = "https://staging.pagamentobancario.com.br/api/v1/remittance/";
            }
            else
                url = "https://api.pagamentobancario.com.br/api/v1/remittance/";

            if (edtcnpjsh.Text == "" | edttokensh.Text == "" | edtpayercpfcnpj.Text == "")
            {
                MessageBox.Show("Dados obrigatórios não preenchidos!", "Alerta", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }


            var client = new RestClient(url + mmoentrada.Text);
            var request = new RestRequest(Method.GET);
            request.AddHeader("cache-control", "no-cache");
            request.AddHeader("content-type", "application/json");
            request.AddHeader("tokenSh", edttokensh.Text);
            request.AddHeader("cnpjSh", edtcnpjsh.Text);
            request.AddHeader("payercpfcnpj", edtpayercpfcnpj.Text);
            request.AddParameter("application/json", (mmoentrada.Text), ParameterType.RequestBody);


            dynamic json = JObject.Parse(client.Execute(request).Content);
            mmosaida.Text = JsonConvert.SerializeObject(json, Formatting.Indented);
        }

        private void btnconsultararquivoderetorno_Click(object sender, EventArgs e)
        {

            string url;

            if (rdambiente.Text == "homologação")
            {
                url = "https://staging.pagamentobancario.com.br/api/v1/reconciliation/";
            }
            else
                url = "https://api.pagamentobancario.com.br/api/v1/remittance/";

            if (edtcnpjsh.Text == "" | edttokensh.Text == "" | edtpayercpfcnpj.Text == "")
            {
                MessageBox.Show("Dados obrigatórios não preenchidos!", "Alerta", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }


            var client = new RestClient(url + mmoentrada.Text);
            var request = new RestRequest(Method.GET);
            request.AddHeader("cache-control", "no-cache");
            request.AddHeader("content-type", "application/json");
            request.AddHeader("tokenSh", edttokensh.Text);
            request.AddHeader("cnpjSh", edtcnpjsh.Text);
            request.AddHeader("payercpfcnpj", edtpayercpfcnpj.Text);
            request.AddParameter("application/json", (mmoentrada.Text), ParameterType.RequestBody);


            dynamic json = JObject.Parse(client.Execute(request).Content);
            mmosaida.Text = JsonConvert.SerializeObject(json, Formatting.Indented);
        }

        private void btnenviararquivoderetorno_Click(object sender, EventArgs e)
        {
            string url;

            if (rdambiente.Text == "homologação")
            {
                url = "https://staging.pagamentobancario.com.br/api/v1/reconciliation";
            }
            else
                url = "https://api.pagamentobancario.com.br/api/v1/reconciliation";

            if (edtcnpjsh.Text == "" | edttokensh.Text == "" | edtpayercpfcnpj.Text == "")
            {
                MessageBox.Show("Dados obrigatórios não preenchidos!", "Alerta", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }


            var client = new RestClient(url);
            var request = new RestRequest(Method.POST);
            request.AddHeader("cache-control", "no-cache");
            request.AddHeader("content-type", "application/json");
            request.AddHeader("tokenSh", edttokensh.Text);
            request.AddHeader("cnpjSh", edtcnpjsh.Text);
            request.AddHeader("payercpfcnpj", edtpayercpfcnpj.Text);
            request.AddParameter("application/json", (mmoentrada.Text), ParameterType.RequestBody);


            dynamic json = JObject.Parse(client.Execute(request).Content);
            mmosaida.Text = JsonConvert.SerializeObject(json, Formatting.Indented);
        }

        private void button20_Click_1(object sender, EventArgs e)
        {
            string url;

            if (rdambiente.Text == "homologação")
            {
                url = "https://staging.pagamentobancario.com.br/api/v1/reconciliation";
            }
            else
                url = "https://api.pagamentobancario.com.br/api/v1/reconciliation";

            if (edtcnpjsh.Text == "" | edttokensh.Text == "" | edtpayercpfcnpj.Text == "")
            {
                MessageBox.Show("Dados obrigatórios não preenchidos!", "Alerta", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }


            var client = new RestClient(url);
            var request = new RestRequest(Method.POST);
            request.AddHeader("cache-control", "no-cache");
            request.AddHeader("content-type", "application/json");
            request.AddHeader("tokenSh", edttokensh.Text);
            request.AddHeader("cnpjSh", edtcnpjsh.Text);
            request.AddHeader("payercpfcnpj", edtpayercpfcnpj.Text);
            request.AddParameter("application/json", (mmoentrada.Text), ParameterType.RequestBody);


            dynamic json = JObject.Parse(client.Execute(request).Content);
            mmosaida.Text = JsonConvert.SerializeObject(json, Formatting.Indented);
        }

        private void tabpagtaxas_Click(object sender, EventArgs e)
        {

        }

        private void button6_Click(object sender, EventArgs e)
        {

            string url;

            if (rdambiente.Text == "homologação")
            {
                url = "https://staging.pagamentobancario.com.br/api/v1/reconciliation/";
            }
            else
                url = "https://api.pagamentobancario.com.br/api/v1/remittance/";

            if (edtcnpjsh.Text == "" | edttokensh.Text == "" | edtpayercpfcnpj.Text == "")
            {
                MessageBox.Show("Dados obrigatórios não preenchidos!", "Alerta", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }


            var client = new RestClient(url + mmoentrada.Text);
            var request = new RestRequest(Method.GET);
            request.AddHeader("cache-control", "no-cache");
            request.AddHeader("content-type", "application/json");
            request.AddHeader("tokenSh", edttokensh.Text);
            request.AddHeader("cnpjSh", edtcnpjsh.Text);
            request.AddHeader("payercpfcnpj", edtpayercpfcnpj.Text);
            request.AddParameter("application/json", (mmoentrada.Text), ParameterType.RequestBody);


            dynamic json = JObject.Parse(client.Execute(request).Content);
            mmosaida.Text = JsonConvert.SerializeObject(json, Formatting.Indented);
        }

        private void btnsolicitarcomprovantedepagamento_Click(object sender, EventArgs e)
        {
            string url;

            if (rdambiente.Text == "homologação")
            {
                url = "https://staging.pagamentobancario.com.br/api/v1/voucher";
            }
            else
                url = "https://api.pagamentobancario.com.br/api/v1/voucher";

            if (edtcnpjsh.Text == "" | edttokensh.Text == "" | edtpayercpfcnpj.Text == "")
            {
                MessageBox.Show("Dados obrigatórios não preenchidos!", "Alerta", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }


            var client = new RestClient(url);
            var request = new RestRequest(Method.POST);
            request.AddHeader("cache-control", "no-cache");
            request.AddHeader("content-type", "application/json");
            request.AddHeader("tokenSh", edttokensh.Text);
            request.AddHeader("cnpjSh", edtcnpjsh.Text);
            request.AddHeader("payercpfcnpj", edtpayercpfcnpj.Text);
            request.AddParameter("application/json", (mmoentrada.Text), ParameterType.RequestBody);


            dynamic json = JObject.Parse(client.Execute(request).Content);
            mmosaida.Text = JsonConvert.SerializeObject(json, Formatting.Indented);
        }

        private void btnconsultarcomprovantedepagamento_Click(object sender, EventArgs e)
        {
            string url;

            if (rdambiente.Text == "homologação")
            {
                url = "https://staging.pagamentobancario.com.br/api/v1/voucher/";
            }
            else
                url = "https://api.pagamentobancario.com.br/api/v1/voucher/";

            if (edtcnpjsh.Text == "" | edttokensh.Text == "" | edtpayercpfcnpj.Text == "")
            {
                MessageBox.Show("Dados obrigatórios não preenchidos!", "Alerta", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }


            var client = new RestClient(url + mmoentrada.Text);
            var request = new RestRequest(Method.POST);
            request.AddHeader("cache-control", "no-cache");
            request.AddHeader("content-type", "application/json");
            request.AddHeader("tokenSh", edttokensh.Text);
            request.AddHeader("cnpjSh", edtcnpjsh.Text);
            request.AddHeader("payercpfcnpj", edtpayercpfcnpj.Text);
            request.AddParameter("application/json", (mmoentrada.Text), ParameterType.RequestBody);


            dynamic json = JObject.Parse(client.Execute(request).Content);
            mmosaida.Text = JsonConvert.SerializeObject(json, Formatting.Indented);
        }

        private void btnconsultarbilhetagem_Click(object sender, EventArgs e)
        {
            string url;

            if (rdambiente.Text == "homologação")
            {
                url = "https://staging.pagamentobancario.com.br/api/v1/report";
            }
            else
                url = "https://api.pagamentobancario.com.br/api/v1/report";

            if (edtcnpjsh.Text == "" | edttokensh.Text == "" | edtpayercpfcnpj.Text == "")
            {
                MessageBox.Show("Dados obrigatórios não preenchidos!", "Alerta", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }


            var client = new RestClient(url);
            var request = new RestRequest(Method.POST);
            request.AddHeader("cache-control", "no-cache");
            request.AddHeader("content-type", "application/json");
            request.AddHeader("tokenSh", edttokensh.Text);
            request.AddHeader("cnpjSh", edtcnpjsh.Text);
            request.AddHeader("payercpfcnpj", edtpayercpfcnpj.Text);
            request.AddParameter("application/json", (mmoentrada.Text), ParameterType.RequestBody);


            dynamic json = JObject.Parse(client.Execute(request).Content);
            mmosaida.Text = JsonConvert.SerializeObject(json, Formatting.Indented);
        }

        private void button31_Click(object sender, EventArgs e)
        {
            string url;

            if (rdambiente.Text == "homologação")
            {
                url = "https://staging.pagamentobancario.com.br/api/v1/notification";
            }
            else
                url = "https://api.pagamentobancario.com.br/api/v1/notification";

            if (edtcnpjsh.Text == "" | edttokensh.Text == "" | edtpayercpfcnpj.Text == "")
            {
                MessageBox.Show("Dados obrigatórios não preenchidos!", "Alerta", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }


            var client = new RestClient(url);
            var request = new RestRequest(Method.POST);
            request.AddHeader("cache-control", "no-cache");
            request.AddHeader("content-type", "application/json");
            request.AddHeader("tokenSh", edttokensh.Text);
            request.AddHeader("cnpjSh", edtcnpjsh.Text);
            request.AddHeader("payercpfcnpj", edtpayercpfcnpj.Text);
            request.AddParameter("application/json", (mmoentrada.Text), ParameterType.RequestBody);


            dynamic json = JObject.Parse(client.Execute(request).Content);
            mmosaida.Text = JsonConvert.SerializeObject(json, Formatting.Indented);
        }

        private void button28_Click_1(object sender, EventArgs e)
        {
            string url;

            if (rdambiente.Text == "homologação")
            {
                url = "https://staging.pagamentobancario.com.br/api/v1/notification";
            }
            else
                url = "https://staging.pagamentobancario.com.br/api/v1/notification";

            if (edtcnpjsh.Text == "" | edttokensh.Text == "" | edtpayercpfcnpj.Text == "")
            {
                MessageBox.Show("Dados obrigatórios não preenchidos!", "Alerta", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }


            var client = new RestClient(url);
            var request = new RestRequest(Method.GET);
            request.AddHeader("cache-control", "no-cache");
            request.AddHeader("content-type", "application/json");
            request.AddHeader("tokenSh", edttokensh.Text);
            request.AddHeader("cnpjSh", edtcnpjsh.Text);
            request.AddHeader("payercpfcnpj", edtpayercpfcnpj.Text);
            request.AddParameter("application/json", (mmoentrada.Text), ParameterType.RequestBody);


            dynamic json = JObject.Parse(client.Execute(request).Content);
            mmosaida.Text = JsonConvert.SerializeObject(json, Formatting.Indented);
        }

        private void btnatualizarnotificacao_Click(object sender, EventArgs e)
        {
            string url;

            if (rdambiente.Text == "homologação")
            {
                url = "https://staging.pagamentobancario.com.br/api/v1/notification";
            }
            else
                url = "https://api.pagamentobancario.com.br/api/v1/notification";

            if (edtcnpjsh.Text == "" | edttokensh.Text == "" | edtpayercpfcnpj.Text == "")
            {
                MessageBox.Show("Dados obrigatórios não preenchidos!", "Alerta", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }


            var client = new RestClient(url);
            var request = new RestRequest(Method.PUT);
            request.AddHeader("cache-control", "no-cache");
            request.AddHeader("content-type", "application/json");
            request.AddHeader("tokenSh", edttokensh.Text);
            request.AddHeader("cnpjSh", edtcnpjsh.Text);
            request.AddHeader("payercpfcnpj", edtpayercpfcnpj.Text);
            request.AddParameter("application/json", (mmoentrada.Text), ParameterType.RequestBody);


            dynamic json = JObject.Parse(client.Execute(request).Content);
            mmosaida.Text = JsonConvert.SerializeObject(json, Formatting.Indented);
        }

        private void btnenviarextratobancario_Click(object sender, EventArgs e)
        {
            string url;

            if (rdambiente.Text == "homologação")
            {
                url = "https://staging.pagamentobancario.com.br/api/v1/statement/parser";
            }
            else
                url = "https://api.pagamentobancario.com.br/api/v1/statement/parser";

            if (edtcnpjsh.Text == "" | edttokensh.Text == "" | edtpayercpfcnpj.Text == "")
            {
                MessageBox.Show("Dados obrigatórios não preenchidos!", "Alerta", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }


            var client = new RestClient(url);
            var request = new RestRequest(Method.POST);
            request.AddHeader("cache-control", "no-cache");
            request.AddHeader("content-type", "application/json");
            request.AddHeader("tokenSh", edttokensh.Text);
            request.AddHeader("cnpjSh", edtcnpjsh.Text);
            request.AddHeader("payercpfcnpj", edtpayercpfcnpj.Text);
            request.AddParameter("application/json", (mmoentrada.Text), ParameterType.RequestBody);


            dynamic json = JObject.Parse(client.Execute(request).Content);
            mmosaida.Text = JsonConvert.SerializeObject(json, Formatting.Indented);
        }

        private void btnconsultarextratobancario_Click(object sender, EventArgs e)
        {
            string url;

            if (rdambiente.Text == "homologação")
            {
                url = "https://staging.pagamentobancario.com.br/api/v1/statement/parser/";
            }
            else
                url = "https://api.pagamentobancario.com.br/api/v1/statement/parser/";

            if (edtcnpjsh.Text == "" | edttokensh.Text == "" | edtpayercpfcnpj.Text == "")
            {
                MessageBox.Show("Dados obrigatórios não preenchidos!", "Alerta", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }


            var client = new RestClient(url + mmoentrada.Text);
            var request = new RestRequest(Method.GET);
            request.AddHeader("cache-control", "no-cache");
            request.AddHeader("content-type", "application/json");
            request.AddHeader("tokenSh", edttokensh.Text);
            request.AddHeader("cnpjSh", edtcnpjsh.Text);
            request.AddHeader("payercpfcnpj", edtpayercpfcnpj.Text);
            request.AddParameter("application/json", (mmoentrada.Text), ParameterType.RequestBody);


            dynamic json = JObject.Parse(client.Execute(request).Content);
            mmosaida.Text = JsonConvert.SerializeObject(json, Formatting.Indented);
        }






        private void jsonexemplocadastropagador_Click(object sender, EventArgs e)
        {
            mmoajuda.Text = String.Empty;
            mmoentrada.Text = String.Empty;

            mmoentrada.Text  = @"{
             'Email': 'james@example.com',
                'Active': true,
                 'CreatedDate': '2013-01-20T00:00:00Z',
                    'Roles': [
                      'User',
                          'Admin'
                             ]
                                    }";

            mmoajuda.Text += "CADASTRO DE PAGADOR"+ "\r\n"; _ = Environment.NewLine;
            mmoajuda.Text += ""; _ = Environment.NewLine;
            mmoajuda.Text += "\tAntes de fazer qualquer ação no produto, é necessário fazer o cadastro do pagador, ou seja, cadastrar o CNPJ do pagador e as contas que irão gerar os pagamentos." + "\r\n"; _ = Environment.NewLine;
            mmoajuda.Text += ""; _ = Environment.NewLine;
            mmoajuda.Text += "\tEste processo é feito através da rota que explicaremos abaixo e também conforme a documentação: https://docs.pagamentobancario.com.br/#tag/payer" + "\r\n"; _ = Environment.NewLine;
            mmoajuda.Text += ""; _ = Environment.NewLine;
            mmoajuda.Text += "\tObs.: É importante que os campos que identificam a conta sejam confirmados com o banco antes de efetuar o cadastro das informações em nossa API." + "\r\n"; _ = Environment.NewLine;

        }

        private void jsonexemploconsultapagador_Click(object sender, EventArgs e)
        {
            mmoajuda.Text = String.Empty;
            mmoentrada.Text = String.Empty;
            mmoentrada.Text += "{"; _ = Environment.NewLine;
            mmoentrada.Text += "accounts: ["; _ = Environment.NewLine;
            mmoentrada.Text += "{}"; _ = Environment.NewLine;
            mmoentrada.Text += "]"; _ = Environment.NewLine;
            mmoentrada.Text += "}"; _ = Environment.NewLine;

            mmoajuda.Text += "CONSULTA DE PAGADOR" + "\r\n"; _ = Environment.NewLine;
            
            mmoajuda.Text += "\tRota responsável pela consulta dos dados do pagador." + "\r\n"; _ = Environment.NewLine;
           
            mmoajuda.Text += "\tEm caso de sucesso, o retorno da API trará na resposta todas as informações que foram cadastradas para o CNPJ consultado, incluindo o accountHash, token e demais campos que visem a identificação do pagador." + "\r\n"; _ = Environment.NewLine;
          
            mmoajuda.Text += "\t" + "\r\n"; _ = Environment.NewLine;

        }

        private void jsonexemploatualizardadosdopagador_Click(object sender, EventArgs e)
        {
            mmoajuda.Text = String.Empty;
            mmoentrada.Text = String.Empty;

            mmoentrada.Text += "{"; _ = Environment.NewLine;
            mmoentrada.Text += "name: Tecnospeed"; _ = Environment.NewLine;
            mmoentrada.Text += "email: contato@tecnospeed.com.br"; _ = Environment.NewLine;
            mmoentrada.Text += "neighborhood: DUQUE DE CAXIAS"; _ = Environment.NewLine;
            mmoentrada.Text += "addressNumber: 882"; _ = Environment.NewLine;
            mmoentrada.Text += "zipcode: 87020025"; _ = Environment.NewLine;
            mmoentrada.Text += "state: PR"; _ = Environment.NewLine;
            mmoentrada.Text += "city: MARINGA"; _ = Environment.NewLine;
            mmoentrada.Text += "addressComplement: ,"; _ = Environment.NewLine;
            mmoentrada.Text += "}"; _ = Environment.NewLine;


            mmoajuda.Text += "Atualizar dados do pagador" + "\r\n"; _ = Environment.NewLine;

            mmoajuda.Text += "\tA documentação https://docs.pagamentobancario.com.br/#operation/updatePayer mostra como alterar dados de um pagador. Este recurso pode ser utilizado caso precise atualizar as informações como nome, e-mail, endereço e telefone dos pagadores cadastrados em nossa API." + "\r\n"; _ = Environment.NewLine;

        }

        private void jsonexemploconsultarconta_Click(object sender, EventArgs e)
        {
            mmoajuda.Text = String.Empty;
            mmoentrada.Text = String.Empty;

            mmoentrada.Text += "["; _ = Environment.NewLine;
            mmoentrada.Text += "{"; _ = Environment.NewLine;
            mmoentrada.Text += "bankCode: 001"; _ = Environment.NewLine;
            mmoentrada.Text += "agency: 1111"; _ = Environment.NewLine;
            mmoentrada.Text += "agencyDigit: "; _ = Environment.NewLine;
            mmoentrada.Text += "accountNumber: 0001"; _ = Environment.NewLine;
            mmoentrada.Text += "accountDac: 1"; _ = Environment.NewLine;
            mmoentrada.Text += "convenioAgency: "; _ = Environment.NewLine;
            mmoentrada.Text += "convenioNumber: 22"; _ = Environment.NewLine;
            mmoentrada.Text += "remessaSequential: 0"; _ = Environment.NewLine;
            mmoentrada.Text += "van: false"; _ = Environment.NewLine;
            mmoentrada.Text += "}"; _ = Environment.NewLine;
            mmoentrada.Text += "]"; _ = Environment.NewLine;

            mmoajuda.Text += "Listar contas" + "\r\n"; _ = Environment.NewLine;

            mmoajuda.Text += "\tA documentação https://docs.pagamentobancario.com.br/#operation/fetchAccount mostrará como efetuar a consulta de contas." + "\r\n"; _ = Environment.NewLine;

            mmoajuda.Text += "\tEste método retornará todas as contas cadastradas pelo pagador." + "\r\n"; _ = Environment.NewLine;

        }

        private void button7_Click(object sender, EventArgs e)
        {
            mmoajuda.Text = String.Empty;
            mmoentrada.Text = String.Empty;

            mmoentrada.Text += "{"; _ = Environment.NewLine;
            mmoentrada.Text += "bankCode: 001"; _ = Environment.NewLine;
            mmoentrada.Text += "agency: 1111"; _ = Environment.NewLine;
            mmoentrada.Text += "agencyDigit: "; _ = Environment.NewLine;
            mmoentrada.Text += "accountNumber: 0001"; _ = Environment.NewLine;
            mmoentrada.Text += "accountDac: 1"; _ = Environment.NewLine;
            mmoentrada.Text += "convenioAgency: "; _ = Environment.NewLine;
            mmoentrada.Text += "convenioNumber: 22"; _ = Environment.NewLine;
            mmoentrada.Text += "remessaSequential: 0"; _ = Environment.NewLine;
            mmoentrada.Text += "van: false"; _ = Environment.NewLine;
            mmoentrada.Text += "}"; _ = Environment.NewLine;

            mmoajuda.Text += "Atualizar conta" + "\r\n"; _ = Environment.NewLine;

            mmoajuda.Text += "\tA documentação https://docs.pagamentobancario.com.br/#operation/updateAccount mostrará como atualizar contas." + "\r\n"; _ = Environment.NewLine;

            mmoajuda.Text += "\tObservação:É possível atualizar um parâmetro por vez." + "\r\n"; _ = Environment.NewLine;
        }

        private void button29_Click(object sender, EventArgs e)
        {
            mmoajuda.Text = String.Empty;
            mmoentrada.Text = String.Empty;

            mmoentrada.Text += "accountHash: 8MsOxGFsZh"; _ = Environment.NewLine;
            mmoentrada.Text += "description: Pagamento de Boletos e Bloquetos"; _ = Environment.NewLine;
            mmoentrada.Text += "paymentForm: 30"; _ = Environment.NewLine;
            mmoentrada.Text += "nominalAmount: 1.5"; _ = Environment.NewLine;
            mmoentrada.Text += "paymentDate: 2019 - 09 - 20,"; _ = Environment.NewLine;
            mmoentrada.Text += "amount: 1.5,"; _ = Environment.NewLine;
            mmoentrada.Text += "barcode: 34193808200000001011090000366261234123451000"; _ = Environment.NewLine;
            mmoentrada.Text += "beneficiary: {"; _ = Environment.NewLine;
            mmoentrada.Text += "name: BENEFICIARIO TESTE"; _ = Environment.NewLine;
            mmoentrada.Text += "cpfCnpj: 13201437000135"; _ = Environment.NewLine;
            mmoentrada.Text += "}"; _ = Environment.NewLine;
            mmoentrada.Text += "dueDate: 2019 - 09 - 20"; _ = Environment.NewLine;
            mmoentrada.Text += "tag: ["; _ = Environment.NewLine;
            mmoentrada.Text += "teste"; _ = Environment.NewLine;
            mmoentrada.Text += "]"; _ = Environment.NewLine;
            mmoentrada.Text += "}"; _ = Environment.NewLine;

            mmoajuda.Text += "Títulos, concessionárias e tributos com código de barras" + "\r\n"; _ = Environment.NewLine;

            mmoajuda.Text += "\tNesta documentação https://docs.pagamentobancario.com.br/#operation/billetPayment iremos definir como será feita a geração de um pedido de pagamento de títulos, concessionárias e tributos através de boletos/bloquetos." + "\r\n"; _ = Environment.NewLine;

        }

        private void button27_Click(object sender, EventArgs e)
        {

            mmoajuda.Text = String.Empty;
            mmoentrada.Text = String.Empty;

            mmoentrada.Text += "accountHash: b8aKHR6tXS"; _ = Environment.NewLine;
            mmoentrada.Text += "paymentDate: 2019-11-12"; _ = Environment.NewLine;
            mmoentrada.Text += "dueDate: 2019-11-13"; _ = Environment.NewLine;
            mmoentrada.Text += "amount: 1.5"; _ = Environment.NewLine;
            mmoentrada.Text += "interestAmount: 0"; _ = Environment.NewLine;
            mmoentrada.Text += "discountAmount: 0"; _ = Environment.NewLine;
            mmoentrada.Text += "fineAmount: 0"; _ = Environment.NewLine;
            mmoentrada.Text += "paymentFor: 1"; _ = Environment.NewLine;
            mmoentrada.Text += "compensation: 1"; _ = Environment.NewLine;
            mmoentrada.Text += "beneficiary:"; _ = Environment.NewLine;
            mmoentrada.Text += "name: Teste Beneficiario"; _ = Environment.NewLine;
            mmoentrada.Text += "cpfCnpj: 38947633000184"; _ = Environment.NewLine;
            mmoentrada.Text += "bankCode: 001"; _ = Environment.NewLine;
            mmoentrada.Text += "agency: 1111"; _ = Environment.NewLine;
            mmoentrada.Text += "agencyDigit: 2"; _ = Environment.NewLine;
            mmoentrada.Text += "accountNumber: 3333"; _ = Environment.NewLine;
            mmoentrada.Text += "accountNumberDigit: 3"; _ = Environment.NewLine;
            mmoentrada.Text += "accountDac: 4"; _ = Environment.NewLine;
            mmoentrada.Text += "street: Rua Teste"; _ = Environment.NewLine;
            mmoentrada.Text += "neighborhood: Bairro Teste"; _ = Environment.NewLine;
            mmoentrada.Text += "addressNumber: 123"; _ = Environment.NewLine;
            mmoentrada.Text += "addressComplement: "; _ = Environment.NewLine;
            mmoentrada.Text += "city: Maringa"; _ = Environment.NewLine;
            mmoentrada.Text += "state: PR"; _ = Environment.NewLine;
            mmoentrada.Text += "zipcode: 87000000"; _ = Environment.NewLine;
            mmoentrada.Text += "accountType: 1"; _ = Environment.NewLine;
            mmoentrada.Text += "transferOptions: 01"; _ = Environment.NewLine;
            mmoentrada.Text += "}"; _ = Environment.NewLine;
            mmoentrada.Text += "tags:"; _ = Environment.NewLine;
            mmoentrada.Text += "string"; _ = Environment.NewLine;
            mmoentrada.Text += "]"; _ = Environment.NewLine;
            mmoentrada.Text += "}"; _ = Environment.NewLine;

            mmoajuda.Text += "Transferência bancária" + "\r\n"; _ = Environment.NewLine;

            mmoajuda.Text += "\tNa documentação https://docs.pagamentobancario.com.br/#operation/transferPayment iremos definir como será feita a geração de um pedido de pagamento via transferências bancárias." + "\r\n"; _ = Environment.NewLine;

                    }

        private void button25_Click(object sender, EventArgs e)
        {
            mmoajuda.Text = String.Empty;
            mmoentrada.Text = String.Empty;

            mmoentrada.Text += "accountHash: b8aKHR6tXS"; _ = Environment.NewLine;
            mmoentrada.Text += "paymentDate: 2019-11-12T00:00:00.000Z"; _ = Environment.NewLine;
            mmoentrada.Text += "amount:1.5"; _ = Environment.NewLine;
            mmoentrada.Text += "interestAmount: 0,"; _ = Environment.NewLine;
            mmoentrada.Text += "discountAmount: 0,"; _ = Environment.NewLine;
            mmoentrada.Text += "fineAmount: 0"; _ = Environment.NewLine;
            mmoentrada.Text += "beneficiary: {"; _ = Environment.NewLine;
            mmoentrada.Text += "name:"; _ = Environment.NewLine;
            mmoentrada.Text += "Teste Beneficiario"; _ = Environment.NewLine;
            mmoentrada.Text += "cpfCnpj 38947633000184"; _ = Environment.NewLine;
            mmoentrada.Text += "bankCode: 001"; _ = Environment.NewLine;
            mmoentrada.Text += "agency: 1111"; _ = Environment.NewLine;
            mmoentrada.Text += "agencyDigit: 2"; _ = Environment.NewLine;
            mmoentrada.Text += "accountNumber: 3333"; _ = Environment.NewLine;
            mmoentrada.Text += "accountNumberDigit: "; _ = Environment.NewLine;
            mmoentrada.Text += "accountDac: 4"; _ = Environment.NewLine;
            mmoentrada.Text += "neighborhood: Rua Teste"; _ = Environment.NewLine;
            mmoentrada.Text += "addressNumber: 123"; _ = Environment.NewLine;
            mmoentrada.Text += "addressComplement: "; _ = Environment.NewLine;
            mmoentrada.Text += "city: Maringa"; _ = Environment.NewLine;
            mmoentrada.Text += "state: PR"; _ = Environment.NewLine;
            mmoentrada.Text += "zipcode: 87000000"; _ = Environment.NewLine;
            mmoentrada.Text += "accountType: 1"; _ = Environment.NewLine;
            mmoentrada.Text += "transferOptions: 01"; _ = Environment.NewLine;
            mmoentrada.Text += "}"; _ = Environment.NewLine;
            mmoentrada.Text += "tags: ["; _ = Environment.NewLine;
            mmoentrada.Text += "string"; _ = Environment.NewLine;
            mmoentrada.Text += "]"; _ = Environment.NewLine;
            mmoentrada.Text += "}"; _ = Environment.NewLine;


            mmoajuda.Text += "Salários" + "\r\n"; _ = Environment.NewLine;

            mmoajuda.Text += "\tNa documentação https://docs.pagamentobancario.com.br/#operation/paycheckPayment iremos definir como será feita a geração de um pedido de pagamento de salários." + "\r\n"; _ = Environment.NewLine;


        }

        private void button23_Click(object sender, EventArgs e)
        {
            mmoajuda.Text = String.Empty;
            mmoentrada.Text = String.Empty;

            mmoentrada.Text += "{"; _ = Environment.NewLine;
            mmoentrada.Text += "accountHash: b8aKHR6tXS"; _ = Environment.NewLine;
            mmoentrada.Text += "revenueCode: 1234"; _ = Environment.NewLine;
            mmoentrada.Text += "paymentDate:2019-12-20"; _ = Environment.NewLine;
            mmoentrada.Text += "amount 1.5"; _ = Environment.NewLine;
            mmoentrada.Text += "description: Pagamento da GARE Teste"; _ = Environment.NewLine;
            mmoentrada.Text += "contributorDocument: 93848368005"; _ = Environment.NewLine;
            mmoentrada.Text += "dueDate:2019-12-20"; _ = Environment.NewLine;
            mmoentrada.Text += "stateRegistration: PR"; _ = Environment.NewLine;
            mmoentrada.Text += "activeDebit: 123"; _ = Environment.NewLine;
            mmoentrada.Text += "referencePeriod: 2019-12"; _ = Environment.NewLine;
            mmoentrada.Text += "installment: 01"; _ = Environment.NewLine;
            mmoentrada.Text += "interestAmount: 0"; _ = Environment.NewLine;
            mmoentrada.Text += "fineAmount: 0"; _ = Environment.NewLine;
            mmoentrada.Text += "nominalAmount: 1.5"; _ = Environment.NewLine;
            mmoentrada.Text += "tags: ["; _ = Environment.NewLine;
            mmoentrada.Text += "teste"; _ = Environment.NewLine;
            mmoentrada.Text += "]"; _ = Environment.NewLine;
            mmoentrada.Text += "}"; _ = Environment.NewLine;

            mmoajuda.Text += "Diversos" + "\r\n"; _ = Environment.NewLine;

            mmoajuda.Text += "\tNa documentação https://docs.pagamentobancario.com.br/#operation/garePayment iremos  definir como será feita a geração de um pedido de pagamento da GARE (Guia de Arrecadação da Receita Estadual)." + "\r\n"; _ = Environment.NewLine;

        }

        private void button13_Click(object sender, EventArgs e)
        {
            mmoajuda.Text = String.Empty;
            mmoentrada.Text = String.Empty;

            mmoentrada.Text += "{"; _ = Environment.NewLine;
            mmoentrada.Text += "accountHash: b8aKHR6tXS"; _ = Environment.NewLine;
            mmoentrada.Text += "revenueCode: 1234"; _ = Environment.NewLine;
            mmoentrada.Text += "paymentDate: 2019-12-20"; _ = Environment.NewLine;
            mmoentrada.Text += "contributorDocument: 93848368005"; _ = Environment.NewLine;
            mmoentrada.Text += "description: Teste de IPVA"; _ = Environment.NewLine;
            mmoentrada.Text += "nominalAmount: 1.5,"; _ = Environment.NewLine;
            mmoentrada.Text += "contributorName: João Teste"; _ = Environment.NewLine;
            mmoentrada.Text += "calculationYear: 2019"; _ = Environment.NewLine;
            mmoentrada.Text += "amount: 1.50"; _ = Environment.NewLine;
            mmoentrada.Text += "dueDate: 2019-12-20"; _ = Environment.NewLine;
            mmoentrada.Text += "municipalCode: 4115200"; _ = Environment.NewLine;
            mmoentrada.Text += "discountAmount: 0,"; _ = Environment.NewLine;
            mmoentrada.Text += "state: PR"; _ = Environment.NewLine;
            mmoentrada.Text += "vehiclePlates: AAA0000"; _ = Environment.NewLine;
            mmoentrada.Text += "paymentOption: 1,"; _ = Environment.NewLine;
            mmoentrada.Text += "vehicleRenavam: aaaaaaaaaa"; _ = Environment.NewLine;
            mmoentrada.Text += "CRVLWithdrawalOption: 1,"; _ = Environment.NewLine;
            mmoentrada.Text += "tags: ["; _ = Environment.NewLine;
            mmoentrada.Text += "teste"; _ = Environment.NewLine;
            mmoentrada.Text += "]"; _ = Environment.NewLine;
            mmoentrada.Text += "}"; _ = Environment.NewLine;

            mmoajuda.Text += "IPVA" + "\r\n"; _ = Environment.NewLine;

            mmoajuda.Text += "\tNa documentação https://docs.pagamentobancario.com.br/#operation/ipvaPayment definir como será feita a geração de um pedido de pagamento do IPVA." + "\r\n"; _ = Environment.NewLine;

        }

        private void button11_Click(object sender, EventArgs e)
        {
            {
                mmoajuda.Text = String.Empty;
                mmoentrada.Text = String.Empty;

                mmoentrada.Text += "accountHash: b8aKHR6tXS"; _ = Environment.NewLine;
                mmoentrada.Text += "paymentDate: 2019-12-20"; _ = Environment.NewLine;
                mmoentrada.Text += "contributorDocument: 93848368005"; _ = Environment.NewLine;
                mmoentrada.Text += "description: Teste de DPVAT"; _ = Environment.NewLine;
                mmoentrada.Text += "nominalAmount: 1.5"; _ = Environment.NewLine;
                mmoentrada.Text += "contributorName: João Teste"; _ = Environment.NewLine;
                mmoentrada.Text += "calculationYear: 2019"; _ = Environment.NewLine;
                mmoentrada.Text += "amount: 1.50"; _ = Environment.NewLine;
                mmoentrada.Text += "dueDate: 2019-12-20"; _ = Environment.NewLine;
                mmoentrada.Text += "municipalCode: 4115200"; _ = Environment.NewLine;
                mmoentrada.Text += "discountAmount: 0"; _ = Environment.NewLine;
                mmoentrada.Text += "state: PR"; _ = Environment.NewLine;
                mmoentrada.Text += "vehiclePlates: AAA0000"; _ = Environment.NewLine;
                mmoentrada.Text += "paymentOption: 1"; _ = Environment.NewLine;
                mmoentrada.Text += "vehicleRenavam: aaaaaaaaaa"; _ = Environment.NewLine;
                mmoentrada.Text += "CRVLWithdrawalOption: 1"; _ = Environment.NewLine;
                mmoentrada.Text += "tags: "; _ = Environment.NewLine;
                mmoentrada.Text += "teste"; _ = Environment.NewLine;
                mmoentrada.Text += "]"; _ = Environment.NewLine;
                mmoentrada.Text += "}"; _ = Environment.NewLine;

                mmoajuda.Text += "DPVAT" + "\r\n"; _ = Environment.NewLine;

                mmoajuda.Text += "\tNa documentação https://docs.pagamentobancario.com.br/#operation/dpvatPayment definir como será feita a geração de um pedido de pagamento do DPVAT." + "\r\n"; _ = Environment.NewLine;

            }
        }

        private void button9_Click(object sender, EventArgs e)
        {
            mmoajuda.Text = String.Empty;
            mmoentrada.Text = String.Empty;

            mmoentrada.Text += "{"; _ = Environment.NewLine;
            mmoentrada.Text += "accountHash: b8aKHR6tXS"; _ = Environment.NewLine;
            mmoentrada.Text += "revenueCode: 1234"; _ = Environment.NewLine;
            mmoentrada.Text += "referencePeriod: 2019-12"; _ = Environment.NewLine;
            mmoentrada.Text += "reportingPeriod: 2019-12-20"; _ = Environment.NewLine;
            mmoentrada.Text += "paymentDate: 2019-12-20"; _ = Environment.NewLine;
            mmoentrada.Text += "dueDate: 2019-12-20"; _ = Environment.NewLine;
            mmoentrada.Text += "description: Pagamento da DARF Teste"; _ = Environment.NewLine;
            mmoentrada.Text += "contributorDocument: 93848368005"; _ = Environment.NewLine;
            mmoentrada.Text += "contributorName: Teste homologacao"; _ = Environment.NewLine;
            mmoentrada.Text += "referenceNumber: 123"; _ = Environment.NewLine;
            mmoentrada.Text += "interestAmount: 1"; _ = Environment.NewLine;
            mmoentrada.Text += "fineAmount: 0"; _ = Environment.NewLine;
            mmoentrada.Text += "nominalAmount: 0"; _ = Environment.NewLine;
            mmoentrada.Text += "tags: ["; _ = Environment.NewLine;
            mmoentrada.Text += "teste"; _ = Environment.NewLine;
            mmoentrada.Text += "]"; _ = Environment.NewLine;
            mmoentrada.Text += "}"; _ = Environment.NewLine;


            mmoajuda.Text += "DARF" + "\r\n"; _ = Environment.NewLine;

            mmoajuda.Text += "\tNa documentação https://docs.pagamentobancario.com.br/#operation/darfPayment definir como será feita a geração de um pedido de pagamento da DARF.." + "\r\n"; _ = Environment.NewLine;

        }

        private void button15_Click(object sender, EventArgs e)
        {
            mmoajuda.Text = String.Empty;
            mmoentrada.Text = String.Empty;

            mmoentrada.Text += "{"; _ = Environment.NewLine;
            mmoentrada.Text += "accountHash: b8aKHR6tXS"; _ = Environment.NewLine;
            mmoentrada.Text += "revenueCode: 1234"; _ = Environment.NewLine;
            mmoentrada.Text += "contributorDocument: 93848368005"; _ = Environment.NewLine;
            mmoentrada.Text += "paymentDate: 2019-12-20"; _ = Environment.NewLine;
            mmoentrada.Text += "amount: 1.5"; _ = Environment.NewLine;
            mmoentrada.Text += "nominalAmount: 1.50"; _ = Environment.NewLine;
            mmoentrada.Text += "description: Teste GPS"; _ = Environment.NewLine;
            mmoentrada.Text += "referencePeriod: 122019"; _ = Environment.NewLine;
            mmoentrada.Text += "taxAmount: 0"; _ = Environment.NewLine;
            mmoentrada.Text += "otherAmount: 0"; _ = Environment.NewLine;
            mmoentrada.Text += "monetaryAdjustment: 0"; _ = Environment.NewLine;
            mmoentrada.Text += "tags: ["; _ = Environment.NewLine;
            mmoentrada.Text += "string"; _ = Environment.NewLine;
            mmoentrada.Text += "]"; _ = Environment.NewLine;
            mmoentrada.Text += "}"; _ = Environment.NewLine;

            mmoajuda.Text += "GPS" + "\r\n"; _ = Environment.NewLine;

            mmoajuda.Text += "\tNa documentação https://docs.pagamentobancario.com.br/#operation/gpsPayment definir como será feita a geração de um pedido de pagamento da GPS (Guia de previdência social)." + "\r\n"; _ = Environment.NewLine;

        }

        private void button17_Click(object sender, EventArgs e)
        {
            mmoajuda.Text = String.Empty;
            mmoentrada.Text = String.Empty;

            mmoentrada.Text += "{"; _ = Environment.NewLine;
            mmoentrada.Text += "accountHash: b8aKHR6tXS"; _ = Environment.NewLine;
            mmoentrada.Text += "paymentDate: 2019-11-12T00:00:00.000Z"; _ = Environment.NewLine;
            mmoentrada.Text += "paymentForm: 1"; _ = Environment.NewLine;
            mmoentrada.Text += "amount: 1.5"; _ = Environment.NewLine;
            mmoentrada.Text += "interestAmount: 0"; _ = Environment.NewLine;
            mmoentrada.Text += "discountAmount: 0"; _ = Environment.NewLine;
            mmoentrada.Text += "fineAmount: 0"; _ = Environment.NewLine;
            mmoentrada.Text += "beneficiary: {"; _ = Environment.NewLine;
            mmoentrada.Text += "name: Teste Beneficiario"; _ = Environment.NewLine;
            mmoentrada.Text += "cpfCnpj: 38947633000184"; _ = Environment.NewLine;
            mmoentrada.Text += "bankCode: 001"; _ = Environment.NewLine;
            mmoentrada.Text += "agency: 1111"; _ = Environment.NewLine;
            mmoentrada.Text += "agencyDigit: 2"; _ = Environment.NewLine;
            mmoentrada.Text += "accountNumber: 3333"; _ = Environment.NewLine;
            mmoentrada.Text += "accountNumberDigit: 3"; _ = Environment.NewLine;
            mmoentrada.Text += "accountDac: 4"; _ = Environment.NewLine;
            mmoentrada.Text += "neighborhood: Rua Teste"; _ = Environment.NewLine;
            mmoentrada.Text += "addressNumber: 123"; _ = Environment.NewLine;
            mmoentrada.Text += "addressComplement: "; _ = Environment.NewLine;
            mmoentrada.Text += "city: Maringa"; _ = Environment.NewLine;
            mmoentrada.Text += "state: PR"; _ = Environment.NewLine;
            mmoentrada.Text += "zipcode: 87000000"; _ = Environment.NewLine;
            mmoentrada.Text += "}"; _ = Environment.NewLine;
            mmoentrada.Text += "tags"; _ = Environment.NewLine;
            mmoentrada.Text += "string"; _ = Environment.NewLine;
            mmoentrada.Text += "]"; _ = Environment.NewLine;
            mmoentrada.Text += "}"; _ = Environment.NewLine;

            mmoajuda.Text += "Diversos" + "\r\n"; _ = Environment.NewLine;

            mmoajuda.Text += "\tNa documentação https://docs.pagamentobancario.com.br/#operation/variousPayment iremos definir como será feita a geração de um pedido de pagamento definido pelo banco como sendo do tipo Diversos." + "\r\n"; _ = Environment.NewLine;

        }

        private void button19_Click(object sender, EventArgs e)
        {

            mmoajuda.Text = String.Empty;
            mmoentrada.Text = String.Empty;

            mmoentrada.Text += "{"; _ = Environment.NewLine;
            mmoentrada.Text += "uniqueId: ML69WDCECY"; _ = Environment.NewLine;
            mmoentrada.Text += "status: CREATED"; _ = Environment.NewLine;
            mmoentrada.Text += "accountHash: Uy5JvSWmrt"; _ = Environment.NewLine;
            mmoentrada.Text += "paymentType: 0"; _ = Environment.NewLine;
            mmoentrada.Text += "description: teste"; _ = Environment.NewLine;
            mmoentrada.Text += "paymentForm: 30"; _ = Environment.NewLine;
            mmoentrada.Text += "beneficiary: {"; _ = Environment.NewLine;
            mmoentrada.Text += "name: BENEFICIARIO TESTE"; _ = Environment.NewLine;
            mmoentrada.Text += "cpfCnpj: 13201437000135"; _ = Environment.NewLine;
            mmoentrada.Text += "}"; _ = Environment.NewLine;
            mmoentrada.Text += "paymentDate: 2019-09-20T00:00:00.000Z"; _ = Environment.NewLine;
            mmoentrada.Text += "dueDate: 2019-09-20T00:00:00.000Z"; _ = Environment.NewLine;
            mmoentrada.Text += "amount: 1.01"; _ = Environment.NewLine;
            mmoentrada.Text += "nominalAmount: 1.01"; _ = Environment.NewLine;
            mmoentrada.Text += "barcode: 34191808500000001011090000366421234123451000"; _ = Environment.NewLine;
            mmoentrada.Text += "occurrences: [ ]"; _ = Environment.NewLine;
            mmoentrada.Text += "tags: [ ]"; _ = Environment.NewLine;
            mmoentrada.Text += "createdAt: 2019-11-11T19:16:15.486Z"; _ = Environment.NewLine;
            mmoentrada.Text += "updatedAt: 2019-11-11T19:16:15.486Z"; _ = Environment.NewLine;
            mmoentrada.Text += "}"; _ = Environment.NewLine;

            mmoajuda.Text += "Consultar os pagamentos gerados" + "\r\n"; _ = Environment.NewLine;

            mmoajuda.Text += "\tDepois de gerar os pagamentos, e obter o uniqueId, você pode consultar os pagamentos gerados para saber o resultado do processamento pela nossa API." + "\r\n"; _ = Environment.NewLine;
            mmoajuda.Text += "\tTambém, será por esta rota que você consultará os uniqueIds para saber qual o resultado do processamento dos boletos após serem conciliados pelo retorno gerado pelo banco." + "\r\n"; _ = Environment.NewLine;


        }

        private void button14_Click(object sender, EventArgs e)
        {
            mmoajuda.Text = String.Empty;
            mmoentrada.Text = String.Empty;

            mmoentrada.Text += "{"; _ = Environment.NewLine;
            mmoentrada.Text += "payments: ["; _ = Environment.NewLine;
            mmoentrada.Text += "_Q-DZBEDMN"; _ = Environment.NewLine;
            mmoentrada.Text += "]"; _ = Environment.NewLine;
            mmoentrada.Text += "}"; _ = Environment.NewLine;

            mmoajuda.Text += "Gerar remessa" + "\r\n"; _ = Environment.NewLine;

            mmoajuda.Text += "\tApós gerar os pagamento e obter os uniqueIds, é hora de fazer a Solicitação da Remessa." + "\r\n"; _ = Environment.NewLine;
            mmoajuda.Text += "\tO processo de solicitação da remessa acontece de forma assíncrona. Ou seja, neste passo você irá solicitar a remessa e receberá um protocolo (uniqueId) referente à esta solicitação." + "\r\n"; _ = Environment.NewLine;
            mmoajuda.Text += "\tNo passo seguinte, você fará a consulta deste protocolo." + "\r\n"; _ = Environment.NewLine;
            mmoajuda.Text += "\tÉ importante lembrar que a correta geração da remessa e sua aceitação pelo banco é o que garante que os pagamentos serão efetivados com sucesso!" + "\r\n"; _ = Environment.NewLine;

        }

        private void button10_Click_1(object sender, EventArgs e)
        {
            mmoajuda.Text = String.Empty;
            mmoentrada.Text = String.Empty;

            mmoentrada.Text += "{"; _ = Environment.NewLine;
            mmoentrada.Text += "status: PROCESSED"; _ = Environment.NewLine;
            mmoentrada.Text += "remittanceType: DEFAULT"; _ = Environment.NewLine;
            mmoentrada.Text += "payments: ["; _ = Environment.NewLine;
            mmoentrada.Text += "{ }"; _ = Environment.NewLine;
            mmoentrada.Text += "]"; _ = Environment.NewLine;
            mmoentrada.Text += "content: <<<Base64 com o conteúdo da remessa>>"; _ = Environment.NewLine;


            mmoajuda.Text += "Consultar remessa" + "\r\n"; _ = Environment.NewLine;

            mmoajuda.Text += "\tDepois de fazer a solicitação da remessa, é hora de obtermos o arquivo de remessa que será encaminhado ao banco!" + "\r\n"; _ = Environment.NewLine;
            mmoajuda.Text += "\tNesta rota nós iremos consulta o uniqueId (protocolo) que obtivemos na rota POST, onde a remessa foi solicitada." + "\r\n"; _ = Environment.NewLine;
         

        }

        private void button21_Click(object sender, EventArgs e)
        {
            mmoajuda.Text = String.Empty;
            mmoentrada.Text = String.Empty;

            mmoentrada.Text += "{"; _ = Environment.NewLine;
            mmoentrada.Text += "uniqueId: Fhvozgeb1r"; _ = Environment.NewLine;
            mmoentrada.Text += "status: PROCESSING"; _ = Environment.NewLine;
            mmoentrada.Text += "createdAt: 2019-11-11T17:05:15.415Z"; _ = Environment.NewLine;
            mmoentrada.Text += "updatedAt: 2019-11-11T17:05:15.415Z"; _ = Environment.NewLine;
            mmoentrada.Text += " }"; _ = Environment.NewLine;

            mmoajuda.Text += "Enviar arquivo de retorno" + "\r\n"; _ = Environment.NewLine;

            mmoajuda.Text += "\tApós ocorrer o processamento da remessa pelo banco, o banco gera o arquivo de retorno contendo as informações referentes ao processamento da remessa. A confirmação do pagamento ou eventuais mensagens de erros estarão presentes neste arquivo." + "\r\n"; _ = Environment.NewLine;
            mmoajuda.Text += "\tNesta rota definiremos como enviar o arquivo de retorno para a nossa API e posteriormente, como consultar o protocolo referente a esta conciliação." + "\r\n"; _ = Environment.NewLine;
            mmoajuda.Text += "\tObs.: Esta rotina não precisa ser implementada caso você opte por utilizar a transmissão automática das remessas e retornos, pois, o recebimento dos retornos ocorrerá de forma automática por nossa API." + "\r\n"; _ = Environment.NewLine;


        }

        private void button16_Click(object sender, EventArgs e)
        {
            mmoajuda.Text = String.Empty;
            mmoentrada.Text = String.Empty;

            mmoentrada.Text += "{"; _ = Environment.NewLine;
            mmoentrada.Text += "uniqueId: d_SjlYdXl9"; _ = Environment.NewLine;
            mmoentrada.Text += "status: PROCESSED"; _ = Environment.NewLine;
            mmoentrada.Text += "accountHash: nzWPzYCdmo"; _ = Environment.NewLine;
            mmoentrada.Text += "reason:"; _ = Environment.NewLine;
            mmoentrada.Text += "payments: ["; _ = Environment.NewLine;
            mmoentrada.Text += "{ }"; _ = Environment.NewLine;
            mmoentrada.Text += "]"; _ = Environment.NewLine;
            mmoentrada.Text += "}"; _ = Environment.NewLine;

            mmoajuda.Text += "Consultar arquivo de retorno" + "\r\n"; _ = Environment.NewLine;

            mmoajuda.Text += "\tDepois de fazer a solicitação do envio do retorno no passo anterior, é hora de obtermos o resultado do processamento deste arquivo." + "\r\n"; _ = Environment.NewLine;
            mmoajuda.Text += "\tNesta rota nós iremos consulta o uniqueId (protocolo) que obtivemos na rota POST, onde o retorno foi enviado." + "\r\n"; _ = Environment.NewLine;
        }

        private void button24_Click(object sender, EventArgs e)
        {
            mmoajuda.Text = String.Empty;
            mmoentrada.Text = String.Empty;

            mmoentrada.Text += "{"; _ = Environment.NewLine;
            mmoentrada.Text += "payments: ["; _ = Environment.NewLine;
            mmoentrada.Text += "_Q-DZBEDMN"; _ = Environment.NewLine;
            mmoentrada.Text += "SD85ZBCSMN"; _ = Environment.NewLine;
            mmoentrada.Text += "]"; _ = Environment.NewLine;
            mmoentrada.Text += "}"; _ = Environment.NewLine;
        }

        private void button20_Click_2(object sender, EventArgs e)
        {
            mmoajuda.Text = String.Empty;
            mmoentrada.Text = String.Empty;

            mmoentrada.Text += "{"; _ = Environment.NewLine;
            mmoentrada.Text += "uniqueId: ATiGxW_nA97h2_xuTObXU"; _ = Environment.NewLine;
            mmoentrada.Text += "status: PROCESSING"; _ = Environment.NewLine;
            mmoentrada.Text += "payments: ["; _ = Environment.NewLine;
            mmoentrada.Text += "{ }"; _ = Environment.NewLine;
            mmoentrada.Text += "]"; _ = Environment.NewLine;
            mmoentrada.Text += "}"; _ = Environment.NewLine;

            mmoajuda.Text += "Consultar comprovante de pagamento" + "\r\n"; _ = Environment.NewLine;

            mmoajuda.Text += "\tDepois de fazer a solicitação do comprovante de pagamento, é hora de realizarmos o download do comprovante!" + "\r\n"; _ = Environment.NewLine;
            mmoajuda.Text += "\tNesta rota, nós iremos consultar o uniqueId (protocolo) que obtivemos na rota POST, em que o comprovante foi solicitado." + "\r\n"; _ = Environment.NewLine;
            mmoajuda.Text += "\tEm caso de sucesso, o resultado da consulta será um Buffer contendo o arquivo PDF." + "\r\n"; _ = Environment.NewLine;

        }

        private void tabpagnotificacao_Click(object sender, EventArgs e)
        {

        }

        private void button12_Click(object sender, EventArgs e)
        {
            mmoajuda.Text = String.Empty;
            mmoentrada.Text = String.Empty;

            mmoentrada.Text += "{"; _ = Environment.NewLine;
            mmoentrada.Text += "status: string"; _ = Environment.NewLine;
            mmoentrada.Text += "message: string"; _ = Environment.NewLine;
            mmoentrada.Text += "cnpjsh: string"; _ = Environment.NewLine;
            mmoentrada.Text += "totalPayments: 0,"; _ = Environment.NewLine;
            mmoentrada.Text += "totalVan: 0,"; _ = Environment.NewLine;
            mmoentrada.Text += "payers: ["; _ = Environment.NewLine;
            mmoentrada.Text += "{ }"; _ = Environment.NewLine;
            mmoentrada.Text += "]"; _ = Environment.NewLine;
            mmoentrada.Text += "}"; _ = Environment.NewLine;

            mmoajuda.Text += "Consulta de bilhetagem" + "\r\n"; _ = Environment.NewLine;

            mmoajuda.Text += "\tNesta rota, obteremos o resumo de todos os pagamentos gerados pela Software House no período solicitado" + "\r\n"; _ = Environment.NewLine;
        
        }

        private void button32_Click(object sender, EventArgs e)
        {
            mmoajuda.Text = String.Empty;
            mmoentrada.Text = String.Empty;

            mmoentrada.Text += "{"; _ = Environment.NewLine;
            mmoentrada.Text += "type: webhook"; _ = Environment.NewLine;
            mmoentrada.Text += "happen: ["; _ = Environment.NewLine;
            mmoentrada.Text += "CREATED"; _ = Environment.NewLine;
            mmoentrada.Text += "PAID"; _ = Environment.NewLine;
            mmoentrada.Text += "SCHEDULED"; _ = Environment.NewLine;
            mmoentrada.Text += "CANCELLED"; _ = Environment.NewLine;
            mmoentrada.Text += "REJECTED"; _ = Environment.NewLine;
            mmoentrada.Text += "REFUNDED"; _ = Environment.NewLine;
            mmoentrada.Text += "]"; _ = Environment.NewLine;
            mmoentrada.Text += "url: https://seusite.com.br"; _ = Environment.NewLine;
            mmoentrada.Text += "headers: {"; _ = Environment.NewLine;
            mmoentrada.Text += "login: exemplo"; _ = Environment.NewLine;
            mmoentrada.Text += "token: exemplo"; _ = Environment.NewLine;
            mmoentrada.Text += "}"; _ = Environment.NewLine;
            mmoentrada.Text += "}"; _ = Environment.NewLine;

            mmoajuda.Text += "Criar notificação" + "\r\n"; _ = Environment.NewLine;

            mmoajuda.Text += "\tA documentação https://docs.pagamentobancario.com.br/#operation/createNotification mostrará como criar notificações." + "\r\n"; _ = Environment.NewLine;

        }

        private void button30_Click(object sender, EventArgs e)
        {
            mmoajuda.Text = String.Empty;
            mmoentrada.Text = String.Empty;

            mmoentrada.Text += "{"; _ = Environment.NewLine;
            mmoentrada.Text += "notification: ["; _ = Environment.NewLine;
            mmoentrada.Text += "{ }"; _ = Environment.NewLine;
            mmoentrada.Text += "]"; _ = Environment.NewLine;
            mmoentrada.Text += "}"; _ = Environment.NewLine;


            mmoajuda.Text += "Listar notificações" + "\r\n"; _ = Environment.NewLine;

            mmoajuda.Text += "\tA documentação https://docs.pagamentobancario.com.br/#operation/fetchNotification mostrará como consultar notificações" + "\r\n"; _ = Environment.NewLine;

        }

        private void button18_Click(object sender, EventArgs e)
        {
            mmoajuda.Text = String.Empty;
            mmoentrada.Text = String.Empty;

            mmoentrada.Text += "{"; _ = Environment.NewLine;
            mmoentrada.Text += "uniqueId: XXXXXX"; _ = Environment.NewLine;
            mmoentrada.Text += "type: webhook"; _ = Environment.NewLine;
            mmoentrada.Text += "happen: ["; _ = Environment.NewLine;
            mmoentrada.Text += "CREATED"; _ = Environment.NewLine;
            mmoentrada.Text += "PAID"; _ = Environment.NewLine;
            mmoentrada.Text += "]"; _ = Environment.NewLine;
            mmoentrada.Text += "url: https://seusite.com.br"; _ = Environment.NewLine;
            mmoentrada.Text += "}"; _ = Environment.NewLine;

            mmoajuda.Text += "Atualizar notificação" + "\r\n"; _ = Environment.NewLine;

            mmoajuda.Text += "\tA documentação https://docs.pagamentobancario.com.br/#operation/fetchNotification mostrará como atualizar notificações" + "\r\n"; _ = Environment.NewLine;

        }

        private void button28_Click_2(object sender, EventArgs e)
        {
            mmoajuda.Text = String.Empty;
            mmoentrada.Text = String.Empty;

            mmoentrada.Text += "{"; _ = Environment.NewLine;
            mmoentrada.Text += "uniqueId: string"; _ = Environment.NewLine;
            mmoentrada.Text += "bankStatement: {"; _ = Environment.NewLine;
            mmoentrada.Text += "bankCode: string"; _ = Environment.NewLine;
            mmoentrada.Text += "bank: string"; _ = Environment.NewLine;
            mmoentrada.Text += "currency: string"; _ = Environment.NewLine;
            mmoentrada.Text += "balance: 0,"; _ = Environment.NewLine;
            mmoentrada.Text += "date: 2019-08-24"; _ = Environment.NewLine;
            mmoentrada.Text += "type: string"; _ = Environment.NewLine;
            mmoentrada.Text += "totalTransactions: 0"; _ = Environment.NewLine;
            mmoentrada.Text += "}"; _ = Environment.NewLine;
            mmoentrada.Text += "transactions: {"; _ = Environment.NewLine;
            mmoentrada.Text += "uniqueId: string"; _ = Environment.NewLine;
            mmoentrada.Text += "}"; _ = Environment.NewLine;
            mmoentrada.Text += "}"; _ = Environment.NewLine;
        }

        private void button22_Click(object sender, EventArgs e)
        {
            mmoajuda.Text = String.Empty;
            mmoentrada.Text = String.Empty;

            mmoentrada.Text += "{"; _ = Environment.NewLine;
            mmoentrada.Text += "bankStatement: {"; _ = Environment.NewLine;
            mmoentrada.Text += "bankCode: 341"; _ = Environment.NewLine;
            mmoentrada.Text += "bank: BANCO ITAU S/A"; _ = Environment.NewLine;
            mmoentrada.Text += "currency: BRL"; _ = Environment.NewLine;
            mmoentrada.Text += "balance: 100,"; _ = Environment.NewLine;
            mmoentrada.Text += "date: 2020-01-01"; _ = Environment.NewLine;
            mmoentrada.Text += "type: ofx"; _ = Environment.NewLine;
            mmoentrada.Text += "totalTransactions: 4,"; _ = Environment.NewLine;
            mmoentrada.Text += "accountHash: xxxxx"; _ = Environment.NewLine;
            mmoentrada.Text += "},"; _ = Environment.NewLine;
            mmoentrada.Text += "transactions: {"; _ = Environment.NewLine;
            mmoentrada.Text += "credit: [],"; _ = Environment.NewLine;
            mmoentrada.Text += "debit: []"; _ = Environment.NewLine;
            mmoentrada.Text += "}"; _ = Environment.NewLine;
            mmoentrada.Text += "}"; _ = Environment.NewLine;
        }

        private void label21_Click(object sender, EventArgs e)
        {

        }

        private void tabcontas_Click(object sender, EventArgs e)
        {

        }

        private void label26_Click(object sender, EventArgs e)
        {

        }

        private void label41_Click(object sender, EventArgs e)
        {

        }

        private void label26_Click_1(object sender, EventArgs e)
        {

        }

        private void label42_Click(object sender, EventArgs e)
        {

        }
    }
}