<?php
include_once("addComponente.php");
try {
    $dia = date("d");
    $mes = date("m");
    $ano = date("Y");
    $dataAtual = $dia . "/" . $mes . "/" . $ano;
    if ($mes == 11) {
        $mes = 01;
        $ano = $ano + 1;
    } elseif ($mes == 12) {
        $mes = 02;
        $ano = $ano + 1;
    } else {
        $mes = $mes + 2;
    }

    $curl = curl_init();
    curl_setopt_array($curl, array(
        CURLOPT_URL => "https://staging.pagamentobancario.com.br/api/v1/payment/taxes/gps",
        CURLOPT_CUSTOMREQUEST => "POST",
        CURLOPT_SSL_VERIFYPEER => 0,
        CURLOPT_SSL_VERIFYHOST => 0,
        CURLOPT_HTTPHEADER => array(
            "CNPJSH: $CNPJSH",
            "tokenSh: $tokenSh",
            "content-type: application/json",
            "payercpfcnpj: $payercpfcnpj",
        ),
        CURLOPT_POSTFIELDS => "[{ \r\n  \"accountHash\": \"b8aKHR6tXS\",\r\n  \"revenueCode\": \"1234\",\r\n  \"contributorDocument\":\"93848368005\",\r\n  \"paymentDate\": \"2019-12-20\",\r\n \"amount\": \"1.5\",\r\n  \"nominalAmount\": \"1.5\",\r\n  \"description\": \"Teste GPS\",\r\n\r\n    \"referencePeriod\": \"122019\",\r\n  \"taxAmount\": \"0\",\r\n  \"otherAmount\": \"0\",\r\n} \"otherAmount\": \"0\",\r\n \"monetaryAdjustment\": \"0\",\r\n}][{ \r\n  \"accountHash\": \"b8aKHR6tXS\",\r\n  \"revenueCode\": \"1234\",\r\n  \"contributorDocument\":\"93848368005\",\r\n  \"paymentDate\": \"2019-12-20\",\r\n \"amount\": \"1.5\",\r\n  \"nominalAmount\": \"1.5\",\r\n  \"description\": \"Teste GPS\",\r\n\r\n    \"referencePeriod\": \"122019\",\r\n  \"taxAmount\": \"0\",\r\n  \"otherAmount\": \"0\",\r\n} \"otherAmount\": \"0\",\r\n \"monetaryAdjustment\": \"0\",\r\n}]",
        CURLOPT_TIMEOUT => 30,
        CURLOPT_RETURNTRANSFER => true
    ));

    $response = curl_exec($curl);
    $err = curl_error($curl);
    curl_close($curl);

} catch (Exception $e) {
    echo $e;
}