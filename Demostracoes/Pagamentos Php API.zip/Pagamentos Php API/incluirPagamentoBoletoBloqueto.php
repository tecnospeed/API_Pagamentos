<?php
include_once("addComponente.php");
try {
    $dia = date("d");
    $mes = date("m");
    $ano = date("Y");
    $dataAtual = $dia . "/" . $mes . "/" . $ano;
    if ($mes == 11) {
        $mes = 01;
        $ano = $ano + 1;
    } elseif ($mes == 12) {
        $mes = 02;
        $ano = $ano + 1;
    } else {
        $mes = $mes + 2;
    }

    $curl = curl_init();
    curl_setopt_array($curl, array(
        CURLOPT_URL => "https://staging.pagamentobancario.com.br/api/v1/payment/billet",
        CURLOPT_CUSTOMREQUEST => "POST",
        CURLOPT_SSL_VERIFYPEER => 0,
        CURLOPT_SSL_VERIFYHOST => 0,
        CURLOPT_HTTPHEADER => array(
            "CNPJSH: $CNPJSH",
            "tokenSh: $tokenSh",
            "content-type: application/json",
            "payercpfcnpj: $payercpfcnpj",
        ),
        CURLOPT_POSTFIELDS => "[{ \r\n  \"accountHash\": \"b8aKHR6tXS\",\r\n  \"description\": \"Pagamento de Boletos e Bloquetos\",\r\n  \"paymentForm\":\"30\",\r\n  \"nominalAmount\": \"1.5\",\r\n  \"ourNumber\": \"1002\",\r\n  \"paymentDate\": \"2019-09-20\",\r\n  \"Amount\": \"1.5\",\r\n  \"barcode\": \"34193808200000001011090000366261234123451000\",\r\n  \"beneficiary": {\"name\": \"Teste Beneficiario\",\r\n  \"cpfCnpj\": \"38947633000184\",\r\n} \"dueDate\": \"2019-09-20\",\r\n]]",
        CURLOPT_TIMEOUT => 30,
        CURLOPT_RETURNTRANSFER => true
    ));

    $response = curl_exec($curl);
    $err = curl_error($curl);
    curl_close($curl);

} catch (Exception $e) {
    echo $e;
}