<?php
include_once("addComponente.php");
try {
    $dia = date("d");
    $mes = date("m");
    $ano = date("Y");
    $dataAtual = $dia . "/" . $mes . "/" . $ano;
    if ($mes == 11) {
        $mes = 01;
        $ano = $ano + 1;
    } elseif ($mes == 12) {
        $mes = 02;
        $ano = $ano + 1;
    } else {
        $mes = $mes + 2;
    }

    $curl = curl_init();
    curl_setopt_array($curl, array(
        CURLOPT_URL => "https://staging.pagamentobancario.com.br/api/v1/payment/taxes/ipva",
        CURLOPT_CUSTOMREQUEST => "POST",
        CURLOPT_SSL_VERIFYPEER => 0,
        CURLOPT_SSL_VERIFYHOST => 0,
        CURLOPT_HTTPHEADER => array(
            "CNPJSH: $CNPJSH",
            "tokenSh: $tokenSh",
            "content-type: application/json",
            "payercpfcnpj: $payercpfcnpj",
        ),
        CURLOPT_POSTFIELDS => "[{ \r\n  \"accountHash\": \"b8aKHR6tXS\",\r\n \"paymentDate\": \"2019-12-20\",\r\n \"contributorDocument\":\"93848368005\",\r\n  \"description\": \"Teste de DPVAT\",\r\n \"nominalAmount\": \"1.50\",\r\n \"contributorName\":\"João Teste\",\r\n \"calculationYear\": \"2019\",\r\n \"amount\": \"1.50\",\r\n  \"dueDate\": \"2019-12-20\",\r\n \"municipalCode\":\"4115200\",\r\n  \"discountAmount\": \"0\",\r\n  \"state\": \"PR\",\r\n  \"vehiclePlates\": \"AAA0000\",\r\n \"paymentOption\": \"1\",\r\n \"vehicleRenavam\": \"aaaaaaaaaa\",\r\n \"CRVLWithdrawalOption\": \"1\",\r\n }]",
        CURLOPT_TIMEOUT => 30,
        CURLOPT_RETURNTRANSFER => true
    ));

    $response = curl_exec($curl);
    $err = curl_error($curl);
    curl_close($curl);

} catch (Exception $e) {
    echo $e;
}