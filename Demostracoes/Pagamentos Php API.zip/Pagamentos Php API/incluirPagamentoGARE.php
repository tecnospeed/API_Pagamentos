<?php
include_once("addComponente.php");
try {
    $dia = date("d");
    $mes = date("m");
    $ano = date("Y");
    $dataAtual = $dia . "/" . $mes . "/" . $ano;
    if ($mes == 11) {
        $mes = 01;
        $ano = $ano + 1;
    } elseif ($mes == 12) {
        $mes = 02;
        $ano = $ano + 1;
    } else {
        $mes = $mes + 2;
    }

    $curl = curl_init();
    curl_setopt_array($curl, array(
        CURLOPT_URL => "https://staging.pagamentobancario.com.br/api/v1/payment/taxes/gare",
        CURLOPT_CUSTOMREQUEST => "POST",
        CURLOPT_SSL_VERIFYPEER => 0,
        CURLOPT_SSL_VERIFYHOST => 0,
        CURLOPT_HTTPHEADER => array(
            "CNPJSH: $CNPJSH",
            "tokenSh: $tokenSh",
            "content-type: application/json",
            "payercpfcnpj: $payercpfcnpj",
        ),
        CURLOPT_POSTFIELDS => "[{ \r\n  \"accountHash\": \"b8aKHR6tXS\",\r\n \"revenueCode\": \"1234\",\r\n \"paymentDate\": \"2019-12-20\",\r\n \"amount\": \"1.50\",\r\n \"description\": \"Pagamento da GARE Teste\",\r\n \"contributorDocument\":\"93848368005\",\r\n \"dueDate\": \"2019-12-20\",\r\n \"stateRegistration\": \"PR\",\r\n \"activeDebit\":\"123\",\r\n \"referencePeriod\": \"2019-12\",\r\n \"installment\":\"01\",\r\n \"interestAmount\": \"0\",\r\n  \"fineAmount\": \"0\",\r\n  \"nominalAmount\": \"1.50\",\r\n }]",
        CURLOPT_TIMEOUT => 30,
        CURLOPT_RETURNTRANSFER => true
    ));

    $response = curl_exec($curl);
    $err = curl_error($curl);
    curl_close($curl);

} catch (Exception $e) {
    echo $e;
}