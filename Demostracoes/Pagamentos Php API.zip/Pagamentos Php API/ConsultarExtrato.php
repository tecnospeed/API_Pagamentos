<?php
include_once("addComponente.php");
try {
    $protocoloExtrato = $_POST['protExtrato'];
    $curl = curl_init();
    curl_setopt_array($curl, array(
        CURLOPT_URL => "https://staging.pagamentobancario.com.br/api/v1/statement/parser${protocoloExtrato}",
        CURLOPT_CUSTOMREQUEST => "GET",
        CURLOPT_SSL_VERIFYPEER => 0,
        CURLOPT_SSL_VERIFYHOST => 0,
        CURLOPT_HTTPHEADER => array(
            "CNPJSH: $CNPJSH",
            "tokenSh: $tokenSh",
            "content-type: application/json",
            "payercpfcnpj: $payercpfcnpj",
        ),
        CURLOPT_RETURNTRANSFER => true        
    ));
    $response = curl_exec($curl);
    $err = curl_error($curl);
    curl_close($curl);
    if ($err) {
        echo "cURL Error #:" . $err;
    } else {
        echo prettyPrint($response);
    }
} catch (Exception $e) {
    echo $e;
}