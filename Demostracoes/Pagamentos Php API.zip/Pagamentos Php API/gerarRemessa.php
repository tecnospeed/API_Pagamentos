<?php
include_once("addComponente.php");
try {
    $id = $_POST['idGerarRemessa'];
    $curl = curl_init();
    curl_setopt_array($curl, array(
        CURLOPT_URL => "https://staging.pagamentobancario.com.br/api/v1/remittance",
        CURLOPT_CUSTOMREQUEST => "POST",
        CURLOPT_SSL_VERIFYPEER => 0,
        CURLOPT_SSL_VERIFYHOST => 0,
        CURLOPT_HTTPHEADER => array(
            "CNPJSH: $CNPJSH",
            "tokenSh: $tokenSh",
            "content-type: application/json",
            "payercpfcnpj: $payercpfcnpj",
        ),
        CURLOPT_POSTFIELDS => "{\r\n  \"payments\": [{$id}]}"]",
        CURLOPT_RETURNTRANSFER => true
    ));
    $response = curl_exec($curl);
    $err = curl_error($curl);
    curl_close($curl);
    if ($err) {
        echo "cURL Error #:" . $err;
    } else {
        echo prettyPrint($response);
    }
} catch (Exception $e) {
    echo $e;
}