<?php
include_once("addComponente.php");
try {
    $dia = date("d");
    $mes = date("m");
    $ano = date("Y");
    $dataAtual = $dia . "/" . $mes . "/" . $ano;
    if ($mes == 11) {
        $mes = 01;
        $ano = $ano + 1;
    } elseif ($mes == 12) {
        $mes = 02;
        $ano = $ano + 1;
    } else {
        $mes = $mes + 2;
    }

    $curl = curl_init();
    curl_setopt_array($curl, array(
        CURLOPT_URL => "https://staging.pagamentobancario.com.br/api/v1/payment/billet",
        CURLOPT_CUSTOMREQUEST => "POST",
        CURLOPT_SSL_VERIFYPEER => 0,
        CURLOPT_SSL_VERIFYHOST => 0,
        CURLOPT_HTTPHEADER => array(
            "CNPJSH: $CNPJSH",
            "tokenSh: $tokenSh",
            "content-type: application/json",
            "payercpfcnpj: $payercpfcnpj",
        ),
        CURLOPT_POSTFIELDS => "[{ \r\n  \"accountHash\": \"b8aKHR6tXS\",\r\n  \"description\": \"Pagamento de Boletos e Bloquetos\",\r\n  \"paymentForm\":\"30\",\r\n  \"nominalAmount\": \"1.5\",\r\n  \"ourNumber\": \"1002\",\r\n  \"paymentDate\": \"2019-09-20\",\r\n  \"Amount\": \"1.5\",\r\n  \"barcode\": \"34193808200000001011090000366261234123451000\",\r\n  \"beneficiary": {\"name\": \"Teste Beneficiario\",\r\n  \"cpfCnpj\": \"38947633000184\",\r\n} \"dueDate\": \"2019-09-20\",\r\n]]",
        CURLOPT_TIMEOUT => 30,
        CURLOPT_RETURNTRANSFER => true
    ));

    $response = curl_exec($curl);
    $err = curl_error($curl);
    curl_close($curl);

} catch (Exception $e) {
    echo $e;
}<?php
include_once("addComponente.php");
try {
    $dia = date("d");
    $mes = date("m");
    $ano = date("Y");
    $dataAtual = $dia . "/" . $mes . "/" . $ano;
    if ($mes == 11) {
        $mes = 01;
        $ano = $ano + 1;
    } elseif ($mes == 12) {
        $mes = 02;
        $ano = $ano + 1;
    } else {
        $mes = $mes + 2;
    }

    $curl = curl_init();
    curl_setopt_array($curl, array(
        CURLOPT_URL => "https://staging.pagamentobancario.com.br/api/v1/payment/paycheck",
        CURLOPT_CUSTOMREQUEST => "POST",
        CURLOPT_SSL_VERIFYPEER => 0,
        CURLOPT_SSL_VERIFYHOST => 0,
        CURLOPT_HTTPHEADER => array(
            "CNPJSH: $CNPJSH",
            "tokenSh: $tokenSh",
            "content-type: application/json",
            "payercpfcnpj: $payercpfcnpj",
        ),
        CURLOPT_POSTFIELDS => "[{ \r\n  \"accountHash\": \"b8aKHR6tXS\",\r\n  \"paymentDate\": \"2019-11-12\",\r\n  \"dueDate\":\"2019-11-13\",\r\n  \"amount\": \"1.5\",\r\n  \"interestAmount\": \"0\",\r\n  \"discountAmount\": \"0\",\r\n  \"fineAmount\": \"0\",\r\n  \"paymentForm\": \"1\",\r\n  \"compensation\": \"1\",\r\n  \"beneficiary": {\"name\": \"Teste Beneficiario\",\r\n  \"cpfCnpj\": \"38947633000184\",\r\n  \"bankCode\": \"001\",\r\n  \"agency\": \"1111\",\r\n  \"agencyDigit\": \"2\",\r\n  \"accountNumber\": \"3333\",\r\n  \"accountNumberDigit\": \"3\",\r\n  \"accountDac\": \"4\",\r\n  \"neighborhood\": \"Rua Teste\",\r\n  \"addressNumber\": \"123\",\r\n  \"addressComplement\": \"\",\r\n  \"city\": \"Maringa\",\r\n  \"state\": \"PR\", \r\n  \"zipcode\": \"87000000\",\r\n  \"accountType\": \"1\",\r\n  \"transferOptions\": \"01\"}]",
        CURLOPT_TIMEOUT => 30,
        CURLOPT_RETURNTRANSFER => true
    ));

    $response = curl_exec($curl);
    $err = curl_error($curl);
    curl_close($curl);

} catch (Exception $e) {
    echo $e;
}