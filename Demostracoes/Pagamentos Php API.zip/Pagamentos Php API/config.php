<?php
$url = "http://localhost/PhpApi/"; 
$DirArq = 'Portable-Files/'; 

error_reporting(E_ERROR | E_PARSE); //Remove os notices do php
