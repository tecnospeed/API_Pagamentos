<?php

// Inclui o arquivo com a definição do header
require '/home/eduardomontanhole/PROJETOS/DEMO PAGAMENTOS PHP/header.php';

$url = "https://staging.pagamentobancario.com.br/api/v1/account";

$data = array(
    [
    "bankCode" => "341",
    "agency" => "1112",
    "agencyDigit" => "",
    "accountNumber" => "123456",
    "accountNumberDigit" => "",
    "accountDac" => "3",
    "convenioNumber" => "456789",
    "remessaSequential" => "1"
    ]
);

$payload = json_encode($data); // Converte o array em uma string JSON

$curl = curl_init();

curl_setopt_array($curl, array(
    CURLOPT_URL => $url,
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_ENCODING => "",
    CURLOPT_MAXREDIRS => 10,
    CURLOPT_TIMEOUT => 30,
    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
    CURLOPT_CUSTOMREQUEST => "POST",
    CURLOPT_POSTFIELDS => $payload, // Envia o payload como o corpo da requisição
    CURLOPT_HTTPHEADER => $header,
));

$response = curl_exec($curl);
$err = curl_error($curl);

curl_close($curl);

if ($err) {
    echo "cURL Error #:" . $err;
} else {
    echo $response;
}

?>
