<?php

// Define o header desejado
$header = array(
    "Content-Type: application/json",
    "cnpjSh: 01001001000113",
    "tokenSh: CdEZhJcQJS9rRdkLnx2Kl67GhAeBx89X2hzgVQ8i",
    "payercpfcnpj: 01001001000113"
);

?>