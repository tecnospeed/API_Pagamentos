<?php

$url = "https://staging.pagamentobancario.com.br/api/v1/payment?uniqueId=UIYZY8QHA";
$headers = array(
    "Content-Type: application/json",
    "cnpjSh: 01001001000113",
    "payercpfcnpj: 01001001000113",
    "tokenSh: CdEZhJcQJS9rRdkLnx2Kl67GhAeBx89X2hzgVQ8i"
);

$curl = curl_init();

curl_setopt_array($curl, array(
    CURLOPT_URL => $url,
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_ENCODING => "",
    CURLOPT_MAXREDIRS => 10,
    CURLOPT_TIMEOUT => 30,
    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
    CURLOPT_CUSTOMREQUEST => "GET",
    CURLOPT_HTTPHEADER => $headers,
));

$response = curl_exec($curl);
$err = curl_error($curl);

curl_close($curl);

if ($err) {
    echo "cURL Error #:" . $err;
} else {
    echo $response;
}
?>
