require 'uri'
require 'net/http'

def pegar_voucher(cnpjsh, tokensh, cpf_cnpj, unique_id)
    url = URI("https://staging.pagamentobancario.com.br/api/v1/voucher/#{unique_id}")

    http = Net::HTTP.new(url.host, url.port)
    http.use_ssl = true

    request = Net::HTTP::Get.new(url)
    request["cnpjsh"] = cnpjsh
    request["tokensh"] = tokensh
    request["payercpfcnpj"] = cpf_cnpj

    response = http.request(request)
    
    puts "Status Code: #{response.code}"
    puts "Response: #{response.read_body}"
end

pegar_voucher(
    cnpjsh: "seu_cnpj",
    tokensh: "seu_token",
    cpf_cnpj: "123.456.789-00",
    unique_id: "unique_id_voucher"
)
