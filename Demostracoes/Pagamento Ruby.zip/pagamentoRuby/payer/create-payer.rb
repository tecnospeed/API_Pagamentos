require 'net/http'
require 'json'

def cadastrar_pagador(cnpjsh, tokensh, nome, cpf_cnpj, email, neighborhood, addressNumber, zipcode, state, city, accounts)
  url = URI("https://staging.pagamentobancario.com.br/api/v1/payer")

  request_body = {
    name: nome,
    cpfCnpj: cpf_cnpj,
    email: email,
    neighborhood: neighborhood,
    addressNumber: addressNumber,
    zipcode: zipcode,
    state: state,
    city: city,
    accounts: accounts
  }.to_json

  headers = {
    'Content-Type' => 'application/json',
    'cnpjsh' => cnpjsh,
    'tokensh' => tokensh
  }

  http = Net::HTTP.new(url.host, url.port)
  http.use_ssl = true 
  
  request = Net::HTTP::Post.new(url)
  request.body = request_body
  headers.each { |key, value| request[key] = value }

  response = http.request(request)

  puts "Código de resposta (Cadastro): #{response.code}"
  puts "Corpo da resposta (Cadastro): #{response.body}"
end

cnpjsh = ""
tokensh = ""
nome = "Teste Demo"
cpf_cnpj = ""
email = "exemplo@pagador.com"
neighborhood = "DUQUE DE CAXIAS"
addressNumber = "882"
zipcode = "87020025"
state = "PR"
city = "MARINGA"
accounts = [
  {
      bankCode: "341",
      agency: "1111",
      agencyDigit: "2",
      accountNumber: "000000066666",
      accountNumberDigit: "7",
      accountDac: "3",
      convenioAgency: "123",
      convenioNumber: "888888",
      remessaSequential: "1"
  }
]

cadastrar_pagador(cnpjsh, tokensh, nome, cpf_cnpj, email, neighborhood, addressNumber, zipcode, state, city, accounts)
