require 'net/http'
require 'json'

def atualizar_pagador(cnpjsh, tokensh, cpf_cnpj, dados_atualizados)
  url = URI("https://staging.pagamentobancario.com.br/api/v1/payer")

  request_body = dados_atualizados.to_json

  headers = {
    'Content-Type' => 'application/json',
    'cnpjsh' => cnpjsh,
    'tokensh' => tokensh,
    'payercpfcnpj' => cpf_cnpj
  }

  http = Net::HTTP.new(url.host, url.port)
  http.use_ssl = true 

  request = Net::HTTP::Put.new(url)
  request.body = request_body
  headers.each { |key, value| request[key] = value }

  response = http.request(request)

  puts "Código de resposta (Atualização): #{response.code}"
  puts "Corpo da resposta (Atualização): #{response.body}"
end

cnpjsh = ""
tokensh = ""
cpf_cnpj = ""
dados_atualizados = {
  name: "Novo Nome do Pagador",
  email: "novoemail@pagador.com",
  street: "Nova Rua do Pagador",
  neighborhood: "Novo Bairro do Pagador",
  addressNumber: "123",
  addressComplement: "Novo Complemento",
  city: "Nova Cidade do Pagador",
  state: "NC",
  zipcode: "98765432"
}

atualizar_pagador(cnpjsh, tokensh, cpf_cnpj, dados_atualizados)
