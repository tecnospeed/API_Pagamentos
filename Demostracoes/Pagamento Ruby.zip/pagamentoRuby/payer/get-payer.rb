require 'net/http'
require 'json'

def consultar_pagador(cnpjsh, tokensh, payercpfcnpj)
  url = URI("https://staging.pagamentobancario.com.br/api/v1/payer")

  url.query = URI.encode_www_form({ payercpfcnpj: payercpfcnpj })

  headers = {
    'cnpjsh' => cnpjsh,
    'tokensh' => tokensh,
    'Content-Type' => 'application/json'
  }

  http = Net::HTTP.new(url.host, url.port)
  http.use_ssl = true 

  request = Net::HTTP::Get.new(url)
  headers.each { |key, value| request[key] = value }

  response = http.request(request)

  puts "Código de resposta (Consulta): #{response.code}"
  puts "Corpo da resposta (Consulta): #{response.body}"
end

cnpjsh = ""
tokensh = ""
payercpfcnpj = ""

consultar_pagador(cnpjsh, tokensh, payercpfcnpj)
