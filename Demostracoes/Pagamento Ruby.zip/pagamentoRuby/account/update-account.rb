require 'net/http'
require 'json'

def atualizar_conta(cnpjsh, tokensh, cpf_cnpj, account_hash, dados_atualizados)
  url = URI("https://staging.pagamentobancario.com.br/api/v1/account/#{account_hash}")

  request_body = dados_atualizados.to_json

  headers = {
    'Content-Type' => 'application/json',
    'cnpjsh' => cnpjsh,
    'tokensh' => tokensh,
    'payercpfcnpj' => cpf_cnpj
  }

  http = Net::HTTP.new(url.host, url.port)
  http.use_ssl = true

  request = Net::HTTP::Put.new(url)
  request.body = request_body
  headers.each { |key, value| request[key] = value }

  response = http.request(request)

  puts "Código de resposta (Atualização de conta): #{response.code}"
  puts "Corpo da resposta (Atualização de conta): #{response.body}"
end

cnpjsh = "01001001000113"
tokensh = "CdEZhJcQJS9rRdkLnx2Kl67GhAeBx89X2hzgVQ8i"
cpf_cnpj = "20892355000"
account_hash = "dYPItIgIEV"
dados_atualizados = {
  bankCode: "341",
  agency: "1111",
  agencyDigit: "2",
  accountNumber: "000000066666",
  accountNumberDigit: "7",
  accountDac: "3",
  convenioAgency: "123",
  convenioNumber: "888888",
  remessaSequential: "1"
}

atualizar_conta(cnpjsh, tokensh, cpf_cnpj, account_hash, dados_atualizados)
