require 'net/http'
require 'json'

def criar_conta(cnpjsh, tokensh, cpf_cnpj, contas)
  url = URI("https://staging.pagamentobancario.com.br/api/v1/account")

  def corrigir_codificacao(valor)
    valor.encode('UTF-8', invalid: :replace, undef: :replace, replace: '')
  end

  contas.each do |conta|
    conta.transform_values! do |value|
      corrigir_codificacao(value)
    end
  end

  cpf_cnpj = corrigir_codificacao(cpf_cnpj)

  request_body = {
    payercpfcnpj: cpf_cnpj,
    accounts: contas
  }.to_json

  headers = {
    'Content-Type' => 'application/json',
    'cnpjsh' => cnpjsh,
    'tokensh' => tokensh
  }

  http = Net::HTTP.new(url.host, url.port)
  http.use_ssl = true 

  request = Net::HTTP::Post.new(url)
  request.body = request_body
  headers.each { |key, value| request[key] = value }

  response = http.request(request)

  puts "Código de resposta (Criação de conta): #{response.code}"
  puts "Corpo da resposta (Criação de conta): #{response.body}"
end

cnpjsh = ""
tokensh = ""
cpf_cnpj = ""
contas = [
  {
    bankCode: "341",
    agency: "1111",
    agencyDigit: "2",
    accountNumber: "000000066666",
    accountNumberDigit: "7",
    accountDac: "3",
    convenioAgency: "123",
    convenioNumber: "888888",
    remessaSequential: "1"
  }
]

criar_conta(cnpjsh, tokensh, cpf_cnpj, contas)
