require 'net/http'
require 'json'

def consultar_contas(cnpjsh, tokensh, cpf_cnpj)
  url = URI("https://staging.pagamentobancario.com.br/api/v1/account")

  params = { payercpfcnpj: cpf_cnpj }
  url.query = URI.encode_www_form(params)

  headers = {
    'cnpjsh' => cnpjsh,
    'tokensh' => tokensh,
    'Content-Type' => 'application/json'
  }

  http = Net::HTTP.new(url.host, url.port)
  http.use_ssl = true 

  request = Net::HTTP::Get.new(url)
  headers.each { |key, value| request[key] = value }

  response = http.request(request)

  puts "Código de resposta (Consulta de contas): #{response.code}"
  puts "Corpo da resposta (Consulta de contas): #{response.body}"
end

cnpjsh = "01001001000113"
tokensh = "CdEZhJcQJS9rRdkLnx2Kl67GhAeBx89X2hzgVQ8i"
cpf_cnpj = "20892355000"

consultar_contas(cnpjsh, tokensh, cpf_cnpj)
