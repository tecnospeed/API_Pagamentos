require 'net/http'
require 'json'

def deletar_contas(cnpjsh, tokensh, cpf_cnpj, account_hashes)
  url = URI("https://staging.pagamentobancario.com.br/api/v1/account")

  request_body = {
    accountHash: account_hashes
  }.to_json

  headers = {
    'Content-Type' => 'application/json',
    'cnpjsh' => cnpjsh,
    'tokensh' => tokensh,
    'payercpfcnpj' => cpf_cnpj
  }

  http = Net::HTTP.new(url.host, url.port)
  http.use_ssl = true

  request = Net::HTTP::Delete.new(url)
  request.body = request_body
  headers.each { |key, value| request[key] = value }

  response = http.request(request)

  puts "Código de resposta (Deleção de contas): #{response.code}"
  puts "Corpo da resposta (Deleção de contas): #{response.body}"
end

cnpjsh = "seu_cnpj"
tokensh = "seu_token"
cpf_cnpj = "123.456.789-00"
account_hashes = ["hash_da_conta_1", "hash_da_conta_2"] 

deletar_contas(cnpjsh, tokensh, cpf_cnpj, account_hashes)
