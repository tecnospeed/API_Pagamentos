require 'uri'
require 'net/http'
require 'json'

def enviar_arquivo_retorno(cnpjsh, tokensh, cpf_cnpj, file_path)
    url = URI("https://staging.pagamentobancario.com.br/api/v1/reconciliation")

    http = Net::HTTP.new(url.host, url.port)
    http.use_ssl = true

    request = Net::HTTP::Post.new(url)
    request["cnpjsh"] = cnpjsh
    request["tokensh"] = tokensh
    request["payercpfcnpj"] = cpf_cnpj
    request["Content-Type"] = "multipart/form-data"

    file = File.open(file_path)

    form_data = [['file', file]]

    request.set_form form_data, 'multipart/form-data'

    response = http.request(request)
    
    puts "Status Code: #{response.code}"
    puts "Response: #{response.read_body}"
end

enviar_arquivo_retorno(
    cnpjsh: "seu_cnpj",
    tokensh: "seu_token",
    cpf_cnpj: "123.456.789-00",
    file_path: "/caminho/para/seu/arquivo_de_retorno.ret"
)
