require 'uri'
require 'net/http'
require 'json'

def cadastrar_notificacao(cnpjsh, tokensh, payercpfcnpj, type, email, cc, headers, url, mobile, happen)
    url = URI("https://staging.pagamentobancario.com.br/api/v1/notification")

    http = Net::HTTP.new(url.host, url.port)
    http.use_ssl = true

    request = Net::HTTP::Post.new(url)
    request["cnpjsh"] = cnpjsh
    request["tokensh"] = tokensh
    request["payercpfcnpj"] = payercpfcnpj
    request["Content-Type"] = "application/json"

    request.body = JSON.dump({
        "type" => type,
        "email" => email,
        "cc" => cc,
        "headers" => headers,
        "url" => url,
        "mobile" => mobile,
        "happen" => happen
    })

    response = http.request(request)
    puts "Status Code: #{response.code}"
    puts "Response: #{response.read_body}"
end

cadastrar_notificacao(
    cnpjsh: "seu_cnpj",
    tokensh: "seu_token",
    payercpfcnpj: "cpf_cnpj_pagador",
    type: "webhook",
    email: "seu_email@exemplo.com",
    cc: "outro_email@exemplo.com",
    headers: {},
    url: "https://sua_url_webhook.com",
    mobile: "seu_numero_de_celular",
    happen: ["PAID", "SCHEDULED", "CANCELLED", "REJECTED", "REFUNDED", "STATEMENT"]
)
