require 'uri'
require 'net/http'
require 'json'

def atualizar_notificacao(cnpjsh, tokensh, payercpfcnpj, unique_id, email, cc, headers, url, mobile, happen)
    url = URI("https://staging.pagamentobancario.com.br/api/v1/notification")

    http = Net::HTTP.new(url.host, url.port)
    http.use_ssl = true

    request = Net::HTTP::Put.new(url)
    request["cnpjsh"] = cnpjsh
    request["tokensh"] = tokensh
    request["payercpfcnpj"] = payercpfcnpj
    request["Content-Type"] = "application/json"
    request.body = JSON.dump({
      uniqueId: unique_id,
      type: "webhook",
      email: email,
      cc: cc,
      headers: headers,
      url: url,
      mobile: mobile,
      happen: happen
    })

    response = http.request(request)
    puts "Status Code: #{response.code}"
    puts "Response: #{response.read_body}"
end

atualizar_notificacao(
    cnpjsh: "seu_cnpj",
    tokensh: "seu_token",
    payercpfcnpj: "cpf_cnpj_pagador",
    unique_id: "id_unico_notificacao",
    email: "seu_email@exemplo.com",
    cc: "email_cc@exemplo.com",
    headers: { "Key" => "Value" },
    url: "https://seusite.com/webhook",
    mobile: "+5511999999999",
    happen: ["CREATED", "PAID", "SCHEDULED"]
)
