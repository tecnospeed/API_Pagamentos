require 'uri'
require 'net/http'
require 'json'

def apagar_notificacao(cnpjsh, tokensh, payercpfcnpj, unique_ids)
    url = URI("https://staging.pagamentobancario.com.br/api/v1/notification")

    http = Net::HTTP.new(url.host, url.port)
    http.use_ssl = true

    request = Net::HTTP::Delete.new(url)
    request["cnpjsh"] = cnpjsh
    request["tokensh"] = tokensh
    request["payercpfcnpj"] = payercpfcnpj
    request["Content-Type"] = "application/json"
    request.body = JSON.dump({
      uniqueId: unique_ids
    })

    response = http.request(request)
    puts "Status Code: #{response.code}"
    puts "Response: #{response.read_body}"
end

apagar_notificacao(
    cnpjsh: "seu_cnpj",
    tokensh: "seu_token",
    payercpfcnpj: "cpf_cnpj_pagador",
    unique_ids: ["id_notificacao_1", "id_notificacao_2"]
)
