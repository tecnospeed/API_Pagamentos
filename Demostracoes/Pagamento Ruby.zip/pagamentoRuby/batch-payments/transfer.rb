require 'uri'
require 'net/http'
require 'json'

def enviar_transferencias_em_lote(cnpjsh, tokensh, cpf_cnpj, pagamentos)
    url = URI("https://staging.pagamentobancario.com.br/api/v1/payment/transfer/batch")

    http = Net::HTTP.new(url.host, url.port)
    http.use_ssl = true

    request = Net::HTTP::Post.new(url)
    request["cnpjsh"] = cnpjsh
    request["tokensh"] = tokensh
    request["payercpfcnpj"] = cpf_cnpj
    request["Content-Type"] = "application/json"
    request.body = pagamentos.to_json

    response = http.request(request)
    puts "Status Code: #{response.code}"
    puts "Response: #{response.read_body}"
end

pagamentos = [
  {
    "accountHash": "hash_conta_1",
    "description": "Pagamento via transferência bancária",
    "paymentForm": "3",
    "paymentDate": "2024-05-10",
    "dueDate": "2024-05-15",
    "amount": 1000.00,
    "compensation": 341,
    "beneficiary": {
      "name": "Nome do Beneficiário",
      "cpfCnpj": "12345678901",
      "bankCode": "001",
      "agency": "1234",
      "agencyDigit": "5",
      "accountNumber": "123456",
      "accountNumberDigit": "7",
      "accountDac": "8",
      "street": "Rua do Beneficiário",
      "neighborhood": "Bairro do Beneficiário",
      "addressNumber": "123",
      "addressComplement": "Complemento do endereço",
      "city": "Cidade do Beneficiário",
      "state": "UF",
      "zipcode": "12345678"
    },
    "tags": ["transferencia", "pagamento"]
  },
  {
    "accountHash": "hash_conta_2",
    "description": "Pagamento via transferência bancária",
    "paymentForm": "3",
    "paymentDate": "2024-05-10",
    "dueDate": "2024-05-15",
    "amount": 1500.00,
    "compensation": 341,
    "beneficiary": {
      "name": "Nome do Beneficiário",
      "cpfCnpj": "12345678901",
      "bankCode": "001",
      "agency": "1234",
      "agencyDigit": "5",
      "accountNumber": "123456",
      "accountNumberDigit": "7",
      "accountDac": "8",
      "street": "Rua do Beneficiário",
      "neighborhood": "Bairro do Beneficiário",
      "addressNumber": "123",
      "addressComplement": "Complemento do endereço",
      "city": "Cidade do Beneficiário",
      "state": "UF",
      "zipcode": "12345678"
    },
    "tags": ["transferencia", "pagamento"]
  }
]

enviar_transferencias_em_lote(
    cnpjsh: "seu_cnpj",
    tokensh: "seu_token",
    cpf_cnpj: "123.456.789-00",
    pagamentos: pagamentos
)
