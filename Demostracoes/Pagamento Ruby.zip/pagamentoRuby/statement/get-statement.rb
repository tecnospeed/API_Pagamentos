require 'uri'
require 'net/http'

def consultar_extrato(unique_id, cnpjsh, tokensh, payercpfcnpj)
    url = URI("https://staging.pagamentobancario.com.br/api/v1/statement/parser/#{unique_id}")

    http = Net::HTTP.new(url.host, url.port)
    http.use_ssl = true

    request = Net::HTTP::Get.new(url)
    request["cnpjsh"] = cnpjsh
    request["tokensh"] = tokensh
    request["payercpfcnpj"] = payercpfcnpj
    request["Content-Type"] = "application/json"

    response = http.request(request)
    puts "Status Code: #{response.code}"
    puts "Response: #{response.read_body}"
end

consultar_extrato(
    unique_id: "seu_unique_id",
    cnpjsh: "seu_cnpj",
    tokensh: "seu_token",
    payercpfcnpj: "cpf_cnpj_pagador"
)
