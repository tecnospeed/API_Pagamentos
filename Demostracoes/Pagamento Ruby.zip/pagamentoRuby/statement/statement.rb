require 'uri'
require 'net/http'

def enviar_extrato(cnpjsh, tokensh, payercpfcnpj, file_path)
    url = URI("https://staging.pagamentobancario.com.br/api/v1/statement/parser")

    http = Net::HTTP.new(url.host, url.port)
    http.use_ssl = true

    request = Net::HTTP::Post.new(url)
    request["cnpjsh"] = cnpjsh
    request["tokensh"] = tokensh
    request["payercpfcnpj"] = payercpfcnpj
    request["Content-Type"] = "multipart/form-data"
    request.body = [
      ["file", File.open(file_path)]
    ]

    response = http.request(request)
    puts "Status Code: #{response.code}"
    puts "Response: #{response.read_body}"
end

enviar_extrato(
    cnpjsh: "seu_cnpj",
    tokensh: "seu_token",
    payercpfcnpj: "cpf_cnpj_pagador",
    file_path: "/caminho/para/o/arquivo.extrato"
)
