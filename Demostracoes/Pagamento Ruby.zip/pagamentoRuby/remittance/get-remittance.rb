require 'uri'
require 'net/http'
require 'json'

def consultar_remessa(cnpjsh, tokensh, cpf_cnpj, batch_id)
    url = URI("https://staging.pagamentobancario.com.br/api/v1/remittance/#{batch_id}")

    http = Net::HTTP.new(url.host, url.port)
    http.use_ssl = true

    request = Net::HTTP::Get.new(url)
    request["cnpjsh"] = cnpjsh
    request["tokensh"] = tokensh
    request["payercpfcnpj"] = cpf_cnpj
    request["Content-Type"] = "application/json"

    response = http.request(request)
    puts "Status Code: #{response.code}"
    puts "Response: #{response.read_body}"
end

consultar_remessa(
    cnpjsh: "seu_cnpj",
    tokensh: "seu_token",
    cpf_cnpj: "123.456.789-00",
    batch_id: "id_da_remessa"
)
