require 'uri'
require 'net/http'
require 'json'

def gerar_remessa(cnpjsh, tokensh, cpf_cnpj, unique_ids, complement = nil)
    url = URI("https://staging.pagamentobancario.com.br/api/v1/remittance")

    http = Net::HTTP.new(url.host, url.port)
    http.use_ssl = true

    request = Net::HTTP::Post.new(url)
    request["cnpjsh"] = cnpjsh
    request["tokensh"] = tokensh
    request["payercpfcnpj"] = cpf_cnpj
    request["Content-Type"] = "application/json"

    payload = {
        "payments" => unique_ids,
        "complement" => complement
    }

    request.body = payload.to_json

    response = http.request(request)
    puts "Status Code: #{response.code}"
    puts "Response: #{response.read_body}"
end

gerar_remessa(
    cnpjsh: "seu_cnpj",
    tokensh: "seu_token",
    cpf_cnpj: "123.456.789-00",
    unique_ids: ["id_1", "id_2", "id_3"],
    complement: 123456789 # Opcional: complemento de registro
)
