require 'uri'
require 'net/http'
require 'json'

def remessa_cancelamento(cnpjsh, tokensh, cpf_cnpj, unique_ids)
    url = URI("https://staging.pagamentobancario.com.br/api/v1/remittance/cancel")

    http = Net::HTTP.new(url.host, url.port)
    http.use_ssl = true

    request = Net::HTTP::Post.new(url)
    request["cnpjsh"] = cnpjsh
    request["tokensh"] = tokensh
    request["payercpfcnpj"] = cpf_cnpj
    request["Content-Type"] = "application/json"
    request.body = {
        payments: unique_ids
    }.to_json

    response = http.request(request)
    puts "Status Code: #{response.code}"
    puts "Response: #{response.read_body}"
end

remessa_cancelamento(
    cnpjsh: "seu_cnpj",
    tokensh: "seu_token",
    cpf_cnpj: "123.456.789-00",
    unique_ids: ["id1", "id2", "id3"]
)
