require 'uri'
require 'net/http'
require 'json'

def consultar_bilhetagem(cnpjsh, tokensh, data_inicial, data_final, limit, page)
    url = URI("https://staging.pagamentobancario.com.br/api/v1/report?data_inicial=#{data_inicial}&data_final=#{data_final}&limit=#{limit}&page=#{page}")

    http = Net::HTTP.new(url.host, url.port)
    http.use_ssl = true

    request = Net::HTTP::Get.new(url)
    request["cnpjsh"] = cnpjsh
    request["tokensh"] = tokensh
    request["Content-Type"] = "application/json"

    response = http.request(request)
    puts "Status Code: #{response.code}"
    puts "Response: #{response.read_body}"
end

consultar_bilhetagem(
    cnpjsh: "seu_cnpj",
    tokensh: "seu_token",
    data_inicial: "2024-01-01",
    data_final: "2024-01-31",
    limit: 100,
    page: 1
)
