require 'net/http'
require 'json'

def gerar_pagamento_boleto(cnpjsh, tokensh, cpf_cnpj, account_hash, payment_form, description, barcode, due_date, nominal_amount, beneficiary)
  url = URI("https://staging.pagamentobancario.com.br/api/v1/payment/billet")

  request_body = {
    accountHash: account_hash,
    paymentForm: payment_form,
    description: description,
    barcode: barcode,
    dueDate: due_date,
    nominalAmount: nominal_amount,
    beneficiary: beneficiary
  }.to_json

  headers = {
    'Content-Type' => 'application/json',
    'cnpjsh' => cnpjsh,
    'tokensh' => tokensh,
    'payercpfcnpj' => cpf_cnpj
  }

  http = Net::HTTP.new(url.host, url.port)
  http.use_ssl = true 

  request = Net::HTTP::Post.new(url)
  request.body = request_body
  headers.each { |key, value| request[key] = value }

  response = http.request(request)

  puts "Código de resposta (Geração de pagamento de boleto): #{response.code}"
  puts "Corpo da resposta (Geração de pagamento de boleto): #{response.body}"
end

cnpjsh = "seu_cnpj"
tokensh = "seu_token"
cpf_cnpj = "123.456.789-00"
account_hash = "hash_da_conta"
payment_form = "codigo_forma_pagamento" 
description = "Descrição do pagamento"
barcode = "codigo_de_barras_boleto"
due_date = "AAAA-MM-DD" 
nominal_amount = 100.50 
beneficiary = {
  name: "Nome do Beneficiário",
  cpfCnpj: "123.456.789-00",
  bankCode: "001", 
  agency: "12345",
  agencyDigit: "6",
  accountNumber: "123456",
  street: "Rua do Beneficiário",
  accountNumberDigit: "7",
  accountDac: "8",
  neighborhood: "Bairro do Beneficiário",
  addressNumber: "123",
  addressComplement: "Complemento do Endereço",
  city: "Cidade do Beneficiário",
  state: "SP",
  zipcode: "12345678"
}

gerar_pagamento_boleto(cnpjsh, tokensh, cpf_cnpj, account_hash, payment_form, description, barcode, due_date, nominal_amount, beneficiary)
