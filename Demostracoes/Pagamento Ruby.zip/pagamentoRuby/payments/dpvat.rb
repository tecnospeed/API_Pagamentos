require 'net/http'
require 'json'

def gerar_pagamento_dpvat(cnpjsh, tokensh, cpf_cnpj, account_hash, revenue_code, payment_date, description, contributor_document, nominal_amount, contributor_name, calculation_year, amount, due_date, municipal_code, discount_amount, city, state, vehicle_plates, payment_option, vehicle_renavam, crvl_withdrawal_option, tags)
  url = URI("https://staging.pagamentobancario.com.br/api/v1/payment/taxes/dpvat")

  request_body = {
    accountHash: account_hash,
    revenueCode: revenue_code,
    paymentDate: payment_date,
    description: description,
    contributorDocument: contributor_document,
    nominalAmount: nominal_amount,
    contributorName: contributor_name,
    calculationYear: calculation_year,
    amount: amount,
    dueDate: due_date,
    municipalCode: municipal_code,
    discountAmount: discount_amount,
    city: city,
    state: state,
    vehiclePlates: vehicle_plates,
    paymentOption: payment_option,
    vehicleRenavam: vehicle_renavam,
    CRVLWithdrawalOption: crvl_withdrawal_option,
    tags: tags
  }.to_json

  headers = {
    'Content-Type' => 'application/json',
    'cnpjsh' => cnpjsh,
    'tokensh' => tokensh,
    'payercpfcnpj' => cpf_cnpj
  }

  http = Net::HTTP.new(url.host, url.port)
  http.use_ssl = true 

  request = Net::HTTP::Post.new(url)
  request.body = request_body
  headers.each { |key, value| request[key] = value }

  response = http.request(request)

  puts "Código de resposta (Geração de pagamento do DPVAT): #{response.code}"
  puts "Corpo da resposta (Geração de pagamento do DPVAT): #{response.body}"
end

cnpjsh = "seu_cnpj"
tokensh = "seu_token"
cpf_cnpj = "123.456.789-00"
account_hash = "hash_da_conta"
revenue_code = "CODIGO"
payment_date = "AAAA-MM-DD" 
description = "Descrição do pagamento"
contributor_document = "Documento do Contribuinte"
nominal_amount = 1000.00 
contributor_name = "Nome do Contribuinte"
calculation_year = "AAAA" 
amount = 1000.00 
due_date = "AAAA-MM-DD" 
municipal_code = "1234567" 
discount_amount = 0.0 
city = "Nome da cidade"
state = "SP" 
vehicle_plates = "XXX9999" 
payment_option = 1
vehicle_renavam = "12345678901234567" 
crvl_withdrawal_option = 1 
tags = ["tag1", "tag2"]

gerar_pagamento_dpvat(cnpjsh, tokensh, cpf_cnpj, account_hash, revenue_code, payment_date, description, contributor_document, nominal_amount, contributor_name, calculation_year, amount, due_date, municipal_code, discount_amount, city, state, vehicle_plates, payment_option, vehicle_renavam, crvl_withdrawal_option, tags)
