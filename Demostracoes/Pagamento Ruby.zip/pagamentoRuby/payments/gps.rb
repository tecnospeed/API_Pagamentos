require 'net/http'
require 'json'

def gerar_pagamento_gps(cnpjsh, tokensh, cpf_cnpj, account_hash, payment_date, due_date, amount, contributor_document, contributor_name, tags)
  url = URI("https://staging.pagamentobancario.com.br/api/v1/payment/taxes/gps")

  request_body = {
    accountHash: account_hash,
    paymentDate: payment_date,
    dueDate: due_date,
    amount: amount,
    contributorDocument: contributor_document,
    contributorName: contributor_name,
    tags: tags
  }.to_json

  headers = {
    'Content-Type' => 'application/json',
    'cnpjsh' => cnpjsh,
    'tokensh' => tokensh,
    'payercpfcnpj' => cpf_cnpj
  }

  http = Net::HTTP.new(url.host, url.port)
  http.use_ssl = true 

  request = Net::HTTP::Post.new(url)
  request.body = request_body
  headers.each { |key, value| request[key] = value }

  response = http.request(request)

  puts "Código de resposta (Geração de pagamento da GPS): #{response.code}"
  puts "Corpo da resposta (Geração de pagamento da GPS): #{response.body}"
end

# Exemplo de uso:
cnpjsh = "seu_cnpj"
tokensh = "seu_token"
cpf_cnpj = "123.456.789-00"
account_hash = "hash_da_conta"
payment_date = "AAAA-MM-DD" 
due_date = "AAAA-MM-DD" 
amount = 1000.00 
contributor_document = "Documento do Contribuinte"
contributor_name = "Nome do contribuinte"
tags = ["tag1", "tag2"]

gerar_pagamento_gps(cnpjsh, tokensh, cpf_cnpj, account_hash, payment_date, due_date, amount, contributor_document, contributor_name, tags)
