require 'uri'
require 'net/http'
require 'json'

def gerar_pagamento_diversos(cnpjsh, tokensh, cpf_cnpj, account_hash, description, payment_form, payment_date, due_date, amount, rebate_amount, interest_amount, discount_amount, fine_amount, moviment_code, complementary_code, compromise_type, transmission_param, pix_type, pix_key, ispb_code, registration_complement, pix_url, pix_txid, beneficiary, tags)
    url = URI("https://staging.pagamentobancario.com.br/api/v1/payment/diversos")

    payload = {
        "accountHash": account_hash,
        "description": description,
        "paymentForm": payment_form,
        "paymentDate": payment_date,
        "dueDate": due_date,
        "amount": amount,
        "rebateAmount": rebate_amount,
        "interestAmount": interest_amount,
        "discountAmount": discount_amount,
        "fineAmount": fine_amount,
        "movimentCode": moviment_code,
        "complementaryCode": complementary_code,
        "compromiseType": compromise_type,
        "transmissionParam": transmission_param,
        "pixType": pix_type,
        "pixKey": pix_key,
        "ispbCode": ispb_code,
        "registrationComplement": registration_complement,
        "pixUrl": pix_url,
        "pixTxid": pix_txid,
        "beneficiary": beneficiary,
        "tags": tags
    }

    http = Net::HTTP.new(url.host, url.port)
    http.use_ssl = true

    request = Net::HTTP::Post.new(url)
    request["Content-Type"] = "application/json"
    request["cnpjsh"] = cnpjsh
    request["tokensh"] = tokensh
    request["payercpfcnpj"] = cpf_cnpj
    request.body = payload.to_json

    response = http.request(request)
    puts "Status Code: #{response.code}"
    puts "Response: #{response.read_body}"
end

gerar_pagamento_diversos(
    cnpjsh: "seu_cnpj",
    tokensh: "seu_token",
    cpf_cnpj: "12345678900",
    account_hash: "hash_da_conta",
    description: "Descrição do pagamento",
    payment_form: "forma_de_pagamento",
    payment_date: "AAAA-MM-DD",
    due_date: "AAAA-MM-DD",
    amount: 1000.00,
    rebate_amount: 0.0,
    interest_amount: 0.0,
    discount_amount: 0.0,
    fine_amount: 0.0,
    moviment_code: "01",
    complementary_code: "CC",
    compromise_type: "01",
    transmission_param: 0,
    pix_type: "01",
    pix_key: "chave_pix",
    ispb_code: "codigo_ispb",
    registration_complement: "01",
    pix_url: "url_pix",
    pix_txid: "txid_pix",
    beneficiary: {
        name: "Nome do favorecido",
        cpfCnpj: "CPF ou CNPJ do favorecido",
        bankCode: "Código do banco",
        agency: "Agência",
        agencyDigit: "Dígito da agência",
        accountNumber: "Número da conta",
        accountNumberDigit: "Dígito da conta",
        street: "Rua do favorecido",
        neighborhood: "Bairro do favorecido",
        addressNumber: "Número do endereço",
        addressComplement: "Complemento do endereço",
        city: "Cidade do favorecido",
        state: "UF do favorecido",
        zipcode: "CEP do favorecido"
    },
    tags: ["tag1", "tag2"]
)
