require 'net/http'
require 'json'

def gerar_pagamento_darf(cnpjsh, tokensh, cpf_cnpj, account_hash, revenue_code, payment_date, contributor_document, description, reporting_period, reference_period, reference_number, nominal_amount, due_date, tags, contributor_name, moviment_code, interest_amount = nil, fine_amount = nil, fee_amount = nil, other_amount = nil)
  url = URI("https://staging.pagamentobancario.com.br/api/v1/payment/taxes/darf")

  request_body = {
    accountHash: account_hash,
    revenueCode: revenue_code,
    paymentDate: payment_date,
    contributorDocument: contributor_document,
    description: description,
    reportingPeriod: reporting_period,
    referencePeriod: reference_period,
    referenceNumber: reference_number,
    nominalAmount: nominal_amount,
    dueDate: due_date,
    tags: tags,
    contributorName: contributor_name,
    movimentCode: moviment_code,
    interestAmount: interest_amount,
    fineAmount: fine_amount,
    feeAmount: fee_amount,
    otherAmount: other_amount
  }.to_json

  headers = {
    'Content-Type' => 'application/json',
    'cnpjsh' => cnpjsh,
    'tokensh' => tokensh,
    'payercpfcnpj' => cpf_cnpj
  }

  http = Net::HTTP.new(url.host, url.port)
  http.use_ssl = true 

  request = Net::HTTP::Post.new(url)
  request.body = request_body
  headers.each { |key, value| request[key] = value }

  response = http.request(request)

  puts "Código de resposta (Geração de pagamento da DARF): #{response.code}"
  puts "Corpo da resposta (Geração de pagamento da DARF): #{response.body}"
end

cnpjsh = "seu_cnpj"
tokensh = "seu_token"
cpf_cnpj = "123.456.789-00"
account_hash = "hash_da_conta"
revenue_code = "CODIGO"
payment_date = "AAAA-MM-DD" 
contributor_document = "Documento do Contribuinte"
description = "Descrição do pagamento"
reporting_period = "AAAA-MM-DD" 
reference_period = "AAAA-MM-DD" 
reference_number = "12345" 
nominal_amount = 1000.00 
due_date = "AAAA-MM-DD" 
tags = ["tag1", "tag2"]
contributor_name = "Nome do contribuinte"
moviment_code = "01" 
interest_amount = 10.00 
fine_amount = 20.00 
fee_amount = 5.00 
other_amount = 15.00 

gerar_pagamento_darf(cnpjsh, tokensh, cpf_cnpj, account_hash, revenue_code, payment_date, contributor_document, description, reporting_period, reference_period, reference_number, nominal_amount, due_date, tags, contributor_name, moviment_code, interest_amount, fine_amount, fee_amount, other_amount)
