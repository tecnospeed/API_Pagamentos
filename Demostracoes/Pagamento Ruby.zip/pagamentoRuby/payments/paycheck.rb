require 'net/http'
require 'json'

def gerar_pagamento_salarios(cnpjsh, tokensh, cpf_cnpj, payment_form, account_hash, description, payment_date, due_date, amount, rebate_amount, interest_amount, discount_amount, fine_amount, moviment_code, complementary_code, compromise_type, transmission_param, beneficiary)
  url = URI("https://staging.pagamentobancario.com.br/api/v1/payment/paycheck")

  request_body = {
    accountHash: account_hash,
    description: description,
    paymentForm: payment_form,
    paymentDate: payment_date,
    dueDate: due_date,
    amount: amount,
    rebateAmount: rebate_amount,
    interestAmount: interest_amount,
    discountAmount: discount_amount,
    fineAmount: fine_amount,
    movimentCode: moviment_code,
    complementaryCode: complementary_code,
    compromiseType: compromise_type,
    transmissionParam: transmission_param,
    beneficiary: beneficiary
  }.to_json

  headers = {
    'Content-Type' => 'application/json',
    'cnpjsh' => cnpjsh,
    'tokensh' => tokensh,
    'payercpfcnpj' => cpf_cnpj
  }

  http = Net::HTTP.new(url.host, url.port)
  http.use_ssl = true # Habilita SSL para conexões HTTPS

  request = Net::HTTP::Post.new(url)
  request.body = request_body
  headers.each { |key, value| request[key] = value }

  response = http.request(request)

  puts "Código de resposta (Geração de pagamento de salários): #{response.code}"
  puts "Corpo da resposta (Geração de pagamento de salários): #{response.body}"
end

# Exemplo de uso:
cnpjsh = "seu_cnpj"
tokensh = "seu_token"
cpf_cnpj = "123.456.789-00"
payment_form = "Forma de pagamento" 
account_hash = "hash_da_conta"
description = "Descrição do pagamento"
payment_date = "AAAA-MM-DD"
due_date = "AAAA-MM-DD" 
amount = 1000.00
rebate_amount = 0.0 
interest_amount = 0.0 
discount_amount = 0.0 
fine_amount = 0.0
moviment_code = "MC"
complementary_code = "CC" 
compromise_type = 2 
transmission_param = 50 
beneficiary = {
  name: "Nome do Beneficiário",
  cpfCnpj: "123.456.789-00",
  bankCode: "001", 
  agency: "12345",
  agencyDigit: "6",
  accountNumber: "123456",
  accountNumberDigit: "7",
  street: "Rua do Beneficiário",
  neighborhood: "Bairro do Beneficiário",
  addressNumber: "123",
  addressComplement: "Complemento do Endereço",
  city: "Cidade do Beneficiário",
  state: "SP",
  zipcode: "12345678"
}

gerar_pagamento_salarios(cnpjsh, tokensh, cpf_cnpj, payment_form, account_hash, description, payment_date, due_date, amount, rebate_amount, interest_amount, discount_amount, fine_amount, moviment_code, complementary_code, compromise_type, transmission_param, beneficiary)
