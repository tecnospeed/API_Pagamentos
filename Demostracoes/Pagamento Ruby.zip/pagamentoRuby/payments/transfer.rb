require 'net/http'
require 'json'

def gerar_pagamento_transferencia(cnpjsh, tokensh, cpf_cnpj, payment_form, account_hash, description, payment_date, due_date, amount, nominal_amount, beneficiary)
  url = URI("https://staging.pagamentobancario.com.br/api/v1/payment/transfer")

  request_body = {
    accountHash: account_hash,
    description: description,
    paymentForm: payment_form,
    paymentDate: payment_date,
    dueDate: due_date,
    amount: amount,
    nominalAmount: nominal_amount,
    beneficiary: beneficiary
  }.to_json

  headers = {
    'Content-Type' => 'application/json',
    'cnpjsh' => cnpjsh,
    'tokensh' => tokensh,
    'payercpfcnpj' => cpf_cnpj
  }

  http = Net::HTTP.new(url.host, url.port)
  http.use_ssl = true 

  request = Net::HTTP::Post.new(url)
  request.body = request_body
  headers.each { |key, value| request[key] = value }

  response = http.request(request)

  puts "Código de resposta (Geração de pagamento via transferência): #{response.code}"
  puts "Corpo da resposta (Geração de pagamento via transferência): #{response.body}"
end

cnpjsh = ""
tokensh = ""
cpf_cnpj = ""
payment_form = "3" 
account_hash = "Umu6BiNKYH"
description = "Descrição do pagamento"
payment_date = "AAAA-MM-DD" 
due_date = "AAAA-MM-DD" 
amount = 100.50 
nominal_amount = 100.50 
beneficiary = {
  name: "Nome do Beneficiário",
  cpfCnpj: "12345678900",
  bankCode: "001", 
  agency: "12345",
  agencyDigit: "6",
  accountNumber: "123456",
  accountNumberDigit: "7",
  street: "Rua do Beneficiário",
  neighborhood: "Bairro do Beneficiário",
  addressNumber: "123",
  addressComplement: "Complemento do Endereço",
  city: "Cidade do Beneficiário",
  state: "SP",
  zipcode: "12345678",
  accountType: 1 
}

gerar_pagamento_transferencia(cnpjsh, tokensh, cpf_cnpj, payment_form, account_hash, description, payment_date, due_date, amount, nominal_amount, beneficiary)
