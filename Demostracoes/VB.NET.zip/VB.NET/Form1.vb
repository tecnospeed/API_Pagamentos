﻿Imports Newtonsoft.Json
Imports Newtonsoft.Json.Linq
Imports RestSharp
Imports System.IO
Imports System.Net
Imports System.Text

Public Class Form1
    Private Sub button1_Click(sender As Object, e As EventArgs) Handles button1.Click
        Dim Url As String

        Url = "https://zum1meb9r5.execute-api.us-east-1.amazonaws.com/pro/pagamentos"

        Dim objCampoConta As New Dictionary(Of String, String) From {
                                                                        {"tipoPagamento", txtTipoPagamento.Text},
                                                                        {"formaPagamento", txtFormaPagamento.Text},
                                                                        {"contaDebitadaCodigoBanco", txtContaDebitadaCodigoBanco.Text},
                                                                        {"contaDebitadaNumero", txtContaDebitadaNumero.Text},
                                                                        {"contaDebitadaAgencia", txtcontaDebitadaAgencia.Text},
                                                                        {"contaDebitadaDac", txtContaDebitadaDac.Text},
                                                                        {"contaDebitadaCpfCnpj", txtContaDebitadaCpfCnpj.Text},
                                                                        {"contaDebitadaNomeEmpresa", txtContaDebitadaNomeEmpresa.Text},
                                                                        {"empresaDebitadaEndereco", txtEmpresaDebitadaEndereco.Text},
                                                                        {"empresaDebitadaNumero", txtEmpresaDebitadaNumero.Text},
                                                                        {"empresaDebitadaComplemento", txtEmpresaDebitadaComplemento.Text},
                                                                        {"empresaDebitadaCidade", txtEmpresaDebitadaCidade.Text},
                                                                        {"empresaDebitadaCep", txtEmpresaDebitadaCep.Text},
                                                                        {"empresaDebitadaEstado", txtEmpresaDebitadaEstado.Text},
                                                                        {"nomeFavorecido", txtNomeFavorecido.Text},
                                                                        {"dataPagamento", txtDataPagamento.Text},
                                                                        {"valorPagamento", txtvalorPagamento.Text},
                                                                        {"valorDescontoAbatimento", txtvalorPagamento.Text},
                                                                        {"valorMoraMulta", txtMoraMulta.Text},
                                                                        {"beneficiarioNome", txtBeneficiarioNome.Text},
                                                                        {"beneficiarioCpfCnpj", txtBeneficiarioCnpj.Text},
                                                                        {"codigoBarras", txtCodBarras.Text},
                                                                        {"numeroControle", txtNumeroControle.Text}
        }

        Dim Json As String = JsonConvert.SerializeObject(objCampoConta, Formatting.Indented)
        Dim JsonBytes As Byte() = Encoding.UTF8.GetBytes(Json)

        txtEntradaJSON.Text = Json

        Dim client = New RestClient(Url)
        Dim request = New RestRequest(Method.POST)
        request.AddHeader("cache-control", "no-cache")
        request.AddHeader("content-type", "application/json")
        request.AddParameter("application/json", Json, ParameterType.RequestBody)

        Dim ObjBoleto As Object = JsonConvert.DeserializeObject(client.Execute(request).Content)
        txtRespostaAPI.Text = JsonConvert.SerializeObject(ObjBoleto, Formatting.Indented)

        Dim rawresp As String
        rawresp = txtRespostaAPI.Text

        Dim resposta() = Newtonsoft.Json.JsonConvert.DeserializeObject(Of Pagamento())(rawresp)

        txtIdintegracao.Text = resposta(0).idIntegracao

    End Sub

    Public Class Pagamento
        Public Property tipoPagamento As String
        Public Property formaPagamento As String
        Public Property contaDebitadaCodigoBanco As String
        Public Property contaDebitadaNumero As String
        Public Property contaDebitadaAgencia As String
        Public Property contaDebitadaDac As String
        Public Property contaDebitadaCpfCnpj As String
        Public Property contaDebitadaNomeEmpresa As String
        Public Property empresaDebitadaEndereco As String
        Public Property empresaDebitadaNumero As String
        Public Property empresaDebitadaComplemento As String
        Public Property empresaDebitadaCidade As String
        Public Property empresaDebitadaCep As String
        Public Property empresaDebitadaEstado As String
        Public Property nomeFavorecido As String
        Public Property dataPagamento As String
        Public Property valorPagamento As String
        Public Property valorDescontoAbatimento As String
        Public Property valorMoraMulta As String
        Public Property beneficiarioNome As String
        Public Property beneficiarioCpfCnpj As String
        Public Property codigoBarras As String
        Public Property numeroControle As String
        Public Property idIntegracao As String
    End Class

    Public Class arrayRemessa
        Public Property arquivo As String
        Public Property pagamentos As List(Of String)
    End Class

    Public Class RemessaResposta
        Public Property protocolo As String
        Public Property remessas As List(Of arrayRemessa)
    End Class

    Private Sub btnGerarRemessa_Click(sender As Object, e As EventArgs) Handles btnGerarRemessa.Click
        Dim Url As String

        Url = "https://zum1meb9r5.execute-api.us-east-1.amazonaws.com/pro/remessas"

        Dim objRemessa As New Dictionary(Of String, String) From {
                                                                        {"idIntegracao", txtIdintegracao.Text}
        }

        Dim Json As String = JsonConvert.SerializeObject(objRemessa, Formatting.Indented)
        Dim JsonBytes As Byte() = Encoding.UTF8.GetBytes(Json)

        txtEntradaJSON.Text = Json

        Dim client = New RestClient(Url)
        Dim request = New RestRequest(Method.POST)
        request.AddHeader("cache-control", "no-cache")
        request.AddHeader("content-type", "application/json")
        request.AddParameter("application/json", Json, ParameterType.RequestBody)

        Dim ObjBoleto As Object = JsonConvert.DeserializeObject(client.Execute(request).Content)
        txtRespostaAPI.Text = JsonConvert.SerializeObject(ObjBoleto, Formatting.Indented)

        Dim rawresp As String
        rawresp = txtRespostaAPI.Text

        Dim resposta = Newtonsoft.Json.JsonConvert.DeserializeObject(Of RemessaResposta)(rawresp)

        txtProtocoloRemessa.Text = resposta.protocolo

        Dim remessa = JsonConvert.SerializeObject(resposta.remessas, Formatting.Indented)

        Dim respostaRemessa() = Newtonsoft.Json.JsonConvert.DeserializeObject(Of arrayRemessa())(remessa)

        txtRemessa.Text = respostaRemessa(0).arquivo


    End Sub
End Class

