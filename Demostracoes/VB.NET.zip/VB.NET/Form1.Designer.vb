﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lblProtocolo = New System.Windows.Forms.Label()
        Me.button1 = New System.Windows.Forms.Button()
        Me.label26 = New System.Windows.Forms.Label()
        Me.txtNumeroControle = New System.Windows.Forms.TextBox()
        Me.label25 = New System.Windows.Forms.Label()
        Me.txtCodBarras = New System.Windows.Forms.TextBox()
        Me.label24 = New System.Windows.Forms.Label()
        Me.txtBeneficiarioCnpj = New System.Windows.Forms.TextBox()
        Me.btnGerarRemessa = New System.Windows.Forms.Button()
        Me.label27 = New System.Windows.Forms.Label()
        Me.txtIdintegracao = New System.Windows.Forms.TextBox()
        Me.label16 = New System.Windows.Forms.Label()
        Me.txtBeneficiarioNome = New System.Windows.Forms.TextBox()
        Me.label17 = New System.Windows.Forms.Label()
        Me.txtProtocoloRemessa = New System.Windows.Forms.TextBox()
        Me.txtMoraMulta = New System.Windows.Forms.TextBox()
        Me.txtEntradaJSON = New System.Windows.Forms.TextBox()
        Me.label18 = New System.Windows.Forms.Label()
        Me.txtDescontoAbatimento = New System.Windows.Forms.TextBox()
        Me.label19 = New System.Windows.Forms.Label()
        Me.txtvalorPagamento = New System.Windows.Forms.TextBox()
        Me.label20 = New System.Windows.Forms.Label()
        Me.label21 = New System.Windows.Forms.Label()
        Me.groupBox3 = New System.Windows.Forms.GroupBox()
        Me.txtFormaPagamento = New System.Windows.Forms.TextBox()
        Me.groupBox2 = New System.Windows.Forms.GroupBox()
        Me.txtRemessa = New System.Windows.Forms.TextBox()
        Me.txtTipoPagamento = New System.Windows.Forms.TextBox()
        Me.label22 = New System.Windows.Forms.Label()
        Me.txtDataPagamento = New System.Windows.Forms.TextBox()
        Me.label23 = New System.Windows.Forms.Label()
        Me.txtNomeFavorecido = New System.Windows.Forms.TextBox()
        Me.label15 = New System.Windows.Forms.Label()
        Me.label14 = New System.Windows.Forms.Label()
        Me.label13 = New System.Windows.Forms.Label()
        Me.txtEmpresaDebitadaCep = New System.Windows.Forms.TextBox()
        Me.label12 = New System.Windows.Forms.Label()
        Me.txtEmpresaDebitadaEstado = New System.Windows.Forms.TextBox()
        Me.txtRespostaAPI = New System.Windows.Forms.TextBox()
        Me.txtEmpresaDebitadaCidade = New System.Windows.Forms.TextBox()
        Me.groupBox4 = New System.Windows.Forms.GroupBox()
        Me.groupBox1 = New System.Windows.Forms.GroupBox()
        Me.label11 = New System.Windows.Forms.Label()
        Me.txtEmpresaDebitadaComplemento = New System.Windows.Forms.TextBox()
        Me.label10 = New System.Windows.Forms.Label()
        Me.txtEmpresaDebitadaNumero = New System.Windows.Forms.TextBox()
        Me.label9 = New System.Windows.Forms.Label()
        Me.txtEmpresaDebitadaEndereco = New System.Windows.Forms.TextBox()
        Me.label8 = New System.Windows.Forms.Label()
        Me.txtContaDebitadaNomeEmpresa = New System.Windows.Forms.TextBox()
        Me.label7 = New System.Windows.Forms.Label()
        Me.txtContaDebitadaCpfCnpj = New System.Windows.Forms.TextBox()
        Me.label6 = New System.Windows.Forms.Label()
        Me.label5 = New System.Windows.Forms.Label()
        Me.label4 = New System.Windows.Forms.Label()
        Me.label3 = New System.Windows.Forms.Label()
        Me.label2 = New System.Windows.Forms.Label()
        Me.label1 = New System.Windows.Forms.Label()
        Me.txtContaDebitadaDac = New System.Windows.Forms.TextBox()
        Me.txtContaDebitadaNumero = New System.Windows.Forms.TextBox()
        Me.txtcontaDebitadaAgencia = New System.Windows.Forms.TextBox()
        Me.txtContaDebitadaCodigoBanco = New System.Windows.Forms.TextBox()
        Me.groupBox3.SuspendLayout()
        Me.groupBox2.SuspendLayout()
        Me.groupBox4.SuspendLayout()
        Me.groupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'lblProtocolo
        '
        Me.lblProtocolo.AutoSize = True
        Me.lblProtocolo.Location = New System.Drawing.Point(6, 90)
        Me.lblProtocolo.Name = "lblProtocolo"
        Me.lblProtocolo.Size = New System.Drawing.Size(52, 13)
        Me.lblProtocolo.TabIndex = 52
        Me.lblProtocolo.Text = "Protocolo"
        '
        'button1
        '
        Me.button1.Location = New System.Drawing.Point(355, 232)
        Me.button1.Name = "button1"
        Me.button1.Size = New System.Drawing.Size(100, 25)
        Me.button1.TabIndex = 49
        Me.button1.Text = "Incluir Pagamento"
        Me.button1.UseVisualStyleBackColor = True
        '
        'label26
        '
        Me.label26.AutoSize = True
        Me.label26.Location = New System.Drawing.Point(243, 221)
        Me.label26.Name = "label26"
        Me.label26.Size = New System.Drawing.Size(101, 13)
        Me.label26.TabIndex = 48
        Me.label26.Text = "Numero de Controle"
        '
        'txtNumeroControle
        '
        Me.txtNumeroControle.Location = New System.Drawing.Point(246, 235)
        Me.txtNumeroControle.Name = "txtNumeroControle"
        Me.txtNumeroControle.Size = New System.Drawing.Size(100, 20)
        Me.txtNumeroControle.TabIndex = 47
        Me.txtNumeroControle.Text = "TESTENUMERO"
        '
        'label25
        '
        Me.label25.AutoSize = True
        Me.label25.Location = New System.Drawing.Point(352, 184)
        Me.label25.Name = "label25"
        Me.label25.Size = New System.Drawing.Size(88, 13)
        Me.label25.TabIndex = 46
        Me.label25.Text = "Código de Barras"
        '
        'txtCodBarras
        '
        Me.txtCodBarras.Location = New System.Drawing.Point(355, 198)
        Me.txtCodBarras.Name = "txtCodBarras"
        Me.txtCodBarras.Size = New System.Drawing.Size(100, 20)
        Me.txtCodBarras.TabIndex = 45
        Me.txtCodBarras.Text = "00193787500000010000000003096952000000099117"
        '
        'label24
        '
        Me.label24.AutoSize = True
        Me.label24.Location = New System.Drawing.Point(243, 184)
        Me.label24.Name = "label24"
        Me.label24.Size = New System.Drawing.Size(117, 13)
        Me.label24.TabIndex = 44
        Me.label24.Text = "Beneficiário CPF/CNPJ"
        '
        'txtBeneficiarioCnpj
        '
        Me.txtBeneficiarioCnpj.Location = New System.Drawing.Point(246, 198)
        Me.txtBeneficiarioCnpj.Name = "txtBeneficiarioCnpj"
        Me.txtBeneficiarioCnpj.Size = New System.Drawing.Size(100, 20)
        Me.txtBeneficiarioCnpj.TabIndex = 43
        Me.txtBeneficiarioCnpj.Text = "10.00"
        '
        'btnGerarRemessa
        '
        Me.btnGerarRemessa.Location = New System.Drawing.Point(9, 62)
        Me.btnGerarRemessa.Name = "btnGerarRemessa"
        Me.btnGerarRemessa.Size = New System.Drawing.Size(100, 24)
        Me.btnGerarRemessa.TabIndex = 50
        Me.btnGerarRemessa.Text = "Gerar Remessa"
        Me.btnGerarRemessa.UseVisualStyleBackColor = True
        '
        'label27
        '
        Me.label27.AutoSize = True
        Me.label27.Location = New System.Drawing.Point(6, 22)
        Me.label27.Name = "label27"
        Me.label27.Size = New System.Drawing.Size(66, 13)
        Me.label27.TabIndex = 32
        Me.label27.Text = "Idintegracao"
        '
        'txtIdintegracao
        '
        Me.txtIdintegracao.Location = New System.Drawing.Point(9, 36)
        Me.txtIdintegracao.Name = "txtIdintegracao"
        Me.txtIdintegracao.Size = New System.Drawing.Size(100, 20)
        Me.txtIdintegracao.TabIndex = 31
        '
        'label16
        '
        Me.label16.AutoSize = True
        Me.label16.Location = New System.Drawing.Point(352, 147)
        Me.label16.Name = "label16"
        Me.label16.Size = New System.Drawing.Size(93, 13)
        Me.label16.TabIndex = 42
        Me.label16.Text = "Beneficiário Nome"
        '
        'txtBeneficiarioNome
        '
        Me.txtBeneficiarioNome.Location = New System.Drawing.Point(355, 161)
        Me.txtBeneficiarioNome.Name = "txtBeneficiarioNome"
        Me.txtBeneficiarioNome.Size = New System.Drawing.Size(100, 20)
        Me.txtBeneficiarioNome.TabIndex = 41
        Me.txtBeneficiarioNome.Text = "Beneficiario Nome"
        '
        'label17
        '
        Me.label17.AutoSize = True
        Me.label17.Location = New System.Drawing.Point(243, 147)
        Me.label17.Name = "label17"
        Me.label17.Size = New System.Drawing.Size(104, 13)
        Me.label17.TabIndex = 40
        Me.label17.Text = "Valor de Mora/Multa"
        '
        'txtProtocoloRemessa
        '
        Me.txtProtocoloRemessa.Location = New System.Drawing.Point(9, 104)
        Me.txtProtocoloRemessa.Name = "txtProtocoloRemessa"
        Me.txtProtocoloRemessa.Size = New System.Drawing.Size(100, 20)
        Me.txtProtocoloRemessa.TabIndex = 51
        '
        'txtMoraMulta
        '
        Me.txtMoraMulta.Location = New System.Drawing.Point(246, 161)
        Me.txtMoraMulta.Name = "txtMoraMulta"
        Me.txtMoraMulta.Size = New System.Drawing.Size(100, 20)
        Me.txtMoraMulta.TabIndex = 39
        Me.txtMoraMulta.Text = "0"
        '
        'txtEntradaJSON
        '
        Me.txtEntradaJSON.Location = New System.Drawing.Point(13, 24)
        Me.txtEntradaJSON.Multiline = True
        Me.txtEntradaJSON.Name = "txtEntradaJSON"
        Me.txtEntradaJSON.Size = New System.Drawing.Size(442, 284)
        Me.txtEntradaJSON.TabIndex = 55
        '
        'label18
        '
        Me.label18.AutoSize = True
        Me.label18.Location = New System.Drawing.Point(352, 110)
        Me.label18.Name = "label18"
        Me.label18.Size = New System.Drawing.Size(111, 13)
        Me.label18.TabIndex = 38
        Me.label18.Text = "Desconto/Abatimento"
        '
        'txtDescontoAbatimento
        '
        Me.txtDescontoAbatimento.Location = New System.Drawing.Point(355, 124)
        Me.txtDescontoAbatimento.Name = "txtDescontoAbatimento"
        Me.txtDescontoAbatimento.Size = New System.Drawing.Size(100, 20)
        Me.txtDescontoAbatimento.TabIndex = 37
        Me.txtDescontoAbatimento.Text = "0"
        '
        'label19
        '
        Me.label19.AutoSize = True
        Me.label19.Location = New System.Drawing.Point(243, 110)
        Me.label19.Name = "label19"
        Me.label19.Size = New System.Drawing.Size(88, 13)
        Me.label19.TabIndex = 36
        Me.label19.Text = "Valor Pagamento"
        '
        'txtvalorPagamento
        '
        Me.txtvalorPagamento.Location = New System.Drawing.Point(246, 124)
        Me.txtvalorPagamento.Name = "txtvalorPagamento"
        Me.txtvalorPagamento.Size = New System.Drawing.Size(100, 20)
        Me.txtvalorPagamento.TabIndex = 35
        Me.txtvalorPagamento.Text = "10.00"
        '
        'label20
        '
        Me.label20.AutoSize = True
        Me.label20.Location = New System.Drawing.Point(352, 73)
        Me.label20.Name = "label20"
        Me.label20.Size = New System.Drawing.Size(93, 13)
        Me.label20.TabIndex = 34
        Me.label20.Text = "Forma Pagamento"
        '
        'label21
        '
        Me.label21.AutoSize = True
        Me.label21.Location = New System.Drawing.Point(243, 73)
        Me.label21.Name = "label21"
        Me.label21.Size = New System.Drawing.Size(85, 13)
        Me.label21.TabIndex = 32
        Me.label21.Text = "Tipo Pagamento"
        '
        'groupBox3
        '
        Me.groupBox3.Controls.Add(Me.txtEntradaJSON)
        Me.groupBox3.Location = New System.Drawing.Point(12, 305)
        Me.groupBox3.Name = "groupBox3"
        Me.groupBox3.Size = New System.Drawing.Size(470, 327)
        Me.groupBox3.TabIndex = 60
        Me.groupBox3.TabStop = False
        Me.groupBox3.Text = "Entrada"
        '
        'txtFormaPagamento
        '
        Me.txtFormaPagamento.Location = New System.Drawing.Point(355, 87)
        Me.txtFormaPagamento.Name = "txtFormaPagamento"
        Me.txtFormaPagamento.Size = New System.Drawing.Size(100, 20)
        Me.txtFormaPagamento.TabIndex = 33
        Me.txtFormaPagamento.Text = "31"
        '
        'groupBox2
        '
        Me.groupBox2.Controls.Add(Me.txtRemessa)
        Me.groupBox2.Controls.Add(Me.lblProtocolo)
        Me.groupBox2.Controls.Add(Me.txtProtocoloRemessa)
        Me.groupBox2.Controls.Add(Me.btnGerarRemessa)
        Me.groupBox2.Controls.Add(Me.label27)
        Me.groupBox2.Controls.Add(Me.txtIdintegracao)
        Me.groupBox2.Location = New System.Drawing.Point(488, 12)
        Me.groupBox2.Name = "groupBox2"
        Me.groupBox2.Size = New System.Drawing.Size(470, 287)
        Me.groupBox2.TabIndex = 59
        Me.groupBox2.TabStop = False
        Me.groupBox2.Text = "Remessa"
        '
        'txtRemessa
        '
        Me.txtRemessa.Location = New System.Drawing.Point(115, 36)
        Me.txtRemessa.Multiline = True
        Me.txtRemessa.Name = "txtRemessa"
        Me.txtRemessa.Size = New System.Drawing.Size(340, 235)
        Me.txtRemessa.TabIndex = 54
        '
        'txtTipoPagamento
        '
        Me.txtTipoPagamento.Location = New System.Drawing.Point(246, 87)
        Me.txtTipoPagamento.Name = "txtTipoPagamento"
        Me.txtTipoPagamento.Size = New System.Drawing.Size(100, 20)
        Me.txtTipoPagamento.TabIndex = 31
        Me.txtTipoPagamento.Text = "20"
        '
        'label22
        '
        Me.label22.AutoSize = True
        Me.label22.Location = New System.Drawing.Point(352, 36)
        Me.label22.Name = "label22"
        Me.label22.Size = New System.Drawing.Size(102, 13)
        Me.label22.TabIndex = 30
        Me.label22.Text = "Data do Pagamento"
        '
        'txtDataPagamento
        '
        Me.txtDataPagamento.Location = New System.Drawing.Point(355, 50)
        Me.txtDataPagamento.Name = "txtDataPagamento"
        Me.txtDataPagamento.Size = New System.Drawing.Size(100, 20)
        Me.txtDataPagamento.TabIndex = 29
        Me.txtDataPagamento.Text = "11042019"
        '
        'label23
        '
        Me.label23.AutoSize = True
        Me.label23.Location = New System.Drawing.Point(243, 36)
        Me.label23.Name = "label23"
        Me.label23.Size = New System.Drawing.Size(106, 13)
        Me.label23.TabIndex = 28
        Me.label23.Text = "Nome do Favorecido"
        '
        'txtNomeFavorecido
        '
        Me.txtNomeFavorecido.Location = New System.Drawing.Point(246, 50)
        Me.txtNomeFavorecido.Name = "txtNomeFavorecido"
        Me.txtNomeFavorecido.Size = New System.Drawing.Size(100, 20)
        Me.txtNomeFavorecido.TabIndex = 27
        Me.txtNomeFavorecido.Text = "Teste Favorecido"
        '
        'label15
        '
        Me.label15.AutoSize = True
        Me.label15.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.label15.Location = New System.Drawing.Point(236, 21)
        Me.label15.Name = "label15"
        Me.label15.Size = New System.Drawing.Size(110, 15)
        Me.label15.TabIndex = 26
        Me.label15.Text = "Conta Debitada "
        '
        'label14
        '
        Me.label14.AutoSize = True
        Me.label14.Location = New System.Drawing.Point(119, 237)
        Me.label14.Name = "label14"
        Me.label14.Size = New System.Drawing.Size(58, 13)
        Me.label14.TabIndex = 25
        Me.label14.Text = "ED Estado"
        '
        'label13
        '
        Me.label13.AutoSize = True
        Me.label13.Location = New System.Drawing.Point(10, 237)
        Me.label13.Name = "label13"
        Me.label13.Size = New System.Drawing.Size(46, 13)
        Me.label13.TabIndex = 23
        Me.label13.Text = "ED CEP"
        '
        'txtEmpresaDebitadaCep
        '
        Me.txtEmpresaDebitadaCep.Location = New System.Drawing.Point(13, 251)
        Me.txtEmpresaDebitadaCep.Name = "txtEmpresaDebitadaCep"
        Me.txtEmpresaDebitadaCep.Size = New System.Drawing.Size(100, 20)
        Me.txtEmpresaDebitadaCep.TabIndex = 22
        Me.txtEmpresaDebitadaCep.Text = "86890000"
        '
        'label12
        '
        Me.label12.AutoSize = True
        Me.label12.Location = New System.Drawing.Point(119, 200)
        Me.label12.Name = "label12"
        Me.label12.Size = New System.Drawing.Size(58, 13)
        Me.label12.TabIndex = 21
        Me.label12.Text = "ED Cidade"
        '
        'txtEmpresaDebitadaEstado
        '
        Me.txtEmpresaDebitadaEstado.Location = New System.Drawing.Point(122, 251)
        Me.txtEmpresaDebitadaEstado.Name = "txtEmpresaDebitadaEstado"
        Me.txtEmpresaDebitadaEstado.Size = New System.Drawing.Size(100, 20)
        Me.txtEmpresaDebitadaEstado.TabIndex = 24
        Me.txtEmpresaDebitadaEstado.Text = "PR"
        '
        'txtRespostaAPI
        '
        Me.txtRespostaAPI.Location = New System.Drawing.Point(13, 24)
        Me.txtRespostaAPI.Multiline = True
        Me.txtRespostaAPI.Name = "txtRespostaAPI"
        Me.txtRespostaAPI.Size = New System.Drawing.Size(442, 284)
        Me.txtRespostaAPI.TabIndex = 55
        '
        'txtEmpresaDebitadaCidade
        '
        Me.txtEmpresaDebitadaCidade.Location = New System.Drawing.Point(122, 214)
        Me.txtEmpresaDebitadaCidade.Name = "txtEmpresaDebitadaCidade"
        Me.txtEmpresaDebitadaCidade.Size = New System.Drawing.Size(100, 20)
        Me.txtEmpresaDebitadaCidade.TabIndex = 20
        Me.txtEmpresaDebitadaCidade.Text = "Cambira"
        '
        'groupBox4
        '
        Me.groupBox4.Controls.Add(Me.txtRespostaAPI)
        Me.groupBox4.Location = New System.Drawing.Point(488, 305)
        Me.groupBox4.Name = "groupBox4"
        Me.groupBox4.Size = New System.Drawing.Size(470, 327)
        Me.groupBox4.TabIndex = 61
        Me.groupBox4.TabStop = False
        Me.groupBox4.Text = "Resposta"
        '
        'groupBox1
        '
        Me.groupBox1.Controls.Add(Me.button1)
        Me.groupBox1.Controls.Add(Me.label26)
        Me.groupBox1.Controls.Add(Me.txtNumeroControle)
        Me.groupBox1.Controls.Add(Me.label25)
        Me.groupBox1.Controls.Add(Me.txtCodBarras)
        Me.groupBox1.Controls.Add(Me.label24)
        Me.groupBox1.Controls.Add(Me.txtBeneficiarioCnpj)
        Me.groupBox1.Controls.Add(Me.label16)
        Me.groupBox1.Controls.Add(Me.txtBeneficiarioNome)
        Me.groupBox1.Controls.Add(Me.label17)
        Me.groupBox1.Controls.Add(Me.txtMoraMulta)
        Me.groupBox1.Controls.Add(Me.label18)
        Me.groupBox1.Controls.Add(Me.txtDescontoAbatimento)
        Me.groupBox1.Controls.Add(Me.label19)
        Me.groupBox1.Controls.Add(Me.txtvalorPagamento)
        Me.groupBox1.Controls.Add(Me.label20)
        Me.groupBox1.Controls.Add(Me.txtFormaPagamento)
        Me.groupBox1.Controls.Add(Me.label21)
        Me.groupBox1.Controls.Add(Me.txtTipoPagamento)
        Me.groupBox1.Controls.Add(Me.label22)
        Me.groupBox1.Controls.Add(Me.txtDataPagamento)
        Me.groupBox1.Controls.Add(Me.label23)
        Me.groupBox1.Controls.Add(Me.txtNomeFavorecido)
        Me.groupBox1.Controls.Add(Me.label15)
        Me.groupBox1.Controls.Add(Me.label14)
        Me.groupBox1.Controls.Add(Me.txtEmpresaDebitadaEstado)
        Me.groupBox1.Controls.Add(Me.label13)
        Me.groupBox1.Controls.Add(Me.txtEmpresaDebitadaCep)
        Me.groupBox1.Controls.Add(Me.label12)
        Me.groupBox1.Controls.Add(Me.txtEmpresaDebitadaCidade)
        Me.groupBox1.Controls.Add(Me.label11)
        Me.groupBox1.Controls.Add(Me.txtEmpresaDebitadaComplemento)
        Me.groupBox1.Controls.Add(Me.label10)
        Me.groupBox1.Controls.Add(Me.txtEmpresaDebitadaNumero)
        Me.groupBox1.Controls.Add(Me.label9)
        Me.groupBox1.Controls.Add(Me.txtEmpresaDebitadaEndereco)
        Me.groupBox1.Controls.Add(Me.label8)
        Me.groupBox1.Controls.Add(Me.txtContaDebitadaNomeEmpresa)
        Me.groupBox1.Controls.Add(Me.label7)
        Me.groupBox1.Controls.Add(Me.txtContaDebitadaCpfCnpj)
        Me.groupBox1.Controls.Add(Me.label6)
        Me.groupBox1.Controls.Add(Me.label5)
        Me.groupBox1.Controls.Add(Me.label4)
        Me.groupBox1.Controls.Add(Me.label3)
        Me.groupBox1.Controls.Add(Me.label2)
        Me.groupBox1.Controls.Add(Me.label1)
        Me.groupBox1.Controls.Add(Me.txtContaDebitadaDac)
        Me.groupBox1.Controls.Add(Me.txtContaDebitadaNumero)
        Me.groupBox1.Controls.Add(Me.txtcontaDebitadaAgencia)
        Me.groupBox1.Controls.Add(Me.txtContaDebitadaCodigoBanco)
        Me.groupBox1.Location = New System.Drawing.Point(12, 12)
        Me.groupBox1.Name = "groupBox1"
        Me.groupBox1.Size = New System.Drawing.Size(470, 287)
        Me.groupBox1.TabIndex = 58
        Me.groupBox1.TabStop = False
        Me.groupBox1.Text = "Incluir Pagamento"
        '
        'label11
        '
        Me.label11.AutoSize = True
        Me.label11.Location = New System.Drawing.Point(10, 200)
        Me.label11.Name = "label11"
        Me.label11.Size = New System.Drawing.Size(89, 13)
        Me.label11.TabIndex = 19
        Me.label11.Text = "ED Complemento"
        '
        'txtEmpresaDebitadaComplemento
        '
        Me.txtEmpresaDebitadaComplemento.Location = New System.Drawing.Point(13, 214)
        Me.txtEmpresaDebitadaComplemento.Name = "txtEmpresaDebitadaComplemento"
        Me.txtEmpresaDebitadaComplemento.Size = New System.Drawing.Size(100, 20)
        Me.txtEmpresaDebitadaComplemento.TabIndex = 18
        Me.txtEmpresaDebitadaComplemento.Text = "Apto 704"
        '
        'label10
        '
        Me.label10.AutoSize = True
        Me.label10.Location = New System.Drawing.Point(119, 163)
        Me.label10.Name = "label10"
        Me.label10.Size = New System.Drawing.Size(114, 13)
        Me.label10.TabIndex = 17
        Me.label10.Text = "ED Endereço Numero "
        '
        'txtEmpresaDebitadaNumero
        '
        Me.txtEmpresaDebitadaNumero.Location = New System.Drawing.Point(122, 177)
        Me.txtEmpresaDebitadaNumero.Name = "txtEmpresaDebitadaNumero"
        Me.txtEmpresaDebitadaNumero.Size = New System.Drawing.Size(100, 20)
        Me.txtEmpresaDebitadaNumero.TabIndex = 16
        Me.txtEmpresaDebitadaNumero.Text = "54"
        '
        'label9
        '
        Me.label9.AutoSize = True
        Me.label9.Location = New System.Drawing.Point(10, 163)
        Me.label9.Name = "label9"
        Me.label9.Size = New System.Drawing.Size(71, 13)
        Me.label9.TabIndex = 15
        Me.label9.Text = "ED Endereço"
        '
        'txtEmpresaDebitadaEndereco
        '
        Me.txtEmpresaDebitadaEndereco.Location = New System.Drawing.Point(13, 177)
        Me.txtEmpresaDebitadaEndereco.Name = "txtEmpresaDebitadaEndereco"
        Me.txtEmpresaDebitadaEndereco.Size = New System.Drawing.Size(100, 20)
        Me.txtEmpresaDebitadaEndereco.TabIndex = 14
        Me.txtEmpresaDebitadaEndereco.Text = "Endereço Teste"
        '
        'label8
        '
        Me.label8.AutoSize = True
        Me.label8.Location = New System.Drawing.Point(116, 126)
        Me.label8.Name = "label8"
        Me.label8.Size = New System.Drawing.Size(97, 13)
        Me.label8.TabIndex = 13
        Me.label8.Text = "CD Nome Empresa"
        '
        'txtContaDebitadaNomeEmpresa
        '
        Me.txtContaDebitadaNomeEmpresa.Location = New System.Drawing.Point(119, 140)
        Me.txtContaDebitadaNomeEmpresa.Name = "txtContaDebitadaNomeEmpresa"
        Me.txtContaDebitadaNomeEmpresa.Size = New System.Drawing.Size(100, 20)
        Me.txtContaDebitadaNomeEmpresa.TabIndex = 12
        Me.txtContaDebitadaNomeEmpresa.Text = "Teste Empresa"
        '
        'label7
        '
        Me.label7.AutoSize = True
        Me.label7.Location = New System.Drawing.Point(10, 126)
        Me.label7.Name = "label7"
        Me.label7.Size = New System.Drawing.Size(77, 13)
        Me.label7.TabIndex = 11
        Me.label7.Text = "CD CNPJ/CPF"
        '
        'txtContaDebitadaCpfCnpj
        '
        Me.txtContaDebitadaCpfCnpj.Location = New System.Drawing.Point(13, 140)
        Me.txtContaDebitadaCpfCnpj.Name = "txtContaDebitadaCpfCnpj"
        Me.txtContaDebitadaCpfCnpj.Size = New System.Drawing.Size(100, 20)
        Me.txtContaDebitadaCpfCnpj.TabIndex = 10
        Me.txtContaDebitadaCpfCnpj.Text = "01001001000113"
        '
        'label6
        '
        Me.label6.AutoSize = True
        Me.label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.label6.Location = New System.Drawing.Point(3, 111)
        Me.label6.Name = "label6"
        Me.label6.Size = New System.Drawing.Size(130, 15)
        Me.label6.TabIndex = 9
        Me.label6.Text = "Empresa Debitada "
        '
        'label5
        '
        Me.label5.AutoSize = True
        Me.label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.label5.Location = New System.Drawing.Point(3, 20)
        Me.label5.Name = "label5"
        Me.label5.Size = New System.Drawing.Size(110, 15)
        Me.label5.TabIndex = 8
        Me.label5.Text = "Conta Debitada "
        '
        'label4
        '
        Me.label4.AutoSize = True
        Me.label4.Location = New System.Drawing.Point(116, 35)
        Me.label4.Name = "label4"
        Me.label4.Size = New System.Drawing.Size(62, 13)
        Me.label4.TabIndex = 7
        Me.label4.Text = "CD Numero"
        '
        'label3
        '
        Me.label3.AutoSize = True
        Me.label3.Location = New System.Drawing.Point(116, 72)
        Me.label3.Name = "label3"
        Me.label3.Size = New System.Drawing.Size(47, 13)
        Me.label3.TabIndex = 6
        Me.label3.Text = "CD DAC"
        '
        'label2
        '
        Me.label2.AutoSize = True
        Me.label2.Location = New System.Drawing.Point(10, 74)
        Me.label2.Name = "label2"
        Me.label2.Size = New System.Drawing.Size(64, 13)
        Me.label2.TabIndex = 5
        Me.label2.Text = "CD Agencia"
        '
        'label1
        '
        Me.label1.AutoSize = True
        Me.label1.Location = New System.Drawing.Point(10, 35)
        Me.label1.Name = "label1"
        Me.label1.Size = New System.Drawing.Size(92, 13)
        Me.label1.TabIndex = 4
        Me.label1.Text = "CD Código Banco"
        '
        'txtContaDebitadaDac
        '
        Me.txtContaDebitadaDac.Location = New System.Drawing.Point(119, 88)
        Me.txtContaDebitadaDac.Name = "txtContaDebitadaDac"
        Me.txtContaDebitadaDac.Size = New System.Drawing.Size(100, 20)
        Me.txtContaDebitadaDac.TabIndex = 3
        Me.txtContaDebitadaDac.Text = "3"
        '
        'txtContaDebitadaNumero
        '
        Me.txtContaDebitadaNumero.Location = New System.Drawing.Point(119, 51)
        Me.txtContaDebitadaNumero.Name = "txtContaDebitadaNumero"
        Me.txtContaDebitadaNumero.Size = New System.Drawing.Size(100, 20)
        Me.txtContaDebitadaNumero.TabIndex = 2
        Me.txtContaDebitadaNumero.Text = "40473"
        '
        'txtcontaDebitadaAgencia
        '
        Me.txtcontaDebitadaAgencia.Location = New System.Drawing.Point(13, 88)
        Me.txtcontaDebitadaAgencia.Name = "txtcontaDebitadaAgencia"
        Me.txtcontaDebitadaAgencia.Size = New System.Drawing.Size(100, 20)
        Me.txtcontaDebitadaAgencia.TabIndex = 1
        Me.txtcontaDebitadaAgencia.Text = "3788"
        '
        'txtContaDebitadaCodigoBanco
        '
        Me.txtContaDebitadaCodigoBanco.Location = New System.Drawing.Point(13, 51)
        Me.txtContaDebitadaCodigoBanco.Name = "txtContaDebitadaCodigoBanco"
        Me.txtContaDebitadaCodigoBanco.Size = New System.Drawing.Size(100, 20)
        Me.txtContaDebitadaCodigoBanco.TabIndex = 0
        Me.txtContaDebitadaCodigoBanco.Text = "341"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(968, 645)
        Me.Controls.Add(Me.groupBox3)
        Me.Controls.Add(Me.groupBox2)
        Me.Controls.Add(Me.groupBox4)
        Me.Controls.Add(Me.groupBox1)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.groupBox3.ResumeLayout(False)
        Me.groupBox3.PerformLayout()
        Me.groupBox2.ResumeLayout(False)
        Me.groupBox2.PerformLayout()
        Me.groupBox4.ResumeLayout(False)
        Me.groupBox4.PerformLayout()
        Me.groupBox1.ResumeLayout(False)
        Me.groupBox1.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Private WithEvents lblProtocolo As Label
    Private WithEvents button1 As Button
    Private WithEvents label26 As Label
    Private WithEvents txtNumeroControle As TextBox
    Private WithEvents label25 As Label
    Private WithEvents txtCodBarras As TextBox
    Private WithEvents label24 As Label
    Private WithEvents txtBeneficiarioCnpj As TextBox
    Private WithEvents btnGerarRemessa As Button
    Private WithEvents label27 As Label
    Private WithEvents txtIdintegracao As TextBox
    Private WithEvents label16 As Label
    Private WithEvents txtBeneficiarioNome As TextBox
    Private WithEvents label17 As Label
    Private WithEvents txtProtocoloRemessa As TextBox
    Private WithEvents txtMoraMulta As TextBox
    Private WithEvents txtEntradaJSON As TextBox
    Private WithEvents label18 As Label
    Private WithEvents txtDescontoAbatimento As TextBox
    Private WithEvents label19 As Label
    Private WithEvents txtvalorPagamento As TextBox
    Private WithEvents label20 As Label
    Private WithEvents label21 As Label
    Private WithEvents groupBox3 As GroupBox
    Private WithEvents txtFormaPagamento As TextBox
    Private WithEvents groupBox2 As GroupBox
    Private WithEvents txtRemessa As TextBox
    Private WithEvents txtTipoPagamento As TextBox
    Private WithEvents label22 As Label
    Private WithEvents txtDataPagamento As TextBox
    Private WithEvents label23 As Label
    Private WithEvents txtNomeFavorecido As TextBox
    Private WithEvents label15 As Label
    Private WithEvents label14 As Label
    Private WithEvents label13 As Label
    Private WithEvents txtEmpresaDebitadaCep As TextBox
    Private WithEvents label12 As Label
    Private WithEvents txtEmpresaDebitadaEstado As TextBox
    Private WithEvents txtRespostaAPI As TextBox
    Private WithEvents txtEmpresaDebitadaCidade As TextBox
    Private WithEvents groupBox4 As GroupBox
    Private WithEvents groupBox1 As GroupBox
    Private WithEvents label11 As Label
    Private WithEvents txtEmpresaDebitadaComplemento As TextBox
    Private WithEvents label10 As Label
    Private WithEvents txtEmpresaDebitadaNumero As TextBox
    Private WithEvents label9 As Label
    Private WithEvents txtEmpresaDebitadaEndereco As TextBox
    Private WithEvents label8 As Label
    Private WithEvents txtContaDebitadaNomeEmpresa As TextBox
    Private WithEvents label7 As Label
    Private WithEvents txtContaDebitadaCpfCnpj As TextBox
    Private WithEvents label6 As Label
    Private WithEvents label5 As Label
    Private WithEvents label4 As Label
    Private WithEvents label3 As Label
    Private WithEvents label2 As Label
    Private WithEvents label1 As Label
    Private WithEvents txtContaDebitadaDac As TextBox
    Private WithEvents txtContaDebitadaNumero As TextBox
    Private WithEvents txtcontaDebitadaAgencia As TextBox
    Private WithEvents txtContaDebitadaCodigoBanco As TextBox
End Class
