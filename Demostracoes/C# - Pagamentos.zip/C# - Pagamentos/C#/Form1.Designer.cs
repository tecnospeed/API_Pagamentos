﻿namespace WindowsFormsApplication2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.ConsultarProtocoloRemessa = new System.Windows.Forms.Button();
            this.txtRemessa = new System.Windows.Forms.TextBox();
            this.lblProtocolo = new System.Windows.Forms.Label();
            this.txtProtocoloRemessa = new System.Windows.Forms.TextBox();
            this.btnGerarRemessa = new System.Windows.Forms.Button();
            this.label27 = new System.Windows.Forms.Label();
            this.txtIdintegracao = new System.Windows.Forms.TextBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.txtEntradaJSON = new System.Windows.Forms.TextBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.txtRespostaAPI = new System.Windows.Forms.TextBox();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtAccountHash = new System.Windows.Forms.TextBox();
            this.AlterarPagador = new System.Windows.Forms.Button();
            this.ConsultarPagador = new System.Windows.Forms.Button();
            this.CadastrarPagador = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.txtTokenSH = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txtCNPJSH = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.txtUniqueID = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.CadastrarPagamento = new System.Windows.Forms.Button();
            this.Salarios = new System.Windows.Forms.RadioButton();
            this.BoletosBloquetos = new System.Windows.Forms.RadioButton();
            this.Diversos = new System.Windows.Forms.RadioButton();
            this.TransferenciaBancaria = new System.Windows.Forms.RadioButton();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.label18 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.txtPayerCNPJ = new System.Windows.Forms.TextBox();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.GARE = new System.Windows.Forms.RadioButton();
            this.CadastrarPagamento2 = new System.Windows.Forms.Button();
            this.DPVAT = new System.Windows.Forms.RadioButton();
            this.GPS = new System.Windows.Forms.RadioButton();
            this.IPVA = new System.Windows.Forms.RadioButton();
            this.DARF = new System.Windows.Forms.RadioButton();
            this.UploadRetorno = new System.Windows.Forms.GroupBox();
            this.ConsultarProtocolo = new System.Windows.Forms.Button();
            this.label20 = new System.Windows.Forms.Label();
            this.txtProtocoloRetorno = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.ConsultarPagamento = new System.Windows.Forms.Button();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.groupBox8.SuspendLayout();
            this.UploadRetorno.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.ConsultarProtocoloRemessa);
            this.groupBox2.Controls.Add(this.txtRemessa);
            this.groupBox2.Controls.Add(this.lblProtocolo);
            this.groupBox2.Controls.Add(this.txtProtocoloRemessa);
            this.groupBox2.Controls.Add(this.btnGerarRemessa);
            this.groupBox2.Controls.Add(this.label27);
            this.groupBox2.Controls.Add(this.txtIdintegracao);
            this.groupBox2.Location = new System.Drawing.Point(640, 43);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(336, 174);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Remessa";
            this.groupBox2.Enter += new System.EventHandler(this.groupBox2_Enter);
            // 
            // ConsultarProtocoloRemessa
            // 
            this.ConsultarProtocoloRemessa.Location = new System.Drawing.Point(6, 131);
            this.ConsultarProtocoloRemessa.Name = "ConsultarProtocoloRemessa";
            this.ConsultarProtocoloRemessa.Size = new System.Drawing.Size(100, 24);
            this.ConsultarProtocoloRemessa.TabIndex = 55;
            this.ConsultarProtocoloRemessa.Text = "Consultar";
            this.ConsultarProtocoloRemessa.UseVisualStyleBackColor = true;
            this.ConsultarProtocoloRemessa.Click += new System.EventHandler(this.ConsultarProtocoloRemessa_Click);
            // 
            // txtRemessa
            // 
            this.txtRemessa.Location = new System.Drawing.Point(112, 14);
            this.txtRemessa.Multiline = true;
            this.txtRemessa.Name = "txtRemessa";
            this.txtRemessa.Size = new System.Drawing.Size(215, 141);
            this.txtRemessa.TabIndex = 54;
            // 
            // lblProtocolo
            // 
            this.lblProtocolo.AutoSize = true;
            this.lblProtocolo.Location = new System.Drawing.Point(3, 90);
            this.lblProtocolo.Name = "lblProtocolo";
            this.lblProtocolo.Size = new System.Drawing.Size(52, 13);
            this.lblProtocolo.TabIndex = 52;
            this.lblProtocolo.Text = "Protocolo";
            // 
            // txtProtocoloRemessa
            // 
            this.txtProtocoloRemessa.Location = new System.Drawing.Point(6, 104);
            this.txtProtocoloRemessa.Name = "txtProtocoloRemessa";
            this.txtProtocoloRemessa.Size = new System.Drawing.Size(100, 20);
            this.txtProtocoloRemessa.TabIndex = 51;
            this.txtProtocoloRemessa.TextChanged += new System.EventHandler(this.txtProtocoloRemessa_TextChanged);
            // 
            // btnGerarRemessa
            // 
            this.btnGerarRemessa.Location = new System.Drawing.Point(6, 62);
            this.btnGerarRemessa.Name = "btnGerarRemessa";
            this.btnGerarRemessa.Size = new System.Drawing.Size(100, 24);
            this.btnGerarRemessa.TabIndex = 50;
            this.btnGerarRemessa.Text = "Gerar Remessa";
            this.btnGerarRemessa.UseVisualStyleBackColor = true;
            this.btnGerarRemessa.Click += new System.EventHandler(this.btnGerarRemessa_Click);
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(3, 22);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(66, 13);
            this.label27.TabIndex = 32;
            this.label27.Text = "Idintegracao";
            // 
            // txtIdintegracao
            // 
            this.txtIdintegracao.Location = new System.Drawing.Point(6, 36);
            this.txtIdintegracao.Name = "txtIdintegracao";
            this.txtIdintegracao.Size = new System.Drawing.Size(100, 20);
            this.txtIdintegracao.TabIndex = 31;
            this.txtIdintegracao.Text = "GE2DAYJUGY3GKNDCG43Q";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.txtEntradaJSON);
            this.groupBox3.Location = new System.Drawing.Point(12, 344);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(489, 272);
            this.groupBox3.TabIndex = 3;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Entrada";
            // 
            // txtEntradaJSON
            // 
            this.txtEntradaJSON.Location = new System.Drawing.Point(13, 19);
            this.txtEntradaJSON.Multiline = true;
            this.txtEntradaJSON.Name = "txtEntradaJSON";
            this.txtEntradaJSON.Size = new System.Drawing.Size(460, 243);
            this.txtEntradaJSON.TabIndex = 55;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.txtRespostaAPI);
            this.groupBox4.Location = new System.Drawing.Point(519, 344);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(457, 272);
            this.groupBox4.TabIndex = 57;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Resposta";
            // 
            // txtRespostaAPI
            // 
            this.txtRespostaAPI.Location = new System.Drawing.Point(6, 19);
            this.txtRespostaAPI.Multiline = true;
            this.txtRespostaAPI.Name = "txtRespostaAPI";
            this.txtRespostaAPI.Size = new System.Drawing.Size(442, 243);
            this.txtRespostaAPI.TabIndex = 55;
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.label3);
            this.groupBox5.Controls.Add(this.txtAccountHash);
            this.groupBox5.Controls.Add(this.AlterarPagador);
            this.groupBox5.Controls.Add(this.ConsultarPagador);
            this.groupBox5.Controls.Add(this.CadastrarPagador);
            this.groupBox5.Location = new System.Drawing.Point(17, 118);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(307, 189);
            this.groupBox5.TabIndex = 58;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Pagador";
            this.groupBox5.Enter += new System.EventHandler(this.groupBox5_Enter);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(82, 132);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(75, 13);
            this.label3.TabIndex = 78;
            this.label3.Text = "Account Hash";
            // 
            // txtAccountHash
            // 
            this.txtAccountHash.Location = new System.Drawing.Point(85, 148);
            this.txtAccountHash.Name = "txtAccountHash";
            this.txtAccountHash.Size = new System.Drawing.Size(118, 20);
            this.txtAccountHash.TabIndex = 77;
            // 
            // AlterarPagador
            // 
            this.AlterarPagador.Location = new System.Drawing.Point(85, 60);
            this.AlterarPagador.Name = "AlterarPagador";
            this.AlterarPagador.Size = new System.Drawing.Size(121, 28);
            this.AlterarPagador.TabIndex = 33;
            this.AlterarPagador.Text = "Alterar";
            this.AlterarPagador.UseVisualStyleBackColor = true;
            this.AlterarPagador.Click += new System.EventHandler(this.AlterarPagador_Click);
            // 
            // ConsultarPagador
            // 
            this.ConsultarPagador.Location = new System.Drawing.Point(85, 99);
            this.ConsultarPagador.Name = "ConsultarPagador";
            this.ConsultarPagador.Size = new System.Drawing.Size(121, 28);
            this.ConsultarPagador.TabIndex = 76;
            this.ConsultarPagador.Text = "Consultar";
            this.ConsultarPagador.UseVisualStyleBackColor = true;
            this.ConsultarPagador.Click += new System.EventHandler(this.ConsultarPagador_Click);
            // 
            // CadastrarPagador
            // 
            this.CadastrarPagador.Location = new System.Drawing.Point(85, 22);
            this.CadastrarPagador.Name = "CadastrarPagador";
            this.CadastrarPagador.Size = new System.Drawing.Size(121, 28);
            this.CadastrarPagador.TabIndex = 32;
            this.CadastrarPagador.Text = "Cadastrar";
            this.CadastrarPagador.UseVisualStyleBackColor = true;
            this.CadastrarPagador.Click += new System.EventHandler(this.CadastrarPagador_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(398, 4);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(56, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "Token SH";
            // 
            // txtTokenSH
            // 
            this.txtTokenSH.Location = new System.Drawing.Point(256, 12);
            this.txtTokenSH.Name = "txtTokenSH";
            this.txtTokenSH.Size = new System.Drawing.Size(120, 20);
            this.txtTokenSH.TabIndex = 2;
            this.txtTokenSH.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 16);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(52, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "CNPJ SH";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // txtCNPJSH
            // 
            this.txtCNPJSH.Location = new System.Drawing.Point(58, 12);
            this.txtCNPJSH.Name = "txtCNPJSH";
            this.txtCNPJSH.Size = new System.Drawing.Size(118, 20);
            this.txtCNPJSH.TabIndex = 0;
            this.txtCNPJSH.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.ConsultarPagamento);
            this.groupBox1.Controls.Add(this.txtUniqueID);
            this.groupBox1.Controls.Add(this.textBox1);
            this.groupBox1.Controls.Add(this.CadastrarPagamento);
            this.groupBox1.Controls.Add(this.Salarios);
            this.groupBox1.Controls.Add(this.BoletosBloquetos);
            this.groupBox1.Controls.Add(this.Diversos);
            this.groupBox1.Controls.Add(this.TransferenciaBancaria);
            this.groupBox1.Location = new System.Drawing.Point(330, 43);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(307, 174);
            this.groupBox1.TabIndex = 60;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Pagamento Gerais";
            // 
            // txtUniqueID
            // 
            this.txtUniqueID.AutoSize = true;
            this.txtUniqueID.Location = new System.Drawing.Point(19, 114);
            this.txtUniqueID.Name = "txtUniqueID";
            this.txtUniqueID.Size = new System.Drawing.Size(52, 13);
            this.txtUniqueID.TabIndex = 79;
            this.txtUniqueID.Text = "UniqueID";
            this.txtUniqueID.Click += new System.EventHandler(this.label4_Click);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(17, 129);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(118, 20);
            this.textBox1.TabIndex = 78;
            // 
            // CadastrarPagamento
            // 
            this.CadastrarPagamento.Location = new System.Drawing.Point(84, 75);
            this.CadastrarPagamento.Name = "CadastrarPagamento";
            this.CadastrarPagamento.Size = new System.Drawing.Size(121, 28);
            this.CadastrarPagamento.TabIndex = 76;
            this.CadastrarPagamento.Text = "Cadastrar";
            this.CadastrarPagamento.UseVisualStyleBackColor = true;
            this.CadastrarPagamento.Click += new System.EventHandler(this.CadastrarPagamento_Click);
            // 
            // Salarios
            // 
            this.Salarios.AutoSize = true;
            this.Salarios.Location = new System.Drawing.Point(170, 20);
            this.Salarios.Name = "Salarios";
            this.Salarios.Size = new System.Drawing.Size(62, 17);
            this.Salarios.TabIndex = 63;
            this.Salarios.TabStop = true;
            this.Salarios.Text = "Salários";
            this.Salarios.UseVisualStyleBackColor = true;
            this.Salarios.CheckedChanged += new System.EventHandler(this.radioButton4_CheckedChanged);
            // 
            // BoletosBloquetos
            // 
            this.BoletosBloquetos.AutoSize = true;
            this.BoletosBloquetos.Location = new System.Drawing.Point(17, 41);
            this.BoletosBloquetos.Name = "BoletosBloquetos";
            this.BoletosBloquetos.Size = new System.Drawing.Size(112, 17);
            this.BoletosBloquetos.TabIndex = 62;
            this.BoletosBloquetos.TabStop = true;
            this.BoletosBloquetos.Text = "Boletos/Bloquetos";
            this.BoletosBloquetos.UseVisualStyleBackColor = true;
            this.BoletosBloquetos.CheckedChanged += new System.EventHandler(this.radioButton3_CheckedChanged);
            // 
            // Diversos
            // 
            this.Diversos.AutoSize = true;
            this.Diversos.Location = new System.Drawing.Point(170, 40);
            this.Diversos.Name = "Diversos";
            this.Diversos.Size = new System.Drawing.Size(66, 17);
            this.Diversos.TabIndex = 61;
            this.Diversos.TabStop = true;
            this.Diversos.Text = "Diversos";
            this.Diversos.UseVisualStyleBackColor = true;
            this.Diversos.CheckedChanged += new System.EventHandler(this.radioButton2_CheckedChanged_1);
            // 
            // TransferenciaBancaria
            // 
            this.TransferenciaBancaria.AutoSize = true;
            this.TransferenciaBancaria.Checked = true;
            this.TransferenciaBancaria.Location = new System.Drawing.Point(17, 20);
            this.TransferenciaBancaria.Name = "TransferenciaBancaria";
            this.TransferenciaBancaria.Size = new System.Drawing.Size(135, 17);
            this.TransferenciaBancaria.TabIndex = 60;
            this.TransferenciaBancaria.TabStop = true;
            this.TransferenciaBancaria.Text = "Transferência Bancária";
            this.TransferenciaBancaria.UseVisualStyleBackColor = true;
            this.TransferenciaBancaria.CheckedChanged += new System.EventHandler(this.radioButton1_CheckedChanged);
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.label18);
            this.groupBox6.Controls.Add(this.label17);
            this.groupBox6.Controls.Add(this.txtPayerCNPJ);
            this.groupBox6.Controls.Add(this.txtCNPJSH);
            this.groupBox6.Controls.Add(this.txtTokenSH);
            this.groupBox6.Controls.Add(this.label1);
            this.groupBox6.Location = new System.Drawing.Point(168, 5);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(598, 38);
            this.groupBox6.TabIndex = 61;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Headers";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(395, 16);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(77, 13);
            this.label18.TabIndex = 5;
            this.label18.Text = "CNPJ Pagador";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(198, 16);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(56, 13);
            this.label17.TabIndex = 4;
            this.label17.Text = "Token SH";
            // 
            // txtPayerCNPJ
            // 
            this.txtPayerCNPJ.Location = new System.Drawing.Point(472, 12);
            this.txtPayerCNPJ.Name = "txtPayerCNPJ";
            this.txtPayerCNPJ.Size = new System.Drawing.Size(120, 20);
            this.txtPayerCNPJ.TabIndex = 3;
            // 
            // groupBox8
            // 
            this.groupBox8.Controls.Add(this.GARE);
            this.groupBox8.Controls.Add(this.CadastrarPagamento2);
            this.groupBox8.Controls.Add(this.DPVAT);
            this.groupBox8.Controls.Add(this.GPS);
            this.groupBox8.Controls.Add(this.IPVA);
            this.groupBox8.Controls.Add(this.DARF);
            this.groupBox8.Location = new System.Drawing.Point(330, 223);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(307, 115);
            this.groupBox8.TabIndex = 63;
            this.groupBox8.TabStop = false;
            this.groupBox8.Text = "Pagamento de Tributos e Taxas";
            // 
            // GARE
            // 
            this.GARE.AutoSize = true;
            this.GARE.Location = new System.Drawing.Point(227, 20);
            this.GARE.Name = "GARE";
            this.GARE.Size = new System.Drawing.Size(55, 17);
            this.GARE.TabIndex = 78;
            this.GARE.TabStop = true;
            this.GARE.Text = "GARE";
            this.GARE.UseVisualStyleBackColor = true;
            // 
            // CadastrarPagamento2
            // 
            this.CadastrarPagamento2.Location = new System.Drawing.Point(84, 73);
            this.CadastrarPagamento2.Name = "CadastrarPagamento2";
            this.CadastrarPagamento2.Size = new System.Drawing.Size(121, 28);
            this.CadastrarPagamento2.TabIndex = 76;
            this.CadastrarPagamento2.Text = "Cadastrar";
            this.CadastrarPagamento2.UseVisualStyleBackColor = true;
            this.CadastrarPagamento2.Click += new System.EventHandler(this.button2_Click_1);
            // 
            // DPVAT
            // 
            this.DPVAT.AutoSize = true;
            this.DPVAT.Location = new System.Drawing.Point(132, 20);
            this.DPVAT.Name = "DPVAT";
            this.DPVAT.Size = new System.Drawing.Size(61, 17);
            this.DPVAT.TabIndex = 63;
            this.DPVAT.TabStop = true;
            this.DPVAT.Text = "DPVAT";
            this.DPVAT.UseVisualStyleBackColor = true;
            // 
            // GPS
            // 
            this.GPS.AutoSize = true;
            this.GPS.Location = new System.Drawing.Point(17, 41);
            this.GPS.Name = "GPS";
            this.GPS.Size = new System.Drawing.Size(47, 17);
            this.GPS.TabIndex = 62;
            this.GPS.TabStop = true;
            this.GPS.Text = "GPS";
            this.GPS.UseVisualStyleBackColor = true;
            // 
            // IPVA
            // 
            this.IPVA.AutoSize = true;
            this.IPVA.Location = new System.Drawing.Point(132, 41);
            this.IPVA.Name = "IPVA";
            this.IPVA.Size = new System.Drawing.Size(49, 17);
            this.IPVA.TabIndex = 61;
            this.IPVA.TabStop = true;
            this.IPVA.Text = "IPVA";
            this.IPVA.UseVisualStyleBackColor = true;
            // 
            // DARF
            // 
            this.DARF.AutoSize = true;
            this.DARF.Checked = true;
            this.DARF.Location = new System.Drawing.Point(17, 20);
            this.DARF.Name = "DARF";
            this.DARF.Size = new System.Drawing.Size(54, 17);
            this.DARF.TabIndex = 60;
            this.DARF.TabStop = true;
            this.DARF.Text = "DARF";
            this.DARF.UseVisualStyleBackColor = true;
            // 
            // UploadRetorno
            // 
            this.UploadRetorno.Controls.Add(this.ConsultarProtocolo);
            this.UploadRetorno.Controls.Add(this.label20);
            this.UploadRetorno.Controls.Add(this.txtProtocoloRetorno);
            this.UploadRetorno.Controls.Add(this.button1);
            this.UploadRetorno.Location = new System.Drawing.Point(640, 223);
            this.UploadRetorno.Name = "UploadRetorno";
            this.UploadRetorno.Size = new System.Drawing.Size(336, 115);
            this.UploadRetorno.TabIndex = 64;
            this.UploadRetorno.TabStop = false;
            this.UploadRetorno.Text = "Upload do Retorno";
            this.UploadRetorno.Enter += new System.EventHandler(this.UploadRetorno_Enter);
            // 
            // ConsultarProtocolo
            // 
            this.ConsultarProtocolo.Location = new System.Drawing.Point(188, 74);
            this.ConsultarProtocolo.Name = "ConsultarProtocolo";
            this.ConsultarProtocolo.Size = new System.Drawing.Size(124, 24);
            this.ConsultarProtocolo.TabIndex = 59;
            this.ConsultarProtocolo.Text = "Consultar Protocolo";
            this.ConsultarProtocolo.UseVisualStyleBackColor = true;
            this.ConsultarProtocolo.Click += new System.EventHandler(this.ConsultarProtocolo_Click);
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(17, 62);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(52, 13);
            this.label20.TabIndex = 58;
            this.label20.Text = "Protocolo";
            // 
            // txtProtocoloRetorno
            // 
            this.txtProtocoloRetorno.Location = new System.Drawing.Point(18, 78);
            this.txtProtocoloRetorno.Name = "txtProtocoloRetorno";
            this.txtProtocoloRetorno.Size = new System.Drawing.Size(139, 20);
            this.txtProtocoloRetorno.TabIndex = 57;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(188, 20);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(124, 24);
            this.button1.TabIndex = 56;
            this.button1.Text = "Upload";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // ConsultarPagamento
            // 
            this.ConsultarPagamento.Location = new System.Drawing.Point(161, 124);
            this.ConsultarPagamento.Name = "ConsultarPagamento";
            this.ConsultarPagamento.Size = new System.Drawing.Size(121, 28);
            this.ConsultarPagamento.TabIndex = 80;
            this.ConsultarPagamento.Text = "Consultar Pagamento";
            this.ConsultarPagamento.UseVisualStyleBackColor = true;
            this.ConsultarPagamento.Click += new System.EventHandler(this.ConsultarPagamento_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(988, 628);
            this.Controls.Add(this.UploadRetorno);
            this.Controls.Add(this.groupBox8);
            this.Controls.Add(this.groupBox6);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.groupBox5);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.groupBox2);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.groupBox8.ResumeLayout(false);
            this.groupBox8.PerformLayout();
            this.UploadRetorno.ResumeLayout(false);
            this.UploadRetorno.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label lblProtocolo;
        private System.Windows.Forms.TextBox txtProtocoloRemessa;
        private System.Windows.Forms.Button btnGerarRemessa;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.TextBox txtIdintegracao;
        private System.Windows.Forms.TextBox txtRemessa;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.TextBox txtEntradaJSON;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.TextBox txtRespostaAPI;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.TextBox txtCNPJSH;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtTokenSH;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button CadastrarPagador;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton Salarios;
        private System.Windows.Forms.RadioButton BoletosBloquetos;
        private System.Windows.Forms.RadioButton Diversos;
        private System.Windows.Forms.RadioButton TransferenciaBancaria;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox txtPayerCNPJ;
        private System.Windows.Forms.Button CadastrarPagamento;
        private System.Windows.Forms.Button ConsultarPagador;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.RadioButton GARE;
        private System.Windows.Forms.Button CadastrarPagamento2;
        private System.Windows.Forms.RadioButton DPVAT;
        private System.Windows.Forms.RadioButton GPS;
        private System.Windows.Forms.RadioButton IPVA;
        private System.Windows.Forms.RadioButton DARF;
        private System.Windows.Forms.Button ConsultarProtocoloRemessa;
        private System.Windows.Forms.GroupBox UploadRetorno;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button ConsultarProtocolo;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TextBox txtProtocoloRetorno;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.Button AlterarPagador;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtAccountHash;
        private System.Windows.Forms.Label txtUniqueID;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button ConsultarPagamento;
    }
}

