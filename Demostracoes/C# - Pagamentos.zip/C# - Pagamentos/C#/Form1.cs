﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using RestSharp;
using System.Web.Script.Serialization;

namespace WindowsFormsApplication2
{

    public partial class Form1 : Form
    {
        private string jsonEnvio;

        public Form1()
        {
            InitializeComponent();
        }

        /*  private void button1_Click(object sender, EventArgs e)
          {
              var URLPagamento = "https://zum1meb9r5.execute-api.us-east-1.amazonaws.com/pro/pagamentos";

              IList<Pagamento> ListaPagamento = new List<Pagamento>() {
                  new Pagamento() {
                      tipoPagamento = txtTipoPagamento.Text,
                      formaPagamento = txtFormaPagamento.Text,
                      contaDebitadaCodigoBanco = txtContaDebitadaCodigoBanco.Text,
                      contaDebitadaNumero = txtContaDebitadaNumero.Text,
                      contaDebitadaAgencia = txtcontaDebitadaAgencia.Text,
                      contaDebitadaDac = txtContaDebitadaDac.Text,
                      contaDebitadaCpfCnpj = txtContaDebitadaCpfCnpj.Text,
                      contaDebitadaNomeEmpresa = txtContaDebitadaNomeEmpresa.Text,
                      empresaDebitadaEndereco = txtEmpresaDebitadaEndereco.Text,
                      empresaDebitadaNumero = txtEmpresaDebitadaNumero.Text,
                      empresaDebitadaComplemento = txtEmpresaDebitadaComplemento.Text,
                      empresaDebitadaCidade = txtEmpresaDebitadaCidade.Text,
                      empresaDebitadaCep = txtEmpresaDebitadaCep.Text,
                      empresaDebitadaEstado = txtEmpresaDebitadaEstado.Text,
                      nomeFavorecido = txtNomeFavorecido.Text,
                      dataPagamento = txtDataPagamento.Text,
                      valorPagamento = txtvalorPagamento.Text,
                      valorDescontoAbatimento = txtvalorPagamento.Text,
                      valorMoraMulta = txtMoraMulta.Text,
                      beneficiarioNome = txtBeneficiarioNome.Text,
                      beneficiarioCpfCnpj = txtBeneficiarioCnpj.Text,
                      codigoBarras = txtCodBarras.Text,
                      numeroControle = txtNumeroControle.Text
                  }
              };

              string jsonEnvio = JsonConvert.SerializeObject(ListaPagamento);
              txtEntradaJSON.Text = jsonEnvio;

              var client = new RestClient(URLPagamento);
              var request = new RestRequest(Method.POST);
              request.AddHeader("cache-control", "no-cache");
              request.AddHeader("content-type", "application/json");
              request.AddParameter("application/json", jsonEnvio, ParameterType.RequestBody);

              dynamic jsonResposta = client.Execute(request).Content;
              txtRespostaAPI.Text = jsonResposta;

              List<Pagamento> products = JsonConvert.DeserializeObject<List<Pagamento>>(jsonResposta);
              Pagamento pagamento1 = products[0];

              txtIdintegracao.Text = pagamento1.idIntegracao;
          }
      */
        private void btnGerarRemessa_Click(object sender, EventArgs e)
        {
            var URLRemessa = "https://staging.pagamentobancario.com.br/api/v1/remittance";

            IList<Remessa> listaIdintegracao = new List<Remessa>() {
                new Remessa() {
                    idIntegracao = txtIdintegracao.Text
                }
            };

            string jsonEnvio = JsonConvert.SerializeObject(listaIdintegracao);
            txtEntradaJSON.Text = jsonEnvio;

            var client = new RestClient(URLRemessa);
            var request = new RestRequest(Method.POST);
            request.AddHeader("cache-control", "no-cache");
            request.AddHeader("content-type", "application/json");
            request.AddParameter("application/json", jsonEnvio, ParameterType.RequestBody);

            dynamic jsonResposta = client.Execute(request).Content;
            txtRespostaAPI.Text = jsonResposta;

            RemessaResposta teste = JsonConvert.DeserializeObject<RemessaResposta>(jsonResposta);

            List<arrayRemessa> products = JsonConvert.DeserializeObject<List<arrayRemessa>>(JsonConvert.SerializeObject(teste.remessas));

            txtProtocoloRemessa.Text = teste.protocolo;
            txtRemessa.Text = products[0].arquivo;


        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void groupBox5_Enter(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged_1(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged_2(object sender, EventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void label10_Click(object sender, EventArgs e)
        {

        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox8_TextChanged(object sender, EventArgs e)
        {

        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void label14_Click(object sender, EventArgs e)
        {

        }

        private void CadastrarPagador_Click(object sender, EventArgs e)
        {
            var URLCadastroPagador = "https://staging.pagamentobancario.com.br/api/v1/payer";

            var ListaPagador = new
            {
                name = "CNPJ PARA TESTES",
                cpfCnpj = "01001001000113",
                neighborhood = "DUQUE DE CAXIAS",
                addressNumber = "882",
                zipcode = "87020025",
                state = "PR",
                city = "MARINGA",
                accounts = new object[] { new {
                         bankCode = "341",
                         agency = "1111",
                         agencyDigit =  "2",
                         accountNumber =  "000000066666",
                         accountNumberDigit = "7",
                         accountDac = "3",
                         convenioNumber = "888888",
                         remessaSequential = "1"
                        }
                     }

            };

            JavaScriptSerializer jsonEnvio = new JavaScriptSerializer();
            string strJson = jsonEnvio.Serialize(ListaPagador);
            txtEntradaJSON.Text = strJson;

            var client = new RestClient(URLCadastroPagador);
            var request = new RestRequest(Method.POST);
            request.AddHeader("cache-control", "no-cache");
            request.AddHeader("content-type", "application/json");
            request.AddHeader("tokenSH", txtTokenSH.Text);
            request.AddHeader("cnpjSH", txtCNPJSH.Text);
            request.AddParameter("application/json", strJson, ParameterType.RequestBody);

            dynamic json = JObject.Parse(client.Execute(request).Content);
            txtRespostaAPI.Text = JsonConvert.SerializeObject(json, Formatting.Indented);

            //List<Pagador> products = JsonConvert.DeserializeObject<List<Pagador>>(jsonResposta);
            //Pagador pagamento1 = products[0];

            //txtHashConta.Text = pagamento1.accountHash;
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label11_Click(object sender, EventArgs e)
        {

        }

        private void label16_Click(object sender, EventArgs e)
        {

        }

        private void Endereco_Click(object sender, EventArgs e)
        {

        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void textBox16_TextChanged(object sender, EventArgs e)
        {

        }

        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void radioButton2_CheckedChanged_1(object sender, EventArgs e)
        {

        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void label19_Click(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged_1(object sender, EventArgs e)
        {

        }

        private void radioButton4_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox7_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox9_TextChanged(object sender, EventArgs e)
        {

        }

        private void label25_Click(object sender, EventArgs e)
        {

        }

        private void label26_Click(object sender, EventArgs e)
        {

        }

        private void textBox10_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox11_TextChanged(object sender, EventArgs e)
        {

        }

        private void label28_Click(object sender, EventArgs e)
        {

        }

        private void textBox12_TextChanged(object sender, EventArgs e)
        {

        }

        private void label29_Click(object sender, EventArgs e)
        {

        }

        private void label30_Click(object sender, EventArgs e)
        {

        }

        private void label31_Click(object sender, EventArgs e)
        {

        }

        private void textBox14_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox15_TextChanged(object sender, EventArgs e)
        {

        }

        private void label32_Click(object sender, EventArgs e)
        {

        }

        private void label21_Click(object sender, EventArgs e)
        {

        }

        private void label33_Click(object sender, EventArgs e)
        {

        }

        private void txtDAC_TextChanged(object sender, EventArgs e)
        {

        }

        private void CarregarJSON_Click(object sender, EventArgs e)
        {
            if (TransferenciaBancaria.Checked == true || Salarios.Checked == true)
            {

            }
        }

        private void CadastrarPagamento_Click(object sender, EventArgs e)
        {
            if (TransferenciaBancaria.Checked == true || Salarios.Checked == true)
            {
                var URLPagamento = "https://staging.pagamentobancario.com.br/api/v1/payment/transfer";

                var CamposTransferenciaBancaria = new
                {
                    accountHash = "b8aKHR6tXS",
                    paymentDate = "2019-11-12",
                    paymentForm = "0",
                    amount = "1.5",
                    interestAmount = "0",
                    discountAmount = "0",
                    fineAmount = "0",
                    beneficiary = new
                    {
                        name = "Teste Beneficiario",
                        cpfCnpj = "38947633000184",
                        bankCode = "001",
                        agency = "1111",
                        agencyDigit = "2",
                        accountNumber = "3333",
                        accountNumberDigit = "3",
                        accountDac = "4",
                        neighborhood = "Rua Teste",
                        addressNumber = "123",
                        addressComplement = "",
                        city = "Maringa",
                        state = "PR",
                        zipcode = "87000000",
                        accountType = "1",
                        transferOptions = "01"

                    },
                    tags = new string[] { "string" },

                };
                //Exemplo de json em: https://atendimento.tecnospeed.com.br/hc/pt-br/articles/360038750433-Pagamentos-atrav%C3%A9s-de-transfer%C3%AAncias-banc%C3%A1rias

                JavaScriptSerializer js = new JavaScriptSerializer();
                string strJson = js.Serialize(CamposTransferenciaBancaria);
                txtEntradaJSON.Text = strJson;

                var client = new RestClient(URLPagamento);
                var request = new RestRequest(Method.POST);
                request.AddHeader("cache-control", "no-cache");
                request.AddHeader("content-type", "application/json");
                request.AddHeader("tokenSH", txtTokenSH.Text);
                request.AddHeader("cnpjSH", txtCNPJSH.Text);
                request.AddHeader("payercpfcnpj", txtPayerCNPJ.Text);
                request.AddParameter("application/json", strJson, ParameterType.RequestBody);

                dynamic json = JObject.Parse(client.Execute(request).Content);
                txtRespostaAPI.Text = JsonConvert.SerializeObject(json, Formatting.Indented);
            }
            else if (Diversos.Checked == true)
            {
                var URLPagamento = "https://staging.pagamentobancario.com.br/api/v1/payment/transfer";

                var CamposDiversos = new
                {
                    accountHash = "b8aKHR6tXS",
                    paymentDate = "2019-11-12",
                    paymentForm = "0",
                    amount = "1.5",
                    interestAmount = "0",
                    discountAmount = "0",
                    fineAmount = "0",
                    beneficiary = new
                    {
                        name = "Teste Beneficiario",
                        cpfCnpj = "38947633000184",
                        bankCode = "001",
                        agency = "1111",
                        agencyDigit = "2",
                        accountNumber = "3333",
                        accountNumberDigit = "3",
                        accountDac = "4",
                        neighborhood = "Rua Teste",
                        addressNumber = "123",
                        addressComplement = "",
                        city = "Maringa",
                        state = "PR",
                        zipcode = "87000000",

                    },
                    tags = new string[] { "string" },

                };
                JavaScriptSerializer js = new JavaScriptSerializer();
                string strJson = js.Serialize(CamposDiversos);

                var client = new RestClient(URLPagamento);
                var request = new RestRequest(Method.POST);
                request.AddHeader("cache-control", "no-cache");
                request.AddHeader("content-type", "application/json");
                request.AddHeader("tokenSH", txtTokenSH.Text);
                request.AddHeader("cnpjSH", txtCNPJSH.Text);
                request.AddHeader("payercpfcnpj", txtPayerCNPJ.Text);
                request.AddParameter("application/json", strJson, ParameterType.RequestBody);

                dynamic json = JObject.Parse(client.Execute(request).Content);
                txtRespostaAPI.Text = JsonConvert.SerializeObject(json, Formatting.Indented);
            }
            else if (BoletosBloquetos.Checked == true)
            {
                var URLPagamento = "https://staging.pagamentobancario.com.br/api/v1/payment/billet";

                var CamposBoletosBloquetos = new
                {
                    accountHash = "b8aKHR6tXS",
                    description = "Pagamento de Boletos e Bloquetos",
                    paymentForm = "30",
                    nominalAmount = "1.50",
                    ourNumber = "1002",
                    paymentDate = "2019-09-20",
                    amount = "1.50",
                    barcode = "34193808200000001011090000366261234123451000",
                    beneficiary = new
                    {
                        name = "BENEFICIARIO TESTE",
                        cpfCnpj = "13201437000135",
                    },
                    dueDate = "2019-09-20",
                    tags = new string[] { "string" },

                    //Exemplo de json em:https://atendimento.tecnospeed.com.br/hc/pt-br/articles/360038731693-Pagamento-de-boletos-bloquetos
                };
                JavaScriptSerializer js = new JavaScriptSerializer();
                string strJson = js.Serialize(CamposBoletosBloquetos);

                var client = new RestClient(URLPagamento);
                var request = new RestRequest(Method.POST);
                request.AddHeader("cache-control", "no-cache");
                request.AddHeader("content-type", "application/json");
                request.AddHeader("tokenSH", txtTokenSH.Text);
                request.AddHeader("cnpjSH", txtCNPJSH.Text);
                request.AddHeader("payercpfcnpj", txtPayerCNPJ.Text);
                request.AddParameter("application/json", strJson, ParameterType.RequestBody);

                dynamic json = JObject.Parse(client.Execute(request).Content);
                txtRespostaAPI.Text = JsonConvert.SerializeObject(json, Formatting.Indented);
            }

            if (Salarios.Checked == true)
            {
                var URLPagamento = "https://staging.pagamentobancario.com.br/api/v1/payment/paycheck";

                var CamposSalario = new
                {
                    accountHash = "b8aKHR6tXS",
                    paymentDate = "2019-11-12",
                    paymentForm = "0",
                    amount = "1.5",
                    interestAmount = "0",
                    discountAmount = "0",
                    fineAmount = "0",
                    beneficiary = new
                    {
                        name = "Teste Beneficiario",
                        cpfCnpj = "38947633000184",
                        bankCode = "001",
                        agency = "1111",
                        agencyDigit = "2",
                        accountNumber = "3333",
                        accountNumberDigit = "3",
                        accountDac = "4",
                        neighborhood = "Rua Teste",
                        addressNumber = "123",
                        addressComplement = "",
                        city = "Maringa",
                        state = "PR",
                        zipcode = "87000000",
                        accountType = "1",
                        transferOptions = "01"

                    },
                    tags = new string[] { "string" },

                };
                //Exemplo de json em: https://atendimento.tecnospeed.com.br/hc/pt-br/articles/360038750433-Pagamentos-atrav%C3%A9s-de-transfer%C3%AAncias-banc%C3%A1rias

                JavaScriptSerializer js = new JavaScriptSerializer();
                string strJson = js.Serialize(CamposSalario);
                txtEntradaJSON.Text = strJson;

                var client = new RestClient(URLPagamento);
                var request = new RestRequest(Method.POST);
                request.AddHeader("cache-control", "no-cache");
                request.AddHeader("content-type", "application/json");
                request.AddHeader("tokenSH", txtTokenSH.Text);
                request.AddHeader("cnpjSH", txtCNPJSH.Text);
                request.AddHeader("payercpfcnpj", txtPayerCNPJ.Text);
                request.AddParameter("application/json", strJson, ParameterType.RequestBody);

                dynamic json = JObject.Parse(client.Execute(request).Content);
                txtRespostaAPI.Text = JsonConvert.SerializeObject(json, Formatting.Indented);
            }

        }

        private void groupBox7_Enter(object sender, EventArgs e)
        {

        }

        private void label19_Click_1(object sender, EventArgs e)
        {

        }

        private void label20_Click(object sender, EventArgs e)
        {

        }

        private void label20_Click_1(object sender, EventArgs e)
        {

        }

        private void ConsultarPagador_Click(object sender, EventArgs e)
        {
            string cnpjSH = txtCNPJSH.Text;
            string tokenSH = txtTokenSH.Text;
            string payercpfcnpj = txtPayerCNPJ.Text;
            string URLConsultaPagador = "https://staging.pagamentobancario.com.br/api/v1/payer";

            var client = new RestClient(URLConsultaPagador);
            var request = new RestRequest(Method.GET);
            request.AddHeader("cache-control", "no-cache");
            request.AddHeader("content-type", "application/json");
            request.AddHeader("tokenSH", tokenSH);
            request.AddHeader("cnpjSH", cnpjSH);
            request.AddHeader("payercpfcnpj", payercpfcnpj);

            dynamic json = JObject.Parse(client.Execute(request).Content);
            txtRespostaAPI.Text = JsonConvert.SerializeObject(json, Formatting.Indented);


        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            if (DARF.Checked == true)
            {
                var URLPagamento = "https://staging.pagamentobancario.com.br/api/v1/payment/taxes/darf";

                var CamposDARF = new object[] { new {
                                                      accountHash = "b8aKHR6tXS",
                                                      referencePeriod = "2019-12",
                                                      reportingPeriod = "2019-12-20",
                                                      paymentDate ="2019-12-20",
                                                      dueDate = "2019-12-20",
                                                      description = "Pagamento da DARF Teste",
                                                      contributorDocument = "93848368005",
                                                      contributorName = "Teste homologacao",
                                                      referenceNumber = "123",
                                                      interestAmount = "1.0",
                                                      fineAmount = "0",
                                                      nominalAmount = "0",
                                                      tags = new string[] { "string" },
                                                }
                    //Exemplo de json em:https://atendimento.tecnospeed.com.br/hc/pt-br/articles/360038231754-Pagamento-de-DARF
                                               };
                JavaScriptSerializer js = new JavaScriptSerializer();
                string strJson = js.Serialize(CamposDARF);

                var client = new RestClient(URLPagamento);
                var request = new RestRequest(Method.POST);
                request.AddHeader("cache-control", "no-cache");
                request.AddHeader("content-type", "application/json");
                request.AddHeader("tokenSH", txtTokenSH.Text);
                request.AddHeader("cnpjSH", txtCNPJSH.Text);
                request.AddHeader("payercpfcnpj", txtPayerCNPJ.Text);
                request.AddParameter("application/json", strJson, ParameterType.RequestBody);

                dynamic json = JObject.Parse(client.Execute(request).Content);
                txtRespostaAPI.Text = JsonConvert.SerializeObject(json, Formatting.Indented);
            }

            if (GPS.Checked == true)
            {
                var URLPagamento = "https://staging.pagamentobancario.com.br/api/v1/payment/taxes/gps";

                var CamposGPS = new object[] { new {
                                                      accountHash = "b8aKHR6tXS",
                                                      contributorDocument = "93848368005",
                                                      paymentDate ="2019-12-20",
                                                      amount = "1.50",
                                                      nominalAmount = "1.50",
                                                      description = "Teste GPS",
                                                      referencePeriod = "122019",
                                                      taxAmount = "0",
                                                      otherAmount = "0",
                                                      monetaryAdjustment = "0",
                                                      tags = new string[] { "string" },
                                                    }
                    //Exemplo de json em: https://atendimento.tecnospeed.com.br/hc/pt-br/articles/360038749353-Pagamento-de-GPS
                                               };
                JavaScriptSerializer js = new JavaScriptSerializer();
                string strJson = js.Serialize(CamposGPS);

                var client = new RestClient(URLPagamento);
                var request = new RestRequest(Method.POST);
                request.AddHeader("cache-control", "no-cache");
                request.AddHeader("content-type", "application/json");
                request.AddHeader("tokenSH", txtTokenSH.Text);
                request.AddHeader("cnpjSH", txtCNPJSH.Text);
                request.AddHeader("payercpfcnpj", txtPayerCNPJ.Text);
                request.AddParameter("application/json", strJson, ParameterType.RequestBody);

                dynamic json = JObject.Parse(client.Execute(request).Content);
                txtRespostaAPI.Text = JsonConvert.SerializeObject(json, Formatting.Indented);
            }

            if (DPVAT.Checked == true)
            {
                var URLPagamento = "https://staging.pagamentobancario.com.br/api/v1/payment/taxes/dpvat";

                var CamposDPVAT = new object[] { new {
                                                      accountHash = "b8aKHR6tXS",
                                                      paymentDate ="2019-12-20",
                                                      contributorDocument = "93848368005",
                                                      description = "Teste de DPVAT",
                                                      nominalAmount = "1.50",
                                                      contributorName = "João Teste",
                                                      calculationYear = "2019",
                                                      amount = "1.50",
                                                      dueDate = "2019-12-20",
                                                      municipalCode = "4115200",
                                                      discountAmount = "0",
                                                      state = "PR",
                                                      vehiclePlates = "AAA0000",
                                                      paymentOption = "1",
                                                      vehicleRenavam = "aaaaaaaaaa",
                                                      CRVLWithdrawalOption = "1",
                                                      tags = new string[] { "string" },
                                                    }
                    //Exemplo de json em: https://atendimento.tecnospeed.com.br/hc/pt-br/articles/360038230514-Pagamento-de-DPVAT
                                               };
                JavaScriptSerializer js = new JavaScriptSerializer();
                string strJson = js.Serialize(CamposDPVAT);

                var client = new RestClient(URLPagamento);
                var request = new RestRequest(Method.POST);
                request.AddHeader("cache-control", "no-cache");
                request.AddHeader("content-type", "application/json");
                request.AddHeader("tokenSH", txtTokenSH.Text);
                request.AddHeader("cnpjSH", txtCNPJSH.Text);
                request.AddHeader("payercpfcnpj", txtPayerCNPJ.Text);
                request.AddParameter("application/json", strJson, ParameterType.RequestBody);

                dynamic json = JObject.Parse(client.Execute(request).Content);
                txtRespostaAPI.Text = JsonConvert.SerializeObject(json, Formatting.Indented);
            }

            if (IPVA.Checked == true)
            {
                var URLPagamento = "https://staging.pagamentobancario.com.br/api/v1/payment/taxes/ipva";

                var CamposIPVA = new object[] { new {
                                                      accountHash = "b8aKHR6tXS",
                                                      paymentDate ="2019-12-20",
                                                      contributorDocument = "93848368005",
                                                      description = "Teste de IPVA",
                                                      nominalAmount = "1.50",
                                                      contributorName = "João Teste",
                                                      calculationYear = "2019",
                                                      amount = "1.50",
                                                      dueDate = "2019-12-20",
                                                      municipalCode = "4115200",
                                                      discountAmount = "0",
                                                      state = "PR",
                                                      vehiclePlates = "AAA0000",
                                                      paymentOption = "1",
                                                      vehicleRenavam = "aaaaaaaaaa",
                                                      CRVLWithdrawalOption = "1",
                                                      tags = new string[] { "string" },
                                                    }
                    //Exemplo de json em: https://atendimento.tecnospeed.com.br/hc/pt-br/articles/360038746533-Pagamento-de-IPVA
                                               };
                JavaScriptSerializer js = new JavaScriptSerializer();
                string strJson = js.Serialize(CamposIPVA);

                var client = new RestClient(URLPagamento);
                var request = new RestRequest(Method.POST);
                request.AddHeader("cache-control", "no-cache");
                request.AddHeader("content-type", "application/json");
                request.AddHeader("tokenSH", txtTokenSH.Text);
                request.AddHeader("cnpjSH", txtCNPJSH.Text);
                request.AddHeader("payercpfcnpj", txtPayerCNPJ.Text);
                request.AddParameter("application/json", strJson, ParameterType.RequestBody);

                dynamic json = JObject.Parse(client.Execute(request).Content);
                txtRespostaAPI.Text = JsonConvert.SerializeObject(json, Formatting.Indented);
            }

            if (GARE.Checked == true)
            {
                var URLPagamento = "https://staging.pagamentobancario.com.br/api/v1/payment/taxes/gare";

                var CamposGARE = new object[] { new {
                                                      accountHash = "b8aKHR6tXS",
                                                      paymentDate ="2019-12-20",
                                                      amount = "1.50",
                                                      description = "Pagamento da GARE Teste",
                                                      contributorDocument = "93848368005",
                                                      dueDate = "2019-12-20",
                                                      stateRegistration = "PR",
                                                      activeDebit = "123",
                                                      referencePeriod = "2019-12",
                                                      installment = "01",
                                                      interestAmount = "0",
                                                      fineAmount = "0",
                                                      nominalAmount = "1.50",
                                                      tags = new string[] { "string" },
                                                    }
                    //Exemplo de json em: https://atendimento.tecnospeed.com.br/hc/pt-br/articles/360038744813-Pagamento-de-GARE
                                               };
                JavaScriptSerializer js = new JavaScriptSerializer();
                string strJson = js.Serialize(CamposGARE);

                var client = new RestClient(URLPagamento);
                var request = new RestRequest(Method.POST);
                request.AddHeader("cache-control", "no-cache");
                request.AddHeader("content-type", "application/json");
                request.AddHeader("tokenSH", txtTokenSH.Text);
                request.AddHeader("cnpjSH", txtCNPJSH.Text);
                request.AddHeader("payercpfcnpj", txtPayerCNPJ.Text);
                request.AddParameter("application/json", strJson, ParameterType.RequestBody);

                dynamic json = JObject.Parse(client.Execute(request).Content);
                txtRespostaAPI.Text = JsonConvert.SerializeObject(json, Formatting.Indented);
            }



        }

        private void ConsultarProtocoloRemessa_Click(object sender, EventArgs e)
        {
            string cnpjSH = txtCNPJSH.Text;
            string tokenSH = txtTokenSH.Text;
            string payercpfcnpj = txtPayerCNPJ.Text;
            string url = "https://staging.pagamentobancario.com.br/api/v1/remittance/";

            var client = new RestClient(url + txtProtocoloRemessa.Text);
            var request = new RestRequest(Method.GET);
            request.AddHeader("cache-control", "no-cache");
            request.AddHeader("content-type", "application/json");
            request.AddHeader("tokenSH", tokenSH);
            request.AddHeader("cnpjSH", cnpjSH);
            request.AddHeader("payercpfcnpj", payercpfcnpj);

            dynamic json = JObject.Parse(client.Execute(request).Content);
            txtRespostaAPI.Text = JsonConvert.SerializeObject(json, Formatting.Indented);
        }

        private void UploadRetorno_Enter(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string cnpjSH = txtCNPJSH.Text;
            string tokenSH = txtTokenSH.Text;
            string payercpfcnpj = txtPayerCNPJ.Text;
            string url = "https://staging.pagamentobancario.com.br/api/v1/reconciliation";

            var client = new RestClient(url);
            var request = new RestRequest(Method.POST);
            request.AddHeader("cache-control", "no-cache");
            request.AddHeader("content-type", "application/json");
            request.AddHeader("tokenSH", tokenSH);
            request.AddHeader("cnpjSH", cnpjSH);
            request.AddHeader("payercpfcnpj", payercpfcnpj);
            //request.AddParameter("application/x-www-form-urlencoded", "arquivo=" + RetornoBase64, ParameterType.RequestBody);

            DialogResult result = openFileDialog1.ShowDialog(); // Show the dialog.
            if (result == DialogResult.OK) // Test result.
            {
                string file = openFileDialog1.FileName;

                dynamic json = JObject.Parse(client.Execute(request).Content);
                txtRespostaAPI.Text = JsonConvert.SerializeObject(json, Formatting.Indented);
            }
        }
        private void txtProtocoloRemessa_TextChanged(object sender, EventArgs e)
        {
            string cnpjSH = txtCNPJSH.Text;
            string tokenSH = txtTokenSH.Text;
            string payercpfcnpj = txtPayerCNPJ.Text;
            string url = "http://ecs-pagamento-api-777030523.us-east-1.elb.amazonaws.com/api/v1/reconciliation/";

            var client = new RestClient(url + txtProtocoloRemessa.Text);
            var request = new RestRequest(Method.GET);
            request.AddHeader("cache-control", "no-cache");
            request.AddHeader("content-type", "application/json");
            request.AddHeader("tokenSH", tokenSH);
            request.AddHeader("cnpjSH", cnpjSH);
            request.AddHeader("payercpfcnpj", payercpfcnpj);

            dynamic json = JObject.Parse(client.Execute(request).Content);
            txtRespostaAPI.Text = JsonConvert.SerializeObject(json, Formatting.Indented);
        }

        private void ConsultarProtocolo_Click(object sender, EventArgs e)
        {

            string cnpjSH = txtCNPJSH.Text;
            string tokenSH = txtTokenSH.Text;
            string payercpfcnpj = txtPayerCNPJ.Text;

            var client = new RestClient("https://staging.pagamentobancario.com.br/api/v1/remittance/" + txtProtocoloRetorno.Text);
            var request = new RestRequest(Method.GET);
            request.AddHeader("cache-control", "no-cache");
            request.AddHeader("content-type", "application/json");
            request.AddHeader("token-sh", tokenSH);
            request.AddHeader("cnpj-sh", cnpjSH);
            request.AddHeader("payercpfcnpj", payercpfcnpj);

            dynamic json = JObject.Parse(client.Execute(request).Content);
            txtRespostaAPI.Text = JsonConvert.SerializeObject(json, Formatting.Indented);
        }

        private void AlterarPagador_Click(object sender, EventArgs e)
        {
            var URLAlteracaoPagador = "https://staging.pagamentobancario.com.br/api/v1/payer";

            var ListaPagador = new
            {
                name = "CNPJ PARA TESTES",
                cpfCnpj = "01001001000113",
                neighborhood = "DUQUE DE CAXIAS",
                addressNumber = "882",
                zipcode = "87020025",
                state = "PR",
                city = "MARINGA",
            };

            JavaScriptSerializer jsonEnvio = new JavaScriptSerializer();
            string strJson = jsonEnvio.Serialize(ListaPagador);
            txtEntradaJSON.Text = strJson;

            var client = new RestClient(URLAlteracaoPagador);
            var request = new RestRequest(Method.PUT);
            request.AddHeader("cache-control", "no-cache");
            request.AddHeader("content-type", "application/json");
            request.AddHeader("tokenSH", txtTokenSH.Text);
            request.AddHeader("cnpjSH", txtCNPJSH.Text);
            request.AddHeader("payercpfcnpj", txtPayerCNPJ.Text);
            request.AddParameter("application/json", strJson, ParameterType.RequestBody);

            dynamic json = JObject.Parse(client.Execute(request).Content);
            txtRespostaAPI.Text = JsonConvert.SerializeObject(json, Formatting.Indented);


        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void ConsultarPagamento_Click(object sender, EventArgs e)
        {
            string cnpjSH = txtCNPJSH.Text;
            string tokenSH = txtTokenSH.Text;
            string payercpfcnpj = txtPayerCNPJ.Text;
            string URLConsultaPagamento = "https://staging.pagamentobancario.com.br/api/v1/payment?uniqueId=";

            var client = new RestClient(URLConsultaPagamento + txtUniqueID.Text);
            var request = new RestRequest(Method.GET);
            request.AddHeader("cache-control", "no-cache");
            request.AddHeader("content-type", "application/json");
            request.AddHeader("tokenSH", tokenSH);
            request.AddHeader("cnpjSH", cnpjSH);
            request.AddHeader("payercpfcnpj", payercpfcnpj);

            dynamic json = JObject.Parse(client.Execute(request).Content);
            txtRespostaAPI.Text = JsonConvert.SerializeObject(json, Formatting.Indented);

        }
    }

    public class listaConsultaPagador
    {
        public string cnpjSH { get; set; }
        public string tokenSH { get; set; }
        public string cnpayercpfcnpjpjSH { get; set; }

    }


    public class RemessaResposta
    {
        public string protocolo { get; set; }
        public IList<arrayRemessa> remessas { get; set; }
    }


    public class arrayRemessa
    {
        public string arquivo { get; set; }
        public IList<string> pagador { get; set; }
    }


    public class Pagador
    {
        public string name { get; set; }
        public string cpfCnpj { get; set; }
        public string neighborhood { get; set; }
        public string addressNumber { get; set; }
        public string zipcode { get; set; }
        public string state { get; set; }
        public string city { get; set; }
        public string bankCode { get; set; }
        public string agency { get; set; }
        public string agencyDigit { get; set; }
        public string accountNumber { get; set; }
        public string accountNumberDigit { get; set; }
        public string accountDac { get; set; }
        public string convenioNumber { get; set; }
        public string remessaSequential { get; set; }
        public string accountHash { get; set; }
    }

    public class Pagamento
    {
        public string name { get; set; }
        public string accountHash { get; set; }
        public string paymentForm { get; set; }
        public string paymentDate { get; set; }
        public string amount { get; set; }
        public string cpfCnpj { get; set; }
        public string neighborhood { get; set; }
        public string addressNumber { get; set; }
        public string zipcode { get; set; }
        public string state { get; set; }
        public string city { get; set; }
        public string bankCode { get; set; }
        public string agency { get; set; }
        public string agencyDigit { get; set; }
        public string accountNumber { get; set; }
        public string accountNumberDigit { get; set; }
        public string accountDac { get; set; }
        public string convenioNumber { get; set; }
        public string remessaSequential { get; set; }
    }

    public class ConsultaPagador
    {
        public string cnpjSH { get; set; }
        public string tokenSH { get; set; }
        public string payercpfcnpj { get; set; }
    }

    public class Remessa
    {
        public string idIntegracao { get; set; }
    }
}