package models;

import java.util.List;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class CadastrarPagador {
	@SerializedName("name")
	@Expose
	private String name;
	@SerializedName("cpfCnpj")
	@Expose
	private String decription;
	@SerializedName("neighborhood")
	@Expose
	private String neighborhood;
	@SerializedName("addressNumber")
	@Expose
	private String addressNumber;
	@SerializedName("zipcode")
	@Expose
	private String zipcode;
	@SerializedName("state")
	@Expose
	private String state;
	@SerializedName("city")
	@Expose
	private String city;
	@SerializedName("bankCode")
	@Expose
	private String bankCode;
	@SerializedName("agency")
	@Expose
	private String agency;
	@SerializedName("agencyDigit")
	@Expose
	private String agencyDigit;
	@SerializedName("accountNumber")
	@Expose
	private String accountNumber;
	@SerializedName("accountNumberDigit")
	@Expose
	private String accountNumberDigit;
	@SerializedName("accountDac")
	@Expose
	private String accountDac;
	@SerializedName("convenioNumber")
	@Expose
	private String convenioNumber;
	@SerializedName("remessaSequential")
	@Expose
	private String remessaSequential;
	
	/**
	 * No args constructor for use in serialization
	 * 
	 */
	public CadastrarPagador() {
	}

	/**
	 * 
	 * @param agency
	 * @param agencyDigit
	 * @param accountDac
	 * @param addressNumber
	 * @param state
	 * @param neighborhood
	 * @param cpfCnpj
	 * @param agencyDigit
	 * @param convenioNumber
	 * @param name
	 * @param accountDac
	 * @param agency
	 * @param addressNumber
	 * @param remessaSequential
	 */
	 
	 public CadastrarPagador(String name, String cpfCnpj, String neighborhood,
			String addressNumber, String zipcode, String state, String city,
			String bankCode, String agency, String agencyDigit,
			String accountNumber, String accountNumberDigit, String accountDac,
			String convenioNumber, String remessaSequential) {
		this.name = name;
		this.cpfCnpj = cpfCnpj;
		this.neighborhood = neighborhood;
		this.addressNumber = addressNumber;
		this.zipcode = zipcode;
		this.state = state;
		this.city = city;
		this.bankCode = bankCode;
		this.agency = agency;
		this.agencyDigit = agencyDigit;
		this.accountNumber = accountNumber;
		this.accountNumberDigit = accountNumberDigit;
		this.accountDac = accountDac;
		this.convenioNumber = convenioNumber;
		this.remessaSequential = remessaSequential;
	}
	
	public String getname() {
		return name;
	}

	public void setname(String name) {
		this.name = name;
	}

	public String getcpfCnpj() {
		return cpfCnpj;
	}

	public void setcpfCnpj(String cpfCnpj) {
		this.cpfCnpj = cpfCnpj;
	}

	public String getneighborhood() {
		return neighborhood;
	}

	public void setneighborhood(String neighborhood) {
		this.neighborhood = neighborhood;
	}

	public String getaddressNumber() {
		return addressNumber;
	}

	public void setaddressNumber(String addressNumber) {
		this.addressNumber = addressNumber;
	}

	public String getzipcode() {
		return zipcode;
	}

	public void setzipcode(String zipcode) {
		this.zipcode = zipcode;
	}

	public String getstate() {
		return state;
	}

	public void setstate(String state) {
		this.state = state;
	}

	public String getcity() {
		return city;
	}

	public void setcity(String city) {
		this.city = city;
	}

	public String getbankCode() {
		return bankCode;
	}

	public void setbankCode(String bankCode) {
		this.bankCode = bankCode;
	}

	public String getagency() {
		return agency;
	}

	public void setagency(String agency) {
		this.agency = agency;
	}

	public String getagencyDigit() {
		return agencyDigit;
	}

	public void setagencyDigit(String agencyDigit) {
		this.agencyDigit = agencyDigit;
	}

	public String getaccountNumber() {
		return accountNumber;
	}

	public void setaccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	public String getaccountNumberDigit() {
		return accountNumberDigit;
	}

	public void setaccountNumberDigit(String accountNumberDigit) {
		this.accountNumberDigit = accountNumberDigit;
	}

	public String getaccountDac() {
		return accountDac;
	}

	public void setaccountDac(String accountDac) {
		this.accountDac = accountDac;
	}

	public String getconvenioNumber() {
		return convenioNumber;
	}

	public void setcpfconvenioNumber(String convenioNumber) {
		this.convenioNumber = convenioNumber;
	}

	public String getremessaSequential() {
		return remessaSequential;
	}
	
}
