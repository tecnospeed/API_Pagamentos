package models;


import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class IncluirPagamento {

	@SerializedName("accountHash")
	@Expose
	private String accountHash;
	@SerializedName("description")
	@Expose
	private String decription;
	@SerializedName("paymentForm")
	@Expose
	private String paymentForm;
	@SerializedName("paymentDate")
	@Expose
	private String paymentDate;
	@SerializedName("dueDate")
	@Expose
	private String dueDate;
	@SerializedName("amount")
	@Expose
	private String amount;
	@SerializedName("nominalAmount")
	@Expose
	private String nominalAmount;
	@SerializedName("rebateAmount")
	@Expose
	private String rebateAmount;
	@SerializedName("interestAmount")
	@Expose
	private String interestAmount;
	@SerializedName("discountAmount")
	@Expose
	private String discountAmount;
	@SerializedName("fineAmount")
	@Expose
	private String fineAmount;
	@SerializedName("compensation")
	@Expose
	private String compensation;
	@SerializedName("name")
	@Expose
	private String name;
	@SerializedName("cpfCnpj")
	@Expose
	private String cpfCnpj;
	@SerializedName("bankCode")
	@Expose
	private String bankCode;
	@SerializedName("agency")
	@Expose
	private String agency;
	@SerializedName("agencyDigit")
	@Expose
	private String agencyDigit;
	@SerializedName("accountNumber")
	@Expose
	private String accountNumber;
	@SerializedName("accountNumberDigit")
	@Expose
	private String accountNumberDigit;
	@SerializedName("accountDac")
	@Expose
	private String accountDac;
	@SerializedName("neighborhood")
	@Expose
	private String neighborhood;
	@SerializedName("addressNumber")
	@Expose
	private String addressNumber;
	@SerializedName("addressComplement")
	@Expose
	private String addressComplement;
	@SerializedName("city")
	@Expose
	private String city;
	@SerializedName("state")
	@Expose
	private String state;
	@SerializedName("zipcode")
	@Expose
	private String zipcode;

	/**
	 * No args constructor for use in serialization
	 * 
	 */
	public IncluirPagamento() {
	}

	/**
	 * 
	 * @param agency
	 * @param discountAmount
	 * @param accountDac
	 * @param addressNumber
	 * @param amount
	 * @param neighborhood
	 * @param description
	 * @param agencyDigit
	 * @param cpfCnpj
	 * @param name
	 * @param interestAmount
	 * @param paymentDate
	 * @param bankCode
	 * @param addressComplement
	 * @param state
	 * @param compensation
	 * @param city
	 * @param accountHash
	 * @param rebateAmount
	 * @param paymentForm
	 * @param dueDate
	 * @param nominalAmount
	 * @param zipcode
	 * @param fineAmount
	 * @param accountNumberDigit
	 * @param accountNumber
	 */
	public IncluirPagamento(String accountHash, String description, String paymentForm,
			String paymentDate, String dueDate, String amount, String nominalAmount,
			String rebateAmount, String interestAmount, String discountAmount,
			String fineAmount, String compensation, String name,
			String cpfCnpj, String bankCode, String agency, String agencyDigit,
			String accountNumber, String accountNumberDigit, String accountDac, String neighborhood,
			String addressNumber, String addressComplement, String city, String state,
			String zipcode) {
		this.accountHash = accountHash;
		this.description = description;
		this.paymentForm = paymentForm;
		this.paymentDate = paymentDate;
		this.dueDate = dueDate;
		this.amount = amount;
		this.nominalAmount = nominalAmount;
		this.rebateAmount = rebateAmount;
		this.interestAmount = interestAmount;
		this.discountAmount = discountAmount;
		this.fineAmount = fineAmount;
		this.compensation = compensation;
		this.name = name;
		this.cpfCnpj = cpfCnpj;
		this.bankCode = bankCode;
		this.agency = agency;
		this.agencyDigit = agencyDigit;
		this.accountNumber = accountNumber;
		this.accountNumberDigit = accountNumberDigit;
		this.accountDac = accountDac;
		this.neighborhood = neighborhood;
		this.addressNumber = addressNumber;
		this.addressComplement = addressComplement;
		this.city = city;
		this.state = state;
		this.zipcode = zipcode;
	}

	public String getaccountHash() {
		return accountHash;
	}

	public void setaccountHash(String accountHash) {
		this.accountHash = accountHash;
	}

	public String getdescription() {
		return description;
	}

	public void setdescription(String description) {
		this.description = description;
	}

	public String getpaymentForm() {
		return paymentForm;
	}

	public void setpaymentForm(String paymentForm) {
		this.paymentForm = paymentForm;
	}

	public String getpaymentDate() {
		return paymentDate;
	}

	public void setpaymentDate(String paymentDate) {
		this.paymentDate = paymentDate;
	}

	public String getdueDate() {
		return dueDate;
	}

	public void setdueDate(String dueDate) {
		this.dueDate = dueDate;
	}

	public String getamount() {
		return amount;
	}

	public void setamount(String amount) {
		this.amount = amount;
	}

	public String getnominalAmount() {
		return nominalAmount;
	}

	public void setnominalAmount(String nominalAmount) {
		this.nominalAmount = nominalAmount;
	}

	public String getrebateAmount() {
		return rebateAmount;
	}

	public void setrebateAmount(String rebateAmount) {
		this.rebateAmount = rebateAmount;
	}

	public String getinterestAmount() {
		return interestAmount;
	}

	public void setinterestAmount(String interestAmount) {
		this.interestAmount = interestAmount;
	}

	public String getdiscountAmount() {
		return discountAmount;
	}

	public void setdiscountAmount(String discountAmount) {
		this.discountAmount = discountAmount;
	}

	public String getfineAmount() {
		return fineAmount;
	}

	public void setfineAmount(String fineAmount) {
		this.fineAmount = fineAmount;
	}

	public String getcompensation() {
		return compensation;
	}

	public void setcompensation(String compensation) {
		this.compensation = compensation;
	}

	public String getname() {
		return name;
	}

	public void setname(String name) {
		this.name = name;
	}

	public String getcpfCnpj() {
		return cpfCnpj;
	}

	public void setcpfCnpj(String cpfCnpj) {
		this.cpfCnpj = cpfCnpj;
	}

	public String getbankCode() {
		return bankCode;
	}

	public void setbankCode(String bankCode) {
		this.bankCode = bankCode;
	}

	public String getagency() {
		return agency;
	}

	public void setagency(String agency) {
		this.agency = agency;
	}

	public String getagencyDigit() {
		return agencyDigit;
	}

	public void setagencyDigit(String agencyDigit) {
		this.agencyDigit = agencyDigit;
	}

	public String getaccountNumber() {
		return accountNumber;
	}

	public void setaccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	public String getaccountNumberDigit() {
		return accountNumberDigit;
	}

	public void setaccountNumberDigit(String accountNumberDigit) {
		this.accountNumberDigit = accountNumberDigit;
	}

	public String getaccountDac() {
		return accountDac;
	}

	public void setaccountDac(String accountDac) {
		this.accountDac = accountDac;
	}

	public String getneighborhood() {
		return neighborhood;
	}

	public void setneighborhood(String neighborhood) {
		this.neighborhood = neighborhood;
	}

	public String getaddressNumber() {
		return addressNumber;
	}

	public void setaddressNumber(String addressNumber) {
		this.addressNumber = addressNumber;
	}

	public String getaddressComplement() {
		return addressComplement;
	}

	public void setaddressComplement(String addressComplement) {
		this.addressComplement = addressComplement;
	}

	public String getcity() {
		return city;
	}

	public void setcity(String city) {
		this.city = city;
	}

	public String getstate() {
		return state;
	}

	public void setstate(String state) {
		this.state = state;
	}

	public String getzipcode() {
		return zipcode;
	}

	public void setzipcode(String zipcode) {
		this.zipcode = zipcode;
	}

}