package models;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Retorno {
	@SerializedName("arquivo")
	@Expose
	private String arquivo;

	/**
	* No args constructor for use in serialization
	* 
	*/
	public Retorno() {
	}

	public Retorno(String arquivo) {
	super();
	this.arquivo = arquivo;
	}

}
