package org.eclipse.wb.swt;

import java.nio.Buffer;
import java.util.List;

import javax.xml.ws.Response;

import com.google.gson.JsonObject;

import models.IncluirPagamento;
import models.Retorno;
import models.cadastroPagador;
import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.Path;
import retrofit2.http.Query;



public interface InterfaceAPI {
	
	@POST("payment/transfer")
	Call<JsonObject> Incluir(@Body List<IncluirPagamento> body);
	
	@GET("payment{uniqueId}")
	Call<JsonObject> Consultar(@Query("uniqueId") String uniqueId);
	
	@POST("payer")
	Call<JsonObject> CadastrarPagador(@Body cadastroPagador );
	
	@GET("payer")
	Call<ResponseBody> ConsultarPagador(@Path ConsultaPagador String cpfcnpj);
	
	@POST("remittance")
	Call<JsonObject> GerarRemessa(@Body List<String> pagamentos);
	
	@GET("remittance/{uniqueId}")
	Call<JsonObject> ConsultarProtocoloRemessa(@Path("uniqueId") String uniqueId);
	
	@POST("reconciliation")
	Call<JsonObject> ProcessarRetorno(@Body Retorno jsonretorno);
	
	@GET("reconciliation/{uniqueId}")
	Call<JsonObject> ConsultarProcessamentoRetorno(@Path("uniqueId") String uniqueId);
}
