import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.Buffer;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;

import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Group;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Text;
import org.eclipse.wb.swt.Configuracao;
import org.eclipse.wb.swt.InterfaceAPI;
import org.eclipse.wb.swt.SWTResourceManager;
import org.omg.CORBA.Environment;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;

import models.IncluirPagamento;
import models.Retorno;
import models.cadastroPagador;
import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class Pagamento {

	protected Shell shlPagamentoapi;
	private Text txtaccountHash;
	private Text txtdescription;
	private Text txtpaymentForm;
	private Text txtpaymentDate;
	private Text txtdueDate;
	private Text txtamount;
	private Text txtnominalAmount;
	private Text txtrebateAmount;
	private Text txtinterestAmount;
	private Text txtdiscountAmount;
	private Text txtfineAmount;
	private Text txtcompensation;
	private Text txtname;
	private Text txtcpfCnpj;
	private Text txtbankCode;
	private Text txtagency;
	private Text txtagencyDigit;
	private Text txtRemessa;
	private Text txtRetorno;
	private Text txtProtocolo;
	private Text txtRespostaApi;
	private Text txtStatus;
	private Text txtSituacao;
	private Text txtErro;
	private Text txtMensagem;

	/**
	 * Launch the application.
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		try {
			Pagamento window = new Pagamento();
			window.open();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Open the window.
	 */
	public void open() {
		Display display = Display.getDefault();
		createContents();
		shlPagamentoapi.open();
		shlPagamentoapi.layout();
		while (!shlPagamentoapi.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}
	}

	/**
	 * Create contents of the window.
	 */
	protected void createContents() {
		shlPagamentoapi = new Shell();
		shlPagamentoapi.setSize(740, 626);
		shlPagamentoapi.setText("PagamentoApi");

		Group grpIncluirPagamento = new Group(shlPagamentoapi, SWT.NONE);
		grpIncluirPagamento.setFont(SWTResourceManager.getFont("Segoe UI", 9, SWT.BOLD));
		grpIncluirPagamento.setText("Incluir Pagamento);
		grpIncluirPagamento.setBounds(11, 149, 222, 242);

		Label lblaccountHash = new Label(grpIncluirPagamento, SWT.NONE);
		lblaccountHash.setBounds(18, 46, 43, 15);
		lblaccountHash.setText("accountHash");

		Label lbldescription = new Label(grpIncluirPagamento, SWT.NONE);
		lbldescription.setBounds(67, 46, 43, 15);
		lbldescription.setText("description");

		Label lblpaymentForm = new Label(grpIncluirPagamento, SWT.NONE);
		lblpaymentForm.setBounds(118, 46, 21, 15);
		lblpaymentForm.setText("paymentForm");

		Label lblpaymentDate = new Label(grpIncluirPagamento, SWT.NONE);
		lblpaymentDate.setBounds(151, 46, 55, 15);
		lblpaymentDate.setText("paymentDate");

		txtaccountHash = new Text(grpIncluirPagamento, SWT.BORDER);
		txtaccountHash.setText("341");
		txtaccountHash.setBounds(18, 67, 36, 21);

		txtdescription = new Text(grpIncluirPagamento, SWT.BORDER);
		txtdescription.setText("12124");
		txtdescription.setBounds(66, 67, 44, 21);

		txtpaymentForm = new Text(grpIncluirPagamento, SWT.BORDER);
		txtpaymentForm.setText("1");
		txtpaymentForm.setBounds(118, 67, 21, 21);

		txtpaymentDate = new Text(grpIncluirPagamento, SWT.BORDER);
		txtpaymentDate.setText("12121");
		txtpaymentDate.setBounds(151, 67, 55, 21);

		txtdueDate = new Text(grpIncluirPagamento, SWT.BORDER);
		txtdueDate.setBounds(18, 145, 68, 21);

		txtamount = new Text(grpIncluirPagamento, SWT.BORDER);
		txtamount.setBounds(92, 145, 68, 21);

		txtnominalAmount = new Text(grpIncluirPagamento, SWT.BORDER);
		txtnominalAmount.setBounds(166, 145, 40, 21);

		Label lblUniqueId = new Label(grpIncluirPagamento, SWT.NONE);
		lblUniqueId.setBounds(18, 189, 68, 15);
		lblUniqueId.setText("UniqueId");

		txtUniqueId = new Text(grpIncluirPagamento, SWT.BORDER);
		txtUniqueId.setBounds(18, 210, 68, 21);

		Button btnIncluir = new Button(grpIncluirPagamento, SWT.NONE);
		btnIncluir.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {

				try {

					txtMensagem.setText("");
					txtRespostaApi.setText("");
					txtErro.setText("");

					IncluirPagamento pagamento = new IncluirPagamento(txtdescription.getText(), txtpaymentForm.getText(), txtpaymentDate.getText(),
							txtaccountHash.getText(), txtdueDate.getText(), txtamount.getText(), txtnominalAmount.getText()");
					ArrayList<IncluirPagamento> list = new ArrayList<>();

					list.add(pagamento);

					InterfaceAPI interfacePagamento = Configuracao.createService(InterfaceAPI.class);

					Call<JsonObject> call = interfacePagamento.Incluir(list);

					call.enqueue(new Callback<JsonObject>() {

						@Override
						public void onFailure(Call<JsonObject> arg0, Throwable response) {
							Display.getDefault().syncExec(new Runnable() {
								public void run() {
									txtRespostaApi.setText(txtRespostaApi.getText() + "\nFalha:");
									txtRespostaApi.setText(
											txtRespostaApi.getText() + "\nResposta:\n" + response.getMessage());
								}
							});
						}

						@Override
						public void onResponse(Call<JsonObject> arg0, Response<JsonObject> response) {

							Display.getDefault().syncExec(new Runnable() {
								public void run() {
									if (response.isSuccessful()) {
										txtStatus.setText(response.body().get("_status").toString());
										txtRespostaApi.setText(response.body().toString());

										JsonObject JsonDados = new JsonObject();
										JsonDados = (JsonObject) response.body().get("_dados");

										if (JsonDados.isJsonNull()) {
											txtRespostaApi.setText("Erro ao preencher dados");
										} else {
											JsonArray jArraySucesso = (JsonArray) JsonDados.get("_sucesso");
											JsonArray jArrayFalha = (JsonArray) JsonDados.get("_falha");

											for (int i = 0; i < jArrayFalha.size(); i++) {
												JsonObject Obj = new JsonObject();
												Obj = (JsonObject) jArrayFalha.get(i);

												JsonObject Erro = new JsonObject();
												Erro = (JsonObject) Obj.get("_erro");

												txtErro.setText(Erro.get("erros").getAsString());
												txtMensagem.setText("Falha ao gerar pagamento");
											}

											for (int i = 0; i < jArraySucesso.size(); i++) {
												JsonObject Obj = new JsonObject();
												Obj = (JsonObject) jArraySucesso.get(i);

												List<String> lista = new ArrayList<String>();
												lista.add(Obj.get("uniqueId").getAsString());

												System.out.println(lista);

											}

										}

									} else {
										try {
											String errorBody = response.errorBody().string();
											txtRespostaApi
													.setText(txtRespostaApi.getText() + "\nErroBody:\n" + errorBody);
										} catch (Exception e) {
											txtRespostaApi
													.setText(txtRespostaApi.getText() + "\nErro:\n" + e.toString());
										}
									}
								}
							});

						}

					});

				} catch (Exception e2) {
					// TODO: handle exception

					MessageDialog.openError(shlPagamentoapi, "Ero", e2.toString());
					return;
				}

			}
		});
		btnIncluir.setBounds(92, 208, 55, 25);
		btnIncluir.setText("Incluir");

		Button btnConsultar = new Button(grpIncluirPagamento, SWT.NONE);
		btnConsultar.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				try {

					txtMensagem.setText("");
					txtRespostaApi.setText("");
					txtErro.setText("");
					
					String uniqueId = txtuniqueId.getText();
					
					InterfaceAPI interfacePagamento = Configuracao.createService(InterfaceAPI.class);

					Call<JsonObject> call = interfacePagamento.Consultar(uniqueId);
					
					call.enqueue(new Callback<JsonObject>() {

						@Override
						public void onResponse(Call<JsonObject> arg0, Response<JsonObject> response) {
							// TODO Auto-generated method stub
							Display.getDefault().syncExec(new Runnable() {

								@Override
								public void run() {
									if (response.isSuccessful()) {
										txtStatus.setText(response.body().get("_status").toString());
										txtRespostaApi.setText(response.body().toString());	
									};
									
								}
								
							});
							
						}
						
						@Override
						public void onFailure(Call<JsonObject> arg0, Throwable response) {
							Display.getDefault().syncExec(new Runnable() {
								public void run() {
									txtRespostaApi.setText(txtRespostaApi.getText() + "\nFalha:");
									txtRespostaApi.setText(
									txtRespostaApi.getText() + "\nResposta:\n" + response.getMessage());
								}
							});
							
						}

					});
					
					

					

				} catch (Exception e2) {
					// TODO: handle exception

					MessageDialog.openError(shlPagamentoapi, "Ero", e2.toString());
					return;
				}
			}
		});
		btnConsultar.setText("Consultar");
		btnConsultar.setBounds(149, 208, 57, 25);

		Group grpRemessa = new Group(shlPagamentoapi, SWT.NONE);
		grpRemessa.setText("Remessa");
		grpRemessa.setBounds(248, 10, 472, 133);

		Button btnGerarRemessa = new Button(grpRemessa, SWT.NONE);
		btnGerarRemessa.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				try {

					txtMensagem.setText("");
					txtRespostaApi.setText("");
					txtErro.setText("");
					
					InterfaceAPI interfacePagamento = Configuracao.createService(InterfaceAPI.class);
					
					List<String> pagamentos = new ArrayList<String>();
										
					pagamentos.add(txtuniqueId.getText());
					
					System.out.println(pagamentos);
					
					Call<JsonObject> call = interfacePagamento.GerarRemessa(pagamentos);
					
					call.enqueue(new Callback<JsonObject>() {

						@Override
						public void onResponse(Call<JsonObject> arg0, Response<JsonObject> response) {
							// TODO Auto-generated method stub
							Display.getDefault().syncExec(new Runnable() {

								@Override
								public void run() {
									if (response.isSuccessful()) {
										txtStatus.setText(response.body().get("_status").toString());
										txtRespostaApi.setText(response.body().toString());	
										
										JsonObject JsonDados = new JsonObject();
										JsonDados = (JsonObject) response.body().get("_dados");
										
										JsonArray jArraySucesso = (JsonArray) JsonDados.get("_sucesso");
										JsonArray jArrayFalha = (JsonArray) JsonDados.get("_falha");
										
										System.out.println(jArrayFalha);

										for (int i = 0; i < jArraySucesso.size(); i++) {
											JsonObject Obj = new JsonObject();
											Obj = (JsonObject) jArraySucesso.get(i);

											txtRemessa.setText(Obj.get("remessa").toString());
										}
										
										
										for (int i = 0; i < jArrayFalha.size(); i++) {
											JsonObject Obj = new JsonObject();
											Obj = (JsonObject) jArrayFalha.get(i);
											
											txtErro.setText(Obj.get("_erro").toString());
										}
									};
									
								}
								
							});
							
						}
						
						@Override
						public void onFailure(Call<JsonObject> arg0, Throwable response) {
							Display.getDefault().syncExec(new Runnable() {
								public void run() {
									txtRespostaApi.setText(txtRespostaApi.getText() + "\nFalha:");
									txtRespostaApi.setText(
									txtRespostaApi.getText() + "\nResposta:\n" + response.getMessage());
								}
							});
							
						}

					});
					
					

					

				} catch (Exception e2) {
					// TODO: handle exception

					MessageDialog.openError(shlPagamentoapi, "Ero", e2.toString());
					return;
				}
			}
		});
		btnGerarRemessa.setBounds(10, 23, 89, 25);
		btnGerarRemessa.setText("Gerar Remessa");

		txtRemessa = new Text(grpRemessa, SWT.BORDER | SWT.MULTI);
		txtRemessa.setBounds(105, 23, 357, 100);

		Group grpRetorno = new Group(shlPagamentoapi, SWT.NONE);
		grpRetorno.setText("Retorno");
		grpRetorno.setBounds(248, 149, 472, 189);

		Button btnSubirRetorno = new Button(grpRetorno, SWT.NONE);
		btnSubirRetorno.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				try {

					txtMensagem.setText("");
					txtRespostaApi.setText("");
					txtErro.setText("");
					
					String base64 = Base64.getEncoder().encodeToString(txtRetorno.getText().getBytes());
					
					
					Retorno jsonretorno = new Retorno(base64);
					
					InterfaceAPI interfacePagamento = Configuracao.createService(InterfaceAPI.class);
					
					Call<JsonObject> call = interfacePagamento.ProcessarRetorno(jsonretorno);
					
					call.enqueue(new Callback<JsonObject>() {

						@Override
						public void onResponse(Call<JsonObject> arg0, Response<JsonObject> response) {
							// TODO Auto-generated method stub
							Display.getDefault().syncExec(new Runnable() {

								@Override
								public void run() {
									if (response.isSuccessful()) {
										txtStatus.setText(response.body().get("_status").toString());
										txtRespostaApi.setText(response.body().toString());	
										
										JsonObject JsonDados = new JsonObject();
										JsonDados = (JsonObject) response.body().get("_dados");
										
										txtProtocolo.setText(JsonDados.get("protocolo").getAsString());
										txtMensagem.setText(response.body().get("_mensagem").getAsString());
									};
									
								}
								
							});
							
						}
						
						@Override
						public void onFailure(Call<JsonObject> arg0, Throwable response) {
							Display.getDefault().syncExec(new Runnable() {
								public void run() {
									txtRespostaApi.setText(txtRespostaApi.getText() + "\nFalha:");
									txtRespostaApi.setText(
									txtRespostaApi.getText() + "\nResposta:\n" + response.getMessage());
								}
							});
							
						}

					});
					
					

					

				} catch (Exception e2) {
					// TODO: handle exception

					MessageDialog.openError(shlPagamentoapi, "Ero", e2.toString());
					return;
				}
				
			}
		});
		btnSubirRetorno.setBounds(10, 69, 89, 25);
		btnSubirRetorno.setText("Subir Retorno");

		txtRetorno = new Text(grpRetorno, SWT.BORDER | SWT.MULTI);
		txtRetorno.setBounds(105, 29, 357, 150);

		Label lblProtocolo_1 = new Label(grpRetorno, SWT.NONE);
		lblProtocolo_1.setBounds(10, 100, 55, 15);
		lblProtocolo_1.setText("Protocolo");

		txtProtocolo = new Text(grpRetorno, SWT.BORDER);
		txtProtocolo.setBounds(10, 122, 89, 21);

		Button btnConsultarRetorno = new Button(grpRetorno, SWT.NONE);
		btnConsultarRetorno.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				try {

					txtMensagem.setText("");
					txtRespostaApi.setText("");
					txtErro.setText("");
					
					String protocolo = txtProtocolo.getText();
					
					InterfaceAPI interfacePagamento = Configuracao.createService(InterfaceAPI.class);

					Call<JsonObject> call = interfacePagamento.ConsultarProcessamentoRetorno(protocolo);
					
					call.enqueue(new Callback<JsonObject>() {

						@Override
						public void onResponse(Call<JsonObject> arg0, Response<JsonObject> response) {
							// TODO Auto-generated method stub
							Display.getDefault().syncExec(new Runnable() {

								@Override
								public void run() {
									if (response.isSuccessful()) {
										txtStatus.setText(response.body().get("_status").getAsString());
										txtRespostaApi.setText(response.body().toString());	
									};
									
								}
								
							});
							
						}
						
						@Override
						public void onFailure(Call<JsonObject> arg0, Throwable response) {
							Display.getDefault().syncExec(new Runnable() {
								public void run() {
									txtRespostaApi.setText(txtRespostaApi.getText() + "\nFalha:");
									txtRespostaApi.setText(
									txtRespostaApi.getText() + "\nResposta:\n" + response.getMessage());
								}
							});
							
						}

					});
					
				} catch (Exception e2) {
					// TODO: handle exception

					MessageDialog.openError(shlPagamentoapi, "Ero", e2.toString());
					return;
				}
			}
		});
		btnConsultarRetorno.setBounds(10, 154, 89, 25);
		btnConsultarRetorno.setText("Consultar");

		Group grpRespostaApi = new Group(shlPagamentoapi, SWT.NONE);
		grpRespostaApi.setText("Resposta API");
		grpRespostaApi.setBounds(248, 344, 472, 239);

		txtRespostaApi = new Text(grpRespostaApi, SWT.BORDER | SWT.MULTI);
		txtRespostaApi.setText("Resposta API");
		txtRespostaApi.setBounds(264, 22, 198, 207);

	}
}
