//PAGADOR---------------------------------------------------------
async function postPayer(){
  const cnpj = document.getElementById('cnpjsh').value
  const token = document.getElementById('tokensh').value
  const textoTeste = JSON.parse(document.getElementById('txtJason').value)

  const header = new Headers();
  header.append("cnpjsh", cnpj)
  header.append("tokensh", token)
  header.append("Accept", "application/json")
  header.append("Content-Type", "application/json")

  console.log(textoTeste)
  const options = {
    method: "POST",
    body: JSON.stringify(textoTeste),
    headers: header
  }
  console.log('request')
  const response = await fetch("https://staging.pagamentobancario.com.br/api/v1/payer", options)
  const retorno = await response.json()
  let txt = JSON.stringify(retorno)
  console.log(retorno)
  document.getElementById('response').innerHTML = txt
  }


async function getPayer(){
  const cnpj = document.getElementById('cnpjsh').value
  const token = document.getElementById('tokensh').value
  const payercpfcnpj = document.getElementById('payercpfcnpj').value

  const header = new Headers();
  header.append("cnpjsh", cnpj)
  header.append("tokensh", token)
  header.append("payercpfcnpj", payercpfcnpj)
  header.append("Accept", "application/json")
  header.append("Content-Type", "application/json")

  const options = {
    method: "get",
    headers: header
  }

  const response = await fetch("https://staging.pagamentobancario.com.br/api/v1/payer", options)
  const retorno = await response.json()
  let txt = JSON.stringify(retorno)
  console.log(retorno)
  document.getElementById('response').innerHTML = txt
}  

async function putPayer(){
  const cnpj = document.getElementById('cnpjsh').value
  const token = document.getElementById('tokensh').value
  const payercpfcnpj = document.getElementById('payercpfcnpj').value
  const textoTeste = JSON.parse(document.getElementById('txtJason').value)

  const header = new Headers();
  header.append("cnpjsh", cnpj)
  header.append("tokensh", token)
  header.append("payercpfcnpj", payercpfcnpj)
  header.append("Accept", "application/json")
  header.append("Content-Type", "application/json")

  console.log(textoTeste)
  const options = {
    method: "PUT",
    body: JSON.stringify(textoTeste),
    headers: header
  }
  console.log('request')
  const response = await fetch("https://staging.pagamentobancario.com.br/api/v1/payer", options)
  const retorno = await response.json()
  let txt = JSON.stringify(retorno)
  console.log(retorno)
  document.getElementById('response').innerHTML = txt
}

async function getListPayer(){
  const cnpj = document.getElementById('cnpjsh').value
  const token = document.getElementById('tokensh').value
  const payercpfcnpj = document.getElementById('payercpfcnpj').value

  const header = new Headers();
  header.append("cnpjsh", cnpj)
  header.append("tokensh", token)
  header.append("payercpfcnpj", payercpfcnpj)
  header.append("Accept", "application/json")
  header.append("Content-Type", "application/json")

  const options = {
    method: "GET",
    headers: header
  }
  console.log('request')
  const response = await fetch("https://staging.pagamentobancario.com.br/api/v1/payer/list", options)
  const retorno = await response.json()
  let txt = JSON.stringify(retorno)
  console.log(retorno)
  document.getElementById('response').innerHTML = txt
}

//CONTA---------------------------------------------------------
async function postAccount(){
  const cnpj = document.getElementById('cnpjsh').value
  const token = document.getElementById('tokensh').value
  const payercpfcnpj = document.getElementById('payercpfcnpj').value
  const textoTeste = JSON.parse(document.getElementById('txtJason').value)

  const header = new Headers();
  header.append("cnpjsh", cnpj)
  header.append("tokensh", token)
  header.append("payercpfcnpj", payercpfcnpj)
  header.append("Accept", "application/json")
  header.append("Content-Type", "application/json")

  console.log(textoTeste)
  const options = {
    method: "POST",
    body: JSON.stringify(textoTeste),
    headers: header
  }
  console.log('request')
  const response = await fetch("https://staging.pagamentobancario.com.br/api/v1/account", options)
  const retorno = await response.json()
    let txt = JSON.stringify(retorno)
    console.log(retorno)
    document.getElementById('response').innerHTML = txt
}

async function deleteAccount(){
  const cnpj = document.getElementById('cnpjsh').value
  const token = document.getElementById('tokensh').value
  const payercpfcnpj = document.getElementById('payercpfcnpj').value
  const textoTeste = JSON.parse(document.getElementById('txtJason').value)

  const header = new Headers();
  header.append("cnpjsh", cnpj)
  header.append("tokensh", token)
  header.append("payercpfcnpj", payercpfcnpj)
  header.append("Accept", "application/json")
  header.append("Content-Type", "application/json")

  console.log(textoTeste)
  const options = {
    method: "DELETE",
    body: JSON.stringify(textoTeste),
    headers: header
  }
  console.log('request')
  const response = await fetch("https://staging.pagamentobancario.com.br/api/v1/account", options)
  const retorno = await response.json()
    let txt = JSON.stringify(retorno)
    console.log(retorno)
    document.getElementById('response').innerHTML = txt
}

async function getAccount(){
  const cnpj = document.getElementById('cnpjsh').value
  const token = document.getElementById('tokensh').value
  const payercpfcnpj = document.getElementById('payercpfcnpj').value

  const header = new Headers();
  header.append("cnpjsh", cnpj)
  header.append("tokensh", token)
  header.append("payercpfcnpj", payercpfcnpj)
  header.append("Accept", "application/json")
  header.append("Content-Type", "application/json")

  const options = {
    method: "GET",
    headers: header
  }

  const response = await fetch("https://staging.pagamentobancario.com.br/api/v1/account", options)
  const retorno = await response.json()
    let txt = JSON.stringify(retorno)
    console.log(retorno)
    document.getElementById('response').innerHTML = txt
}  

async function getAccountAccountHash(){
  const cnpj = document.getElementById('cnpjsh').value
  const token = document.getElementById('tokensh').value
  const payercpfcnpj = document.getElementById('payercpfcnpj').value
  const accounthash = document.getElementById('accounthash').value

  const header = new Headers();
  header.append("cnpjsh", cnpj)
  header.append("tokensh", token)
  header.append("payercpfcnpj", payercpfcnpj)
  header.append("Accept", "application/json")
  header.append("Content-Type", "application/json")

  const options = {
    method: "GET",
    headers: header
  }

  const response = await fetch("https://staging.pagamentobancario.com.br/api/v1/account/" + accounthash, options)
  const retorno = await response.json()
    let txt = JSON.stringify(retorno)
    console.log(retorno)
    document.getElementById('response').innerHTML = txt
}  

async function putAccount(){
  const cnpj = document.getElementById('cnpjsh').value
  const token = document.getElementById('tokensh').value
  const payercpfcnpj = document.getElementById('payercpfcnpj').value
  const accounthash = document.getElementById('accounthash').value
  const textoTeste = JSON.parse(document.getElementById('txtJason').value)

  const header = new Headers();
  header.append("cnpjsh", cnpj)
  header.append("tokensh", token)
  header.append("payercpfcnpj", payercpfcnpj)
  header.append("Accept", "application/json")
  header.append("Content-Type", "application/json")

  console.log(textoTeste)
  const options = {
    method: "PUT",
    body: JSON.stringify(textoTeste),
    headers: header
  }

  const response = await fetch("https://staging.pagamentobancario.com.br/api/v1/account/" + accounthash, options)
  const retorno = await response.json()
    let txt = JSON.stringify(retorno)
    console.log(retorno)
    document.getElementById('response').innerHTML = txt
}  

//PAGAMENTO---------------------------------------------------------

async function postPaymentType(){
  const cnpj = document.getElementById('cnpjsh').value
  const token = document.getElementById('tokensh').value
  const payercpfcnpj = document.getElementById('payercpfcnpj').value
  const textoTeste = JSON.parse(document.getElementById('txtJason').value)
  const paymentTypeSelect = document.getElementById('paymentTypeSelect').value

  const header = new Headers();
  header.append("cnpjsh", cnpj)
  header.append("tokensh", token)
  header.append("payercpfcnpj", payercpfcnpj)
  header.append("Accept", "application/json")
  header.append("Content-Type", "application/json")

  console.log(textoTeste)
  const options = {
    method: "POST",
    body: JSON.stringify(textoTeste),
    headers: header
  }

  const urlMappings = {
    billet: "https://staging.pagamentobancario.com.br/api/v1/payment/billet",
    transfer: "https://staging.pagamentobancario.com.br/api/v1/payment/transfer",
    paycheck: "https://staging.pagamentobancario.com.br/api/v1/payment/paycheck",
    gare: "https://staging.pagamentobancario.com.br/api/v1/payment/taxes/gare",
    ipva: "https://staging.pagamentobancario.com.br/api/v1/payment/taxes/ipva",
    dpvat: "https://staging.pagamentobancario.com.br/api/v1/payment/taxes/dpvat",
    darf: "https://staging.pagamentobancario.com.br/api/v1/payment/taxes/darf",
    gps: "https://staging.pagamentobancario.com.br/api/v1/payment/taxes/gps",
    fgts: "https://staging.pagamentobancario.com.br/api/v1/payment/taxes/fgts",
    various: "https://staging.pagamentobancario.com.br/api/v1/payment/various"
  };

  const apiUrl = urlMappings[paymentTypeSelect];

  const response = await fetch(apiUrl, options);

  console.log(apiUrl)
  console.log('request')

  const retorno = await response.json()
    let txt = JSON.stringify(retorno)
    console.log(retorno)
    document.getElementById('response').innerHTML = txt 
}

async function getPayment(){
  const cnpj = document.getElementById('cnpjsh').value
  const token = document.getElementById('tokensh').value
  const payercpfcnpj = document.getElementById('payercpfcnpj').value
  const uniqueId = document.getElementById('uniqueId').value

  const header = new Headers();
  header.append("cnpjsh", cnpj)
  header.append("tokensh", token)
  header.append("payercpfcnpj", payercpfcnpj)
  header.append("Accept", "application/json")
  header.append("Content-Type", "application/json")

  const options = {
    method: "GET",
    headers: header
  }

  const response = await fetch("https://staging.pagamentobancario.com.br/api/v1/payment?uniqueId=" + uniqueId, options)
  const retorno = await response.json()
    let txt = JSON.stringify(retorno)
    console.log(retorno)
    document.getElementById('response').innerHTML = txt
}  

async function deletePayment(){
  const cnpj = document.getElementById('cnpjsh').value
  const token = document.getElementById('tokensh').value
  const payercpfcnpj = document.getElementById('payercpfcnpj').value
  const textoTeste = JSON.parse(document.getElementById('txtJason').value)

  const header = new Headers();
  header.append("cnpjsh", cnpj)
  header.append("tokensh", token)
  header.append("payercpfcnpj", payercpfcnpj)
  header.append("Accept", "application/json")
  header.append("Content-Type", "application/json")

  console.log(textoTeste)
  const options = {
    method: "DELETE",
    body: JSON.stringify(textoTeste),
    headers: header
  }

  const response = await fetch("https://staging.pagamentobancario.com.br/api/v1/payment", options)
  const retorno = await response.json()
    let txt = JSON.stringify(retorno)
    console.log(retorno)
    document.getElementById('response').innerHTML = txt
}  

//PAGAMENTO EM LOTE---------------------------------------------------------
async function postSalariosBatch(){
  const cnpj = document.getElementById('cnpjsh').value
  const token = document.getElementById('tokensh').value
  const payercpfcnpj = document.getElementById('payercpfcnpj').value
  const textoTeste = JSON.parse(document.getElementById('txtJason').value)

  const header = new Headers();
  header.append("cnpjsh", cnpj)
  header.append("tokensh", token)
  header.append("payercpfcnpj", payercpfcnpj)
  header.append("Accept", "application/json")
  header.append("Content-Type", "application/json")

  console.log(textoTeste)
  const options = {
    method: "POST",
    body: JSON.stringify(textoTeste),
    headers: header
  }

  const response = await fetch("https://staging.pagamentobancario.com.br/api/v1/payment/paycheck/batch", options)
  const retorno = await response.json()
    let txt = JSON.stringify(retorno)
    console.log(retorno)
    document.getElementById('response').innerHTML = txt
}  

async function postTransferBatch(){
  const cnpj = document.getElementById('cnpjsh').value
  const token = document.getElementById('tokensh').value
  const payercpfcnpj = document.getElementById('payercpfcnpj').value
  const textoTeste = JSON.parse(document.getElementById('txtJason').value)

  const header = new Headers();
  header.append("cnpjsh", cnpj)
  header.append("tokensh", token)
  header.append("payercpfcnpj", payercpfcnpj)
  header.append("Accept", "application/json")
  header.append("Content-Type", "application/json")

  console.log(textoTeste)
  const options = {
    method: "POST",
    body: JSON.stringify(textoTeste),
    headers: header
  }

  const response = await fetch("https://staging.pagamentobancario.com.br/api/v1/payment/transfer/batch", options)
  const retorno = await response.json()
    let txt = JSON.stringify(retorno)
    console.log(retorno)
    document.getElementById('response').innerHTML = txt
}  

async function getPaymentBatch(){
  const cnpj = document.getElementById('cnpjsh').value
  const token = document.getElementById('tokensh').value
  const payercpfcnpj = document.getElementById('payercpfcnpj').value
  const batchId = document.getElementById('batchId').value

  const header = new Headers();
  header.append("cnpjsh", cnpj)
  header.append("tokensh", token)
  header.append("payercpfcnpj", payercpfcnpj)
  header.append("Accept", "application/json")
  header.append("Content-Type", "application/json")

  const options = {
    method: "GET",
    headers: header
  }

  const response = await fetch("https://staging.pagamentobancario.com.br/api/v1/payment/batch/" + batchId, options)
  const retorno = await response.json()
    let txt = JSON.stringify(retorno)
    console.log(retorno)
    document.getElementById('response').innerHTML = txt
}  

//REMESSA---------------------------------------------------------
async function postRemittance(){
  const cnpj = document.getElementById('cnpjsh').value
  const token = document.getElementById('tokensh').value
  const payercpfcnpj = document.getElementById('payercpfcnpj').value
  const textoTeste = JSON.parse(document.getElementById('txtJason').value)

  const header = new Headers();
  header.append("cnpjsh", cnpj)
  header.append("tokensh", token)
  header.append("payercpfcnpj", payercpfcnpj)
  header.append("Accept", "application/json")
  header.append("Content-Type", "application/json")

  console.log(textoTeste)
  const options = {
    method: "POST",
    body: JSON.stringify(textoTeste),
    headers: header
  }
  console.log('request')
  const response = await fetch("https://staging.pagamentobancario.com.br/api/v1/remittance", options)
  const retorno = await response.json()
    let txt = JSON.stringify(retorno)
    console.log(retorno)
    document.getElementById('response').innerHTML = txt
}

async function getRemittance(){
  const cnpj = document.getElementById('cnpjsh').value
  const token = document.getElementById('tokensh').value
  const payercpfcnpj = document.getElementById('payercpfcnpj').value
  const uniqueid = document.getElementById('uniqueId').value
  

  const header = new Headers();
  header.append("cnpjsh", cnpj)
  header.append("tokensh", token)
  header.append("payercpfcnpj", payercpfcnpj)
  header.append("Accept", "application/json")
  header.append("Content-Type", "application/json")

  const options = {
    method: "get",
    headers: header
  }
  console.log('teste')
  const response = await fetch("https://staging.pagamentobancario.com.br/api/v1/remittance/" + uniqueid, options)
  const retorno = await response.json()
    let txt = JSON.stringify(retorno)
    console.log(retorno)
    document.getElementById('response').innerHTML = txt
}

async function getRemittanceByPeriod(){
  const cnpj = document.getElementById('cnpjsh').value
  const token = document.getElementById('tokensh').value
  const payercpfcnpj = document.getElementById('payercpfcnpj').value
  const dateStart = document.getElementById('dateStart').value
  const dateEnd = document.getElementById('dateEnd').value
  const page = document.getElementById('page').value
  const limit = document.getElementById('limit').value

  const header = new Headers();
  header.append("cnpjsh", cnpj)
  header.append("tokensh", token)
  header.append("payercpfcnpj", payercpfcnpj)
  header.append("Accept", "application/json")
  header.append("Content-Type", "application/json")

  const options = {
    method: "GET",
    headers: header
  }

  let urlRemessa = "https://staging.pagamentobancario.com.br/api/v1/remittance?dateStart=" + dateStart + "&dateEnd=" + dateEnd;

  if (page) {
    urlRemessa += "&page=" + page;
  }

  if (limit) {
    urlRemessa += "&limit=" + limit;
  }

  console.log('teste')
  const response = await fetch(urlRemessa, options)
  const retorno = await response.json()
    let txt = JSON.stringify(retorno)
    console.log(retorno)
    document.getElementById('response').innerHTML = txt
}

async function postCancellationRemittance(){
  const cnpj = document.getElementById('cnpjsh').value
  const token = document.getElementById('tokensh').value
  const payercpfcnpj = document.getElementById('payercpfcnpj').value
  const textoTeste = JSON.parse(document.getElementById('txtJason').value)

  const header = new Headers();
  header.append("cnpjsh", cnpj)
  header.append("tokensh", token)
  header.append("payercpfcnpj", payercpfcnpj)
  header.append("Accept", "application/json")
  header.append("Content-Type", "application/json")

  console.log(textoTeste)
  const options = {
    method: "POST",
    body: JSON.stringify(textoTeste),
    headers: header
  }
  console.log('request')
  const response = await fetch("https://staging.pagamentobancario.com.br/api/v1/remittance/cancel", options)
  const retorno = await response.json()
    let txt = JSON.stringify(retorno)
    console.log(retorno)
    document.getElementById('response').innerHTML = txt
}

async function getDownloadRemittance(){
  const cnpj = document.getElementById('cnpjsh').value
  const token = document.getElementById('tokensh').value
  const payercpfcnpj = document.getElementById('payercpfcnpj').value
  const uniqueid = document.getElementById('uniqueId').value
  

  const header = new Headers();
  header.append("cnpjsh", cnpj)
  header.append("tokensh", token)
  header.append("payercpfcnpj", payercpfcnpj)
  header.append("Accept", "application/json")
  header.append("Content-Type", "application/json")

  const options = {
    method: "GET",
    headers: header
  }
  console.log('teste')
  const response = await fetch("https://staging.pagamentobancario.com.br/api/v1/remittance/" + uniqueid + "/download", options)
  const retorno = await response.text()
    console.log(retorno)
    document.getElementById('response').innerHTML = retorno
}

//RETORNO---------------------------------------------------------

async function postReconciliation(){
  const cnpj = document.getElementById('cnpjsh').value
  const token = document.getElementById('tokensh').value
  const payercpfcnpj = document.getElementById('payercpfcnpj').value
  const file = document.getElementById('arquivo').files[0]

  const formData1 = new FormData()
  formData1.append('file', file.path)

  console.log(file)  

  const header = new Headers();
  header.append("cnpjsh", cnpj)
  header.append("tokensh", token)
  header.append("payercpfcnpj", payercpfcnpj)

  
  const options = {
    method: "POST",
    body: formData1,
    headers: header,
    }
  
  const response = await fetch("https://staging.pagamentobancario.com.br/api/v1/reconciliation", options)
  const retorno = await response.json()
    let txt = JSON.stringify(retorno)
    console.log(retorno)
    document.getElementById('response').innerHTML = txt
}

async function getReconciliationByPeriod(){
  const cnpj = document.getElementById('cnpjsh').value
  const token = document.getElementById('tokensh').value
  const payercpfcnpj = document.getElementById('payercpfcnpj').value
  const dateStart = document.getElementById('dateStart').value
  const dateEnd = document.getElementById('dateEnd').value
  const page = document.getElementById('page').value
  const limit = document.getElementById('limit').value

  const header = new Headers();
  header.append("cnpjsh", cnpj)
  header.append("tokensh", token)
  header.append("payercpfcnpj", payercpfcnpj)
  header.append("Accept", "application/json")
  header.append("Content-Type", "application/json")

  const options = {
    method: "GET",
    headers: header
  }

  let urlReconciliation = "https://staging.pagamentobancario.com.br/api/v1/reconciliation?dateStart=" + dateStart + "&dateEnd=" + dateEnd;

  if (page) {
    urlReconciliation += "&page=" + page;
  }

  if (limit) {
    urlReconciliation += "&limit=" + limit;
  }

  console.log('teste')
  const response = await fetch(urlReconciliation, options)
  const retorno = await response.json()
    let txt = JSON.stringify(retorno)
    console.log(retorno)
    document.getElementById('response').innerHTML = txt
}

async function getReconciliation(){
  const cnpj = document.getElementById('cnpjsh').value
  const token = document.getElementById('tokensh').value
  const payercpfcnpj = document.getElementById('payercpfcnpj').value
  const uniqueId = document.getElementById('uniqueId').value

  const header = new Headers();
  header.append("cnpjsh", cnpj)
  header.append("tokensh", token)
  header.append("payercpfcnpj", payercpfcnpj)
  header.append("Accept", "application/json")
  header.append("Content-Type", "application/json")

  const options = {
    method: "GET",
    headers: header
  }

  const response = await fetch("https://staging.pagamentobancario.com.br/api/v1/reconciliation/" + uniqueId, options)
  const retorno = await response.json()
    let txt = JSON.stringify(retorno)
    console.log(retorno)
    document.getElementById('response').innerHTML = txt
} 

async function getDownloadReconciliation(){
  const cnpj = document.getElementById('cnpjsh').value
  const token = document.getElementById('tokensh').value
  const payercpfcnpj = document.getElementById('payercpfcnpj').value
  const uniqueId = document.getElementById('uniqueId').value

  const header = new Headers();
  header.append("cnpjsh", cnpj)
  header.append("tokensh", token)
  header.append("payercpfcnpj", payercpfcnpj)
  header.append("Accept", "application/json")
  header.append("Content-Type", "application/json")

  const options = {
    method: "GET",
    headers: header
  }

  const response = await fetch("https://staging.pagamentobancario.com.br/api/v1/reconciliation/" + uniqueId + "/download", options)
  const retorno = await response.text()
    console.log(retorno)
    document.getElementById('response').innerHTML = retorno
} 

//COMPROVANTE-----------------------------------------------------------
async function postComprovante(){
  const cnpj = document.getElementById('cnpjsh').value
  const token = document.getElementById('tokensh').value
  const payercpfcnpj = document.getElementById('payercpfcnpj').value
  const textoTeste = JSON.parse(document.getElementById('txtJason').value)

  const header = new Headers();
  header.append("cnpjsh", cnpj)
  header.append("tokensh", token)
  header.append("payercpfcnpj", payercpfcnpj)
  header.append("Accept", "application/json")
  header.append("Content-Type", "application/json")

  console.log(textoTeste)
  const options = {
    method: "POST",
    body: JSON.stringify(textoTeste),
    headers: header
  }
  console.log('request')
  const response = await fetch("https://staging.pagamentobancario.com.br/api/v1/voucher", options)
  const retorno = await response.json()
    let txt = JSON.stringify(retorno)
    console.log(retorno)
    document.getElementById('response').innerHTML = txt
}

async function getComprovante(){
  const cnpj = document.getElementById('cnpjsh').value
  const token = document.getElementById('tokensh').value
  const payercpfcnpj = document.getElementById('payercpfcnpj').value
  const uniqueid = document.getElementById('uniqueId').value
  

  const header = new Headers();
  header.append("cnpjsh", cnpj)
  header.append("tokensh", token)
  header.append("payercpfcnpj", payercpfcnpj)
  header.append("Accept", "application/json")
  header.append("Content-Type", "application/json")

  const options = {
    method: "GET",
    headers: header
  }

  console.log('Abrindo comprovante em uma nova aba...')
  const response = await fetch("https://staging.pagamentobancario.com.br/api/v1/voucher/" + uniqueid, options)
  const retorno = await response.arrayBuffer()
  const blob = new Blob([retorno], { type: 'application/pdf' });
  // Criar uma URL do blob
  const blobUrl = URL.createObjectURL(blob);
  // Abrir o PDF em uma nova aba
  window.open(blobUrl, '_blank');
}

//BILHETAGEM---------------------------------------------
async function getBilhetagem(){
  const cnpj = document.getElementById('cnpjsh').value
  const token = document.getElementById('tokensh').value
  const payercpfcnpj = document.getElementById('payercpfcnpj').value
  const dateStart = document.getElementById('dateStart').value
  const dateEnd = document.getElementById('dateEnd').value
  const page = document.getElementById('page').value
  const limit = document.getElementById('limit').value

  const header = new Headers();
  header.append("cnpjsh", cnpj)
  header.append("tokensh", token)
  header.append("payercpfcnpj", payercpfcnpj)
  header.append("Accept", "application/json")
  header.append("Content-Type", "application/json")

  const options = {
    method: "GET",
    headers: header
  }

  let urlBilhetagem = "https://staging.pagamentobancario.com.br/api/v1/report?dateStart=" + dateStart + "&dateEnd=" + dateEnd;

  if (page) {
    urlBilhetagem += "&page=" + page;
  }

  if (limit) {
    urlBilhetagem += "&limit=" + limit;
  }

  console.log('teste')
  const response = await fetch(urlBilhetagem, options)
  const retorno = await response.json()
    let txt = JSON.stringify(retorno)
    console.log(retorno)
    document.getElementById('response').innerHTML = txt
}

//NOTIFICAÇÃO---------------------------------------------------
async function postNotification(){
  const cnpj = document.getElementById('cnpjsh').value
  const token = document.getElementById('tokensh').value
  const payercpfcnpj = document.getElementById('payercpfcnpj').value
  const textoTeste = JSON.parse(document.getElementById('txtJason').value)

  const header = new Headers();
  header.append("cnpjsh", cnpj)
  header.append("tokensh", token)
  header.append("payercpfcnpj", payercpfcnpj)
  header.append("Accept", "application/json")
  header.append("Content-Type", "application/json")

  console.log(textoTeste)
  const options = {
    method: "POST",
    body: JSON.stringify(textoTeste),
    headers: header
  }
  console.log('request')
  const response = await fetch("https://staging.pagamentobancario.com.br/api/v1/notification", options)
  const retorno = await response.json()
    let txt = JSON.stringify(retorno)
    console.log(retorno)
    document.getElementById('response').innerHTML = txt
}

async function getNotifications(){
  const cnpj = document.getElementById('cnpjsh').value
  const token = document.getElementById('tokensh').value
  const payercpfcnpj = document.getElementById('payercpfcnpj').value

  const header = new Headers();
  header.append("cnpjsh", cnpj)
  header.append("tokensh", token)
  header.append("payercpfcnpj", payercpfcnpj)
  header.append("Accept", "application/json")
  header.append("Content-Type", "application/json")

  const options = {
    method: "GET",
    headers: header
  }

  const response = await fetch("https://staging.pagamentobancario.com.br/api/v1/notification", options)
  const retorno = await response.json()
    let txt = JSON.stringify(retorno)
    console.log(retorno)
    document.getElementById('response').innerHTML = txt
}  

async function deleteNotification(){
  const cnpj = document.getElementById('cnpjsh').value
  const token = document.getElementById('tokensh').value
  const payercpfcnpj = document.getElementById('payercpfcnpj').value
  const textoTeste = JSON.parse(document.getElementById('txtJason').value)

  const header = new Headers();
  header.append("cnpjsh", cnpj)
  header.append("tokensh", token)
  header.append("payercpfcnpj", payercpfcnpj)
  header.append("Accept", "application/json")
  header.append("Content-Type", "application/json")

  console.log(textoTeste)
  const options = {
    method: "DELETE",
    body: JSON.stringify(textoTeste),
    headers: header
  }
  console.log('request')
  const response = await fetch("https://staging.pagamentobancario.com.br/api/v1/notification", options)
  const retorno = await response.json()
    let txt = JSON.stringify(retorno)
    console.log(retorno)
    document.getElementById('response').innerHTML = txt
}

async function putNotification(){
  const cnpj = document.getElementById('cnpjsh').value
  const token = document.getElementById('tokensh').value
  const payercpfcnpj = document.getElementById('payercpfcnpj').value
  const textoTeste = JSON.parse(document.getElementById('txtJason').value)

  const header = new Headers();
  header.append("cnpjsh", cnpj)
  header.append("tokensh", token)
  header.append("payercpfcnpj", payercpfcnpj)
  header.append("Accept", "application/json")
  header.append("Content-Type", "application/json")

  console.log(textoTeste)
  const options = {
    method: "PUT",
    body: JSON.stringify(textoTeste),
    headers: header
  }
  console.log('request')
  const response = await fetch("https://staging.pagamentobancario.com.br/api/v1/notification", options)
  const retorno = await response.json()
    let txt = JSON.stringify(retorno)
    console.log(retorno)
    document.getElementById('response').innerHTML = txt
}

//EXTRATO---------------------------------------------------------------
async function postStatement(){
  const cnpj = document.getElementById('cnpjsh').value
  const token = document.getElementById('tokensh').value
  const payercpfcnpj = document.getElementById('payercpfcnpj').value
  const file = document.getElementById('arquivo').files[0]

  const formData1 = new FormData()
  formData1.append('file', file.path)

  console.log(file)  

  const header = new Headers();
  header.append("cnpjsh", cnpj)
  header.append("tokensh", token)
  header.append("payercpfcnpj", payercpfcnpj)

  
  const options = {
    method: "POST",
    body: formData1,
    headers: header,
    }
  
  const response = await fetch("https://staging.pagamentobancario.com.br/api/v1/statement/parser", options)
  const retorno = await response.json()
    let txt = JSON.stringify(retorno)
    console.log(retorno)
    document.getElementById('response').innerHTML = txt
}

async function getStatement(){
  const cnpj = document.getElementById('cnpjsh').value
  const token = document.getElementById('tokensh').value
  const payercpfcnpj = document.getElementById('payercpfcnpj').value
  const uniqueId = document.getElementById('uniqueId').value
  console.log(uniqueId)

  const header = new Headers();
  header.append("cnpjsh", cnpj)
  header.append("tokensh", token)
  header.append("payercpfcnpj", payercpfcnpj)
  header.append("Accept", "application/json")
  header.append("Content-Type", "application/json")

  const options = {
    method: "get",
    headers: header
  }

  const response = await fetch("https://staging.pagamentobancario.com.br/api/v1/statement/parser/" + uniqueId, options)
  const retorno = await response.json()
    let txt = JSON.stringify(retorno)
    console.log(retorno)
    document.getElementById('response').innerHTML = txt

} 

async function getStatementByPeriod(){
  const cnpj = document.getElementById('cnpjsh').value
  const token = document.getElementById('tokensh').value
  const payercpfcnpj = document.getElementById('payercpfcnpj').value
  const dateStart = document.getElementById('dateStart').value
  const dateEnd = document.getElementById('dateEnd').value
  const accounthash = document.getElementById('accountHash').value
  const page = document.getElementById('page').value
  const limit = document.getElementById('limit').value

  const header = new Headers();
  header.append("cnpjsh", cnpj)
  header.append("tokensh", token)
  header.append("payercpfcnpj", payercpfcnpj)
  header.append("Accept", "application/json")
  header.append("Content-Type", "application/json")

  const options = {
    method: "GET",
    headers: header
  }

  let urlExtrato = "https://staging.pagamentobancario.com.br/api/v1/statement?dateStart=" + dateStart + "&dateEnd=" + dateEnd;

  if (accounthash) {
    urlExtrato += "&accountHash=" + accounthash;
  }

  if (page) {
    urlExtrato += "&page=" + page;
  }

  if (limit) {
    urlExtrato += "&limit=" + limit;
  }

  console.log('teste')
  const response = await fetch(urlExtrato, options)
  const retorno = await response.json()
    let txt = JSON.stringify(retorno)
    console.log(retorno)
    document.getElementById('response').innerHTML = txt
}

async function getDownloadStatement(){
  const cnpj = document.getElementById('cnpjsh').value
  const token = document.getElementById('tokensh').value
  const payercpfcnpj = document.getElementById('payercpfcnpj').value
  const uniqueId = document.getElementById('uniqueId').value

  const header = new Headers();
  header.append("cnpjsh", cnpj)
  header.append("tokensh", token)
  header.append("payercpfcnpj", payercpfcnpj)
  header.append("Accept", "application/json")
  header.append("Content-Type", "application/json")

  const options = {
    method: "GET",
    headers: header
  }

  const response = await fetch("https://staging.pagamentobancario.com.br/api/v1/statement/" + uniqueId + "/download", options)
  const retorno = await response.text()
    console.log(retorno)
    document.getElementById('response').innerHTML = retorno
} 

//DDA---------------------------------------------------------------
async function postDDA() {
  const cnpj = document.getElementById('cnpjsh').value;
  const token = document.getElementById('tokensh').value;
  const payercpfcnpj = document.getElementById('payercpfcnpj').value;
  const file = document.getElementById('arquivo').files[0];  
  const accountHash = document.getElementById('accountHash').value;

  const formData = new FormData();
  formData.append('file', file); 
  formData.append('accountHash', accountHash); 

  console.log(file);

  const headers = new Headers();
  headers.append("cnpjsh", cnpj);
  headers.append("tokensh", token);
  headers.append("payercpfcnpj", payercpfcnpj);

  const options = {
    method: "POST",
    body: formData,
    headers: headers,
  };

  try {
    const response = await fetch("https://staging.pagamentobancario.com.br/api/v1/dda", options);
    const retorno = await response.json();
    let txt = JSON.stringify(retorno);
    console.log(retorno);
    document.getElementById('response').innerHTML = txt;
  } catch (error) {
    console.error('Erro na requisição:', error);
  }
}

async function getDDAUniqueId(){
  const cnpj = document.getElementById('cnpjsh').value
  const token = document.getElementById('tokensh').value
  const payercpfcnpj = document.getElementById('payercpfcnpj').value
  const uniqueId = document.getElementById('uniqueId').value

  const header = new Headers();
  header.append("cnpjsh", cnpj)
  header.append("tokensh", token)
  header.append("payercpfcnpj", payercpfcnpj)
  header.append("Accept", "application/json")
  header.append("Content-Type", "application/json")

  const options = {
    method: "GET",
    headers: header
  }

  const response = await fetch("https://staging.pagamentobancario.com.br/api/v1/dda/" + uniqueId, options)
  const retorno = await response.text()
    console.log(retorno)
    document.getElementById('response').innerHTML = retorno
} 

async function getDDAUltimos(){
  const cnpj = document.getElementById('cnpjsh').value
  const token = document.getElementById('tokensh').value
  const payercpfcnpj = document.getElementById('payercpfcnpj').value

  const header = new Headers();
  header.append("cnpjsh", cnpj)
  header.append("tokensh", token)
  header.append("payercpfcnpj", payercpfcnpj)
  header.append("Accept", "application/json")
  header.append("Content-Type", "application/json")

  const options = {
    method: "GET",
    headers: header
  }

  const response = await fetch("https://staging.pagamentobancario.com.br/api/v1/dda", options)
  const retorno = await response.text()
    console.log(retorno)
    document.getElementById('response').innerHTML = retorno
} 

async function getPaymentDDA(){
  const cnpj = document.getElementById('cnpjsh').value
  const token = document.getElementById('tokensh').value
  const payercpfcnpj = document.getElementById('payercpfcnpj').value
  const uniqueId = document.getElementById('uniqueId').value

  const header = new Headers();
  header.append("cnpjsh", cnpj)
  header.append("tokensh", token)
  header.append("payercpfcnpj", payercpfcnpj)
  header.append("Accept", "application/json")
  header.append("Content-Type", "application/json")

  const options = {
    method: "GET",
    headers: header
  }

  const response = await fetch("https://staging.pagamentobancario.com.br/api/v1/dda/payment/" + uniqueId, options)
  const retorno = await response.text()
    console.log(retorno)
    document.getElementById('response').innerHTML = retorno
} 