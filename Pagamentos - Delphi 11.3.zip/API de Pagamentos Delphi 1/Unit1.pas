﻿unit Unit1;

interface

uses
  Winapi.Windows, Winapi.Messages, System.SysUtils, System.Variants,
  System.Classes, Vcl.Graphics, IdMultipartFormData,
  Vcl.Controls, Vcl.Forms, Vcl.Dialogs, Vcl.StdCtrls, Vcl.ComCtrls,
  IdSSLOpenSSL, IdHTTP, superobject, ExtCtrls, ComObj, ActiveX, IdCoderMIME,
  AxCtrls,
  Vcl.Buttons;

type
  TForm1 = class(TForm)
    textoEntrada: TMemo;
    textoResposta: TMemo;
    Payer: TPageControl;
    tabPayer: TTabSheet;
    btnCadPayer: TButton;
    btnEditPayer: TButton;
    boxIdPayer: TEdit;
    tabConta: TTabSheet;
    tabBoletoRemessaRetorno: TTabSheet;
    tabEmailImpressao: TTabSheet;
    boxIdConta: TEdit;
    btnCadConta: TButton;
    btnEditConta: TButton;
    btnDelConta: TButton;
    btnGerarPagamento: TButton;
    btnConsultarPagamento: TButton;
    solicitaRemessa: TButton;
    btnUploadRetorno: TButton;
    btnConsultarRetorno: TButton;
    boxProtocoloRetorno: TEdit;
    Label8: TLabel;
    Label9: TLabel;
    Label12: TLabel;
    btnIncluirExtrato: TButton;
    SaveDialogPDF: TSaveDialog;
    tabConfiguracoes: TTabSheet;
    Label5: TLabel;
    Label3: TLabel;
    Label2: TLabel;
    Label1: TLabel;
    boxTokenSh: TEdit;
    boxCnpjsh: TEdit;
    boxCnpjPayer: TEdit;
    ambinete: TGroupBox;
    ambienteHomologacao: TRadioButton;
    ambienteProducao: TRadioButton;
    Button1: TButton;
    Button2: TButton;
    Button3: TButton;
    Button4: TButton;
    Button5: TButton;
    Button10: TButton;
    Button12: TButton;
    Button13: TButton;
    Button14: TButton;
    Button15: TButton;
    Button16: TButton;
    Retorno: TTabSheet;
    Label6: TLabel;
    Entrada: TLabel;
    Label13: TLabel;
    OpenDialogRetorno: TOpenDialog;
    Label15: TLabel;
    Label16: TLabel;
    Label17: TLabel;
    Label19: TLabel;
    Label20: TLabel;
    Label24: TLabel;
    boxTipoPagamento: TComboBox;
    btnConsultarExtrato: TBitBtn;
    procedure btnCadPayerClick(Sender: TObject);
    procedure btnEditPayerClick(Sender: TObject);
    procedure btnCadContaClick(Sender: TObject);
    procedure btnEditContaClick(Sender: TObject);
    procedure btnDelContaClick(Sender: TObject);
    procedure btnGerarPagamentoClick(Sender: TObject);
    procedure btnConsultarPagamentoClick(Sender: TObject);
    procedure solicitaRemessaClick(Sender: TObject);
    procedure btnUploadRetornoClick(Sender: TObject);
    procedure btnConsultarRetornoClick(Sender: TObject);
    procedure btnIncluirExtratoClick(Sender: TObject);
    procedure Button1Click(Sender: TObject);
    procedure Button2Click(Sender: TObject);
    procedure Button3Click(Sender: TObject);
    procedure Button4Click(Sender: TObject);
    procedure Button5Click(Sender: TObject);
    procedure Button10Click(Sender: TObject);
    procedure Button11Click(Sender: TObject);
    procedure Button12Click(Sender: TObject);
    procedure Button15Click(Sender: TObject);
    procedure Button16Click(Sender: TObject);
    procedure Button18Click(Sender: TObject);
    procedure Button14Click(Sender: TObject);
    procedure Button13Click(Sender: TObject);
    procedure btnConsultarExtratoClick(Sender: TObject);
  private
    { Private declarations }
    function HttpRequest(const aBody: string; const aMethod: String;
      aURL: String; aTimeout: integer; const aContentType: string = '')
      : TStringStream;
  public
    { Public declarations }
  end;

var
  Form1: TForm1;
  conteudoRemessa: TStringList;

implementation

{$R *.dfm}

function TForm1.HttpRequest(const aBody, aMethod: String; aURL: String;
  aTimeout: integer; const aContentType: string): TStringStream;
var
  Request: OleVariant;
  HttpStream: IStream;
  OleStream: TOleStream;
  fs: TFileStream;
  teste: string;
  _StringStream: TStringStream;
begin
  CoInitialize(nil);
  _StringStream := TStringStream.Create;
  try
    Request := CreateOleObject('WinHttp.WinHttpRequest.5.1');
    Request.Open(aMethod, aURL, False);
    Request.SetRequestHeader('Content-Type', aContentType);
    Request.SetRequestHeader('cnpjSh', boxCnpjsh.Text);
    Request.SetRequestHeader('tokenSh', boxTokenSh.Text);
    Request.SetRequestHeader('payercpfcnpj', boxCnpjPayer.Text);
    Request.Send(aBody);
    HttpStream := IUnknown(Request.ResponseStream) as IStream;

    OleStream := TOleStream.Create(HttpStream);
    _StringStream.LoadFromStream(OleStream);

    Result := _StringStream
  finally
    OleStream.Free;
    Request := Unassigned;
    CoUninitialize;
  end;

end;

procedure TForm1.btnCadPayerClick(Sender: TObject);
var
  json, envio, url: string;
  _ObjetoResposta, _ObjetoEnvio, _ObjetoSucesso: ISuperObject;
  _StringStream: TStringStream;
  I: integer;
begin
  _StringStream := TStringStream.Create;
  if ambienteHomologacao.Checked = True then
    url := 'https://staging.pagamentobancario.com.br/api/v1/payer'
  else if ambienteProducao.Checked = True then
    url := 'https://api.pagamentobancario.com.br/api/v1/payer';

  _StringStream := HttpRequest(textoEntrada.Text, 'POST', url, 100000,
    'application/json');

  _ObjetoResposta := SO(Utf8ToAnsi(_StringStream.DataString));
  _StringStream.Free;

  textoResposta.Text := '';
  textoResposta.Text := (_ObjetoResposta.AsJSon(True));

  envio := _ObjetoResposta.AsString;
end;

procedure TForm1.btnEditPayerClick(Sender: TObject);

var
  json, envio, url: string;
  _ObjetoResposta, _ObjetoEnvio, _ObjetoSucesso: ISuperObject;
  _StringStream: TStringStream;
  I: integer;
begin
  _StringStream := TStringStream.Create;
  if ambienteHomologacao.Checked = True then
    url := 'https://staging.pagamentobancario.com.br/api/v1/payer'
  else if ambienteProducao.Checked = True then
    url := 'https://api.pagamentobancario.com.br/api/v1/payer';

  _StringStream := HttpRequest(textoEntrada.Text, 'PUT', url + boxIdPayer.Text,
    10000, 'application/json');

  _ObjetoResposta := SO(Utf8ToAnsi(_StringStream.DataString));

  textoResposta.Text := '';
  textoResposta.Lines.Add(_ObjetoResposta.AsJSon(True));
  envio := _ObjetoResposta.AsString;

end;

procedure TForm1.btnConsultarExtratoClick(Sender: TObject);
var
  json, envio, url: string;
  _ObjetoResposta, _ObjetoEnvio, _ObjetoSucesso: ISuperObject;
  _StringStream: TStringStream;
  I: integer;
begin
  if ambienteHomologacao.Checked = True then
    url := 'https://staging.pagamentobancario.com.br/api/v1/statement/parser/' +
      textoEntrada.Text
  else if ambienteProducao.Checked = True then
    url := 'https://api.pagamentobancario.com.br/api/v1/reconciliation/' +
      textoEntrada.Text;

  _StringStream := HttpRequest(NullAsStringValue, 'GET',
    url + boxProtocoloRetorno.Text, 100000, 'application/json');

  _ObjetoResposta := SO(Utf8ToAnsi(_StringStream.DataString));

  _ObjetoResposta.AsJSon(True);
  envio := _ObjetoResposta.AsString;
  textoEntrada.Text := SO(Utf8ToAnsi(envio)).AsString;

end;

procedure TForm1.btnCadContaClick(Sender: TObject);
var
  json, envio, url: string;
  _ObjetoResposta, _ObjetoEnvio, _ObjetoSucesso, jsonResposta: ISuperObject;
  _StringStream: TStringStream;
  I: integer;
begin
  if ambienteHomologacao.Checked = True then
    url := 'https://staging.pagamentobancario.com.br/api/v1/account'
  else if ambienteProducao.Checked = True then
    url := 'https://api.pagamentobancario.com.br/api/v1/account';

  _StringStream := HttpRequest(textoEntrada.Text, 'POST', url, 100000,
    'application/json');

  _ObjetoResposta := SO(Utf8ToAnsi(_StringStream.DataString));
  _StringStream.Free;

  textoResposta.Text := '';
  textoResposta.Text := (_ObjetoResposta.AsJSon(True));

  envio := _ObjetoResposta.AsString;

end;

procedure TForm1.btnEditContaClick(Sender: TObject);
var
  json, envio, url: string;
  _ObjetoResposta, _ObjetoEnvio, _ObjetoSucesso, jsonResposta: ISuperObject;
  _StringStream: TStringStream;
  I: integer;
begin
  if ambienteHomologacao.Checked = True then
    url := 'https://staging.pagamentobancario.com.br/api/v1/account' +
      boxIdConta.Text
  else if ambienteProducao.Checked = True then
    url := 'https://api.pagamentobancario.com.br/api/v1/account' +
      boxIdConta.Text;

  _StringStream := HttpRequest(textoEntrada.Text, 'PUT', url, 10000,
    'application/json');

  _ObjetoResposta := SO(Utf8ToAnsi(_StringStream.DataString));
  _StringStream.Free;

  textoResposta.Text := '';
  textoResposta.Text := (_ObjetoResposta.AsJSon(True));

  envio := _ObjetoResposta.AsString;

end;

procedure TForm1.btnDelContaClick(Sender: TObject);
var
  json, envio, url: string;
  _ObjetoResposta, _ObjetoEnvio, _ObjetoSucesso: ISuperObject;
  _StringStream: TStringStream;
  I: integer;
begin
  if ambienteHomologacao.Checked = True then
    url := 'https://staging.pagamentobancario.com.br/api/v1/account' +
      boxIdConta.Text
  else if ambienteProducao.Checked = True then
    url := 'https://api.pagamentobancario.com.br/api/v1/account' +
      boxIdConta.Text;

  textoEntrada.Text := '';

  _StringStream := HttpRequest(NullAsStringValue, 'DELETE',
    url + boxIdConta.Text, 10000, 'application/json');

  _ObjetoResposta := SO(Utf8ToAnsi(_StringStream.DataString));
  _StringStream.Free;

  textoResposta.Text := '';
  textoResposta.Lines.Add(_ObjetoResposta.AsJSon(True));

  envio := _ObjetoResposta.AsString;

end;

procedure TForm1.btnGerarPagamentoClick(Sender: TObject);
var
  impressao, idintegracao, envio, url, tipoImpressao: string;
  _ObjetoResposta, _ObjetoEnvio, _ObjetoSucesso, jsonResposta, _ObjetoEnvioArray
    : ISuperObject;
  _StringStream: TStringStream;
  I: integer;
begin
  if ambienteHomologacao.Checked = True then
    url := 'https://staging.pagamentobancario.com.br/api/v1/payment/'
  else if ambienteProducao.Checked = True then
    url := 'https://api.pagamentobancario.com.br/api/v1/payment/';

  begin

    if boxTipoPagamento.ItemIndex = 0 then
    begin
      url := url + 'billet';
    end

    else if boxTipoPagamento.ItemIndex = 1 then
    begin
      url := url + 'transfer';
    end
    else if boxTipoPagamento.ItemIndex = 2 then
    begin
      url := url + 'paycheck';
    end
    else if boxTipoPagamento.ItemIndex = 3 then
    begin
      url := url + 'taxes/gare';
    end
    else if boxTipoPagamento.ItemIndex = 4 then
    begin
      url := url + 'taxes/ipva';
    end
    else if boxTipoPagamento.ItemIndex = 5 then
    begin
      url := url + 'taxes/dpvat';
    end
    else if boxTipoPagamento.ItemIndex = 6 then
    begin
      url := url + 'taxes/darf';
    end
    else if boxTipoPagamento.ItemIndex = 7 then
    begin
      url := url + 'taxes/gps';
    end
    else if boxTipoPagamento.ItemIndex = 8 then
    begin
      url := url + 'taxez/fgts';
    end
    else if boxTipoPagamento.ItemIndex = 9 then
    begin
      url := url + 'various';
    end

  end;

  _StringStream := HttpRequest(textoEntrada.Text, 'POST', url, 100000,
    'application/json');

  _ObjetoResposta := SO(Utf8ToAnsi(_StringStream.DataString));
  _StringStream.Free;

  textoResposta.Text := '';
  textoResposta.Text := (_ObjetoResposta.AsJSon(True));

end;

procedure TForm1.btnConsultarPagamentoClick(Sender: TObject);
var
  json, envio, url: string;
  _ObjetoResposta, _ObjetoEnvio, _ObjetoSucesso: ISuperObject;
  _StringStream: TStringStream;
  I: integer;
begin
  if ambienteHomologacao.Checked = True then
    url := 'https://staging.pagamentobancario.com.br/api/v1/remittance'
  else if ambienteProducao.Checked = True then
    url := 'https://api.pagamentobancario.com.br/api/v1/remittance';

  textoEntrada.Text := '';

  _StringStream := HttpRequest(NullAsStringValue, 'GET',
    url + textoEntrada.Text, 10000, 'application/json');

  _ObjetoResposta := SO(Utf8ToAnsi(_StringStream.DataString));
  _StringStream.Free;

  textoResposta.Text := '';
  textoResposta.Lines.Add(_ObjetoResposta.AsJSon(True));

end;

procedure TForm1.solicitaRemessaClick(Sender: TObject);
var
  json, envio, url: string;
  _ObjetoResposta, _ObjetoEnvio, _ObjetoSucesso, _ObjetoEnvioArray,
    jsonResposta: ISuperObject;
  _StringStream: TStringStream;
  I: integer;
begin
  if ambienteHomologacao.Checked = True then
    url := 'https://staging.pagamentobancario.com.br/api/v1/remittance/' +
      textoEntrada.Text
  else if ambienteProducao.Checked = True then
    url := 'https://api.pagamentobancario.com.br/api/v1/remittance/' +
      textoEntrada.Text;

  _StringStream := HttpRequest(textoEntrada.Text, 'POST', url, 10000,
    'application/json');

  _ObjetoResposta := SO(Utf8ToAnsi(_StringStream.DataString));
  _StringStream.Free;

  textoResposta.Text := '';
  textoResposta.Text := (_ObjetoResposta.AsJSon(True));
end;

procedure TForm1.btnUploadRetornoClick(Sender: TObject);
var
  _StringStream: TStringStream;
  teste, teste2: TStringList;
  Retorno, json, url: string;
  _Objeto: ISuperObject;
  IdHTTP1: TIdHTTP;
  formData: TIdMultiPartFormDataStream;

begin
  if textoEntrada.Text = '' then
    ShowMessage('Por favor leia um arquivo de retorno')
  else
  begin
    if ambienteHomologacao.Checked = True then
      url := 'https://staging.pagamentobancario.com.br/api/v1/reconciliation'
    else if ambienteProducao.Checked = True then
      url := 'https://api.pagamentobancario.com.br/api/v1/reconciliation';

    IdHTTP1 := TIdHTTP.Create(nil);
    formData := TIdMultiPartFormDataStream.Create;
    try
      formData.AddFile('file', textoEntrada.Text);
      IdHTTP1.Request.ContentType := 'multipart/form-data';
      Retorno := IdHTTP1.Post(url, formData);
      textoResposta.Text := Retorno;
    finally
      formData.Free;
      IdHTTP1.Free;
    end;

  end;
end;

procedure TForm1.Button10Click(Sender: TObject);
begin
  textoEntrada.Lines.Clear;

  if boxTipoPagamento.ItemIndex = 0 then
  begin
    textoEntrada.Lines.Add('{');
    textoEntrada.Lines.Add('"accountHash": "8MsOxGFsZh",');
    textoEntrada.Lines.Add
      ('"description": "Pagamento de Boletos e Bloquetos",');
    textoEntrada.Lines.Add('"paymentForm": "30",');
    textoEntrada.Lines.Add('"nominalAmount": "1.5",');
    textoEntrada.Lines.Add('"paymentDate": "019-09-20",');
    textoEntrada.Lines.Add('"amount": "1.5",');
    textoEntrada.Lines.Add
      ('"barcode": "34193808200000001011090000366261234123451000",');
    textoEntrada.Lines.Add('"beneficiary": {');
    textoEntrada.Lines.Add('  "name": "BENEFICIARIO TESTE",');
    textoEntrada.Lines.Add('  "cpfCnpj": "13201437000135"');
    textoEntrada.Lines.Add('},');
    textoEntrada.Lines.Add('"dueDate": "2019-09-20",');
    textoEntrada.Lines.Add('"tag": ["Rua teste, 987"]');
    textoEntrada.Lines.Add('}');
  end
  else if boxTipoPagamento.ItemIndex = 1 then
  begin
    textoEntrada.Lines.Add('{');
    textoEntrada.Lines.Add('"accountHash": "b8aKHR6tXS",');
    textoEntrada.Lines.Add('"paymentDate": "2019-11-12",');
    textoEntrada.Lines.Add('"dueDate": "2019-11-13",');
    textoEntrada.Lines.Add('"amount": 1.5,');
    textoEntrada.Lines.Add('"interestAmount": 0,');
    textoEntrada.Lines.Add('"discountAmount": 0,');
    textoEntrada.Lines.Add('"fineAmount": "0",');
    textoEntrada.Lines.Add('"paymentForm": 3,');
    textoEntrada.Lines.Add('"compensation": 2,');
    textoEntrada.Lines.Add('"beneficiary": {');
    textoEntrada.Lines.Add('  "name": "Teste Beneficiario",');
    textoEntrada.Lines.Add('  "cpfCnpj": "38947633000184",');
    textoEntrada.Lines.Add('  "bankCode": "001",');
    textoEntrada.Lines.Add('  "agency": "1111",');
    textoEntrada.Lines.Add('  "agencyDigit": "2",');
    textoEntrada.Lines.Add('  "accountNumber": "3333",');
    textoEntrada.Lines.Add('  "accountNumberDigit": "3",');
    textoEntrada.Lines.Add('  "street": "Rua Teste",');
    textoEntrada.Lines.Add('  "neighborhood": "Bairro Teste",');
    textoEntrada.Lines.Add('  "addressNumber": "123",');
    textoEntrada.Lines.Add('  "addressComplement": "",');
    textoEntrada.Lines.Add('  "city": "Maringa",');
    textoEntrada.Lines.Add('  "state": "PR",');
    textoEntrada.Lines.Add('  "zipcode": "87000000",');
    textoEntrada.Lines.Add('  "accountType": "1",');
    textoEntrada.Lines.Add('  "transferOptions": "01"');
    textoEntrada.Lines.Add('},');
    textoEntrada.Lines.Add('"tags": [');
    textoEntrada.Lines.Add('  "string"');
    textoEntrada.Lines.Add(']');
    textoEntrada.Lines.Add('}');
  end
  else if boxTipoPagamento.ItemIndex = 2 then
  begin
    textoEntrada.Lines.Add('{');
    textoEntrada.Lines.Add('"accountHash": "b8aKHR6tXS",');
    textoEntrada.Lines.Add('"paymentDate": "2019-11-12T00:00:00.000Z",');
    textoEntrada.Lines.Add('"amount": 1.5,');
    textoEntrada.Lines.Add('"interestAmount": 0,');
    textoEntrada.Lines.Add('"discountAmount": 0,');
    textoEntrada.Lines.Add('"fineAmount": "0",');
    textoEntrada.Lines.Add('"beneficiary": {');
    textoEntrada.Lines.Add('  "name": "Teste Beneficiario",');
    textoEntrada.Lines.Add('  "cpfCnpj": "38947633000184",');
    textoEntrada.Lines.Add('  "bankCode": "001",');
    textoEntrada.Lines.Add('  "agency": "1111",');
    textoEntrada.Lines.Add('  "agencyDigit": "2",');
    textoEntrada.Lines.Add('  "accountNumber": "3333",');
    textoEntrada.Lines.Add('  "accountNumberDigit": "3",');
    textoEntrada.Lines.Add('  "neighborhood": "Rua Teste",');
    textoEntrada.Lines.Add('  "addressNumber": "123",');
    textoEntrada.Lines.Add('  "addressComplement": "",');
    textoEntrada.Lines.Add('  "city": "Maringa",');
    textoEntrada.Lines.Add('  "state": "PR",');
    textoEntrada.Lines.Add('  "zipcode": "87000000",');
    textoEntrada.Lines.Add('  "accountType": "1",');
    textoEntrada.Lines.Add('  "transferOptions": "01"');
    textoEntrada.Lines.Add('},');
    textoEntrada.Lines.Add('"tags": [');
    textoEntrada.Lines.Add('  "string"');
    textoEntrada.Lines.Add(']');
    textoEntrada.Lines.Add('}');
  end
  else if boxTipoPagamento.ItemIndex = 3 then
  begin
    textoEntrada.Lines.Add('{');
    textoEntrada.Lines.Add('"accountHash": "b8aKHR6tXS",');
    textoEntrada.Lines.Add('"revenueCode": "1234",');
    textoEntrada.Lines.Add('"paymentDate": "2019-12-20",');
    textoEntrada.Lines.Add('"amount": 1.5,');
    textoEntrada.Lines.Add('"description": "Pagamento da GARE Teste",');
    textoEntrada.Lines.Add('"contributorDocument": "93848368005",');
    textoEntrada.Lines.Add('"dueDate": "2019-12-20",');
    textoEntrada.Lines.Add('"stateRegistration": "PR",');
    textoEntrada.Lines.Add('"activeDebit": "123",');
    textoEntrada.Lines.Add('"referencePeriod": "2019-12",');
    textoEntrada.Lines.Add('"installment": "01",');
    textoEntrada.Lines.Add('"interestAmount": 0,');
    textoEntrada.Lines.Add('"fineAmount": 0,');
    textoEntrada.Lines.Add('"nominalAmount": 1.5,');
    textoEntrada.Lines.Add('"increaseAmount": 2.5,');
    textoEntrada.Lines.Add('"honoraryAmount": 6.5,');
    textoEntrada.Lines.Add('"tags": [');
    textoEntrada.Lines.Add('  "teste"');
    textoEntrada.Lines.Add(']');
    textoEntrada.Lines.Add('}');
  end
  else if boxTipoPagamento.ItemIndex = 4 then
  begin
    textoEntrada.Lines.Add('{');
    textoEntrada.Lines.Add('"accountHash": "b8aKHR6tXS",');
    textoEntrada.Lines.Add('"revenueCode": "1234",');
    textoEntrada.Lines.Add('"paymentDate": "2019-12-20",');
    textoEntrada.Lines.Add('"contributorDocument": "93848368005",');
    textoEntrada.Lines.Add('"description": "Teste de IPVA",');
    textoEntrada.Lines.Add('"nominalAmount": 1.5,');
    textoEntrada.Lines.Add('"contributorName": "João Teste",');
    textoEntrada.Lines.Add('"calculationYear": "2019",');
    textoEntrada.Lines.Add('"amount": "1.50",');
    textoEntrada.Lines.Add('"dueDate": "2019-12-20",');
    textoEntrada.Lines.Add('"municipalCode": "4115200",');
    textoEntrada.Lines.Add('"discountAmount": 0,');
    textoEntrada.Lines.Add('"state": "PR",');
    textoEntrada.Lines.Add('"vehiclePlates": "AAA0000",');
    textoEntrada.Lines.Add('"paymentOption": 1,');
    textoEntrada.Lines.Add('"vehicleRenavam": "aaaaaaaaaa",');
    textoEntrada.Lines.Add('"CRVLWithdrawalOption": 1,');
    textoEntrada.Lines.Add('"tags": [');
    textoEntrada.Lines.Add('  "teste"');
    textoEntrada.Lines.Add(']');
    textoEntrada.Lines.Add('}');
  end
  else if boxTipoPagamento.ItemIndex = 5 then
  begin
    textoEntrada.Lines.Add('{');
    textoEntrada.Lines.Add('"accountHash": "b8aKHR6tXS",');
    textoEntrada.Lines.Add('"paymentDate": "2019-12-20",');
    textoEntrada.Lines.Add('"contributorDocument": "93848368005",');
    textoEntrada.Lines.Add('"description": "Teste de DPVAT",');
    textoEntrada.Lines.Add('"nominalAmount": 1.5,');
    textoEntrada.Lines.Add('"contributorName": "João Teste",');
    textoEntrada.Lines.Add('"calculationYear": "2019",');
    textoEntrada.Lines.Add('"amount": "1.50",');
    textoEntrada.Lines.Add('"dueDate": "2019-12-20",');
    textoEntrada.Lines.Add('"municipalCode": "4115200",');
    textoEntrada.Lines.Add('"discountAmount": 0,');
    textoEntrada.Lines.Add('"state": "PR",');
    textoEntrada.Lines.Add('"vehiclePlates": "AAA0000",');
    textoEntrada.Lines.Add('"paymentOption": 1,');
    textoEntrada.Lines.Add('"vehicleRenavam": "aaaaaaaaaa",');
    textoEntrada.Lines.Add('"CRVLWithdrawalOption": 1,');
    textoEntrada.Lines.Add('"tags": [');
    textoEntrada.Lines.Add('  "teste"');
    textoEntrada.Lines.Add(']');
    textoEntrada.Lines.Add('}');
  end
  else if boxTipoPagamento.ItemIndex = 6 then
  begin
    textoEntrada.Lines.Add('{');
    textoEntrada.Lines.Add('"accountHash": "b8aKHR6tXS",');
    textoEntrada.Lines.Add('"revenueCode": "1234",');
    textoEntrada.Lines.Add('"referencePeriod": "2019-12-01",');
    textoEntrada.Lines.Add('"reportingPeriod": "2019-12-20",');
    textoEntrada.Lines.Add('"paymentDate": "2019-12-20",');
    textoEntrada.Lines.Add('"dueDate": "2019-12-20",');
    textoEntrada.Lines.Add('"description": "Pagamento da DARF Teste",');
    textoEntrada.Lines.Add('"contributorDocument": "93848368005",');
    textoEntrada.Lines.Add('"contributorName": "Teste homologacao",');
    textoEntrada.Lines.Add('"referenceNumber": "123",');
    textoEntrada.Lines.Add('"interestAmount": 1,');
    textoEntrada.Lines.Add('"fineAmount": 0,');
    textoEntrada.Lines.Add('"nominalAmount": 0,');
    textoEntrada.Lines.Add('"movimentCode": "09",');
    textoEntrada.Lines.Add('"tags": [');
    textoEntrada.Lines.Add('  "teste"');
    textoEntrada.Lines.Add(']');
    textoEntrada.Lines.Add('}');
  end
  else if boxTipoPagamento.ItemIndex = 7 then
  begin
    textoEntrada.Lines.Add('{');
    textoEntrada.Lines.Add('"accountHash": "b8aKHR6tXS",');
    textoEntrada.Lines.Add('"revenueCode": "1234",');
    textoEntrada.Lines.Add('"paymentForm": "17",');
    textoEntrada.Lines.Add('"contributorDocument": "93848368005",');
    textoEntrada.Lines.Add('"paymentDate": "2019-12-20",');
    textoEntrada.Lines.Add('"amount": 1.5,');
    textoEntrada.Lines.Add('"nominalAmount": "1.50",');
    textoEntrada.Lines.Add('"description": "Teste GPS",');
    textoEntrada.Lines.Add('"referencePeriod": "122019",');
    textoEntrada.Lines.Add('"taxAmount": "0",');
    textoEntrada.Lines.Add('"otherAmount": 0,');
    textoEntrada.Lines.Add('"monetaryAdjustment": 0,');
    textoEntrada.Lines.Add('"tags": [');
    textoEntrada.Lines.Add('  "string"');
    textoEntrada.Lines.Add(']');
    textoEntrada.Lines.Add('}');
  end
  else if boxTipoPagamento.ItemIndex = 8 then
  begin
    textoEntrada.Lines.Add('{');
    textoEntrada.Lines.Add('"accountHash": "string",');
    textoEntrada.Lines.Add('"paymentForm": "35",');
    textoEntrada.Lines.Add('"description": "string",');
    textoEntrada.Lines.Add('"barcode": "string",');
    textoEntrada.Lines.Add('"paymentDate": "2019-08-24",');
    textoEntrada.Lines.Add('"dueDate": "2019-08-24",');
    textoEntrada.Lines.Add('"amount": 999999999999.99,');
    textoEntrada.Lines.Add('"contributorDocument": "string",');
    textoEntrada.Lines.Add('"contributorName": "string",');
    textoEntrada.Lines.Add('"revenueCode": "string",');
    textoEntrada.Lines.Add('"fgtsIdentifier": "string",');
    textoEntrada.Lines.Add('"sealSocialConnectivity": 999999999,');
    textoEntrada.Lines.Add('"sealSocialConnectivityDigit": 99,');
    textoEntrada.Lines.Add('"tags": [');
    textoEntrada.Lines.Add('  "string"');
    textoEntrada.Lines.Add(']');
    textoEntrada.Lines.Add('}');
  end
  else if boxTipoPagamento.ItemIndex = 9 then
  begin
    textoEntrada.Lines.Add('{');
    textoEntrada.Lines.Add('"accountHash": "b8aKHR6tXS",');
    textoEntrada.Lines.Add('"paymentDate": "2019-11-12T00:00:00.000Z",');
    textoEntrada.Lines.Add('"paymentForm": "1",');
    textoEntrada.Lines.Add('"amount": 1.5,');
    textoEntrada.Lines.Add('"interestAmount": 0,');
    textoEntrada.Lines.Add('"discountAmount": 0,');
    textoEntrada.Lines.Add('"fineAmount": "0",');
    textoEntrada.Lines.Add('"beneficiary": {');
    textoEntrada.Lines.Add('  "name": "Teste Beneficiario",');
    textoEntrada.Lines.Add('  "cpfCnpj": "38947633000184",');
    textoEntrada.Lines.Add('  "bankCode": "001",');
    textoEntrada.Lines.Add('  "agency": "1111",');
    textoEntrada.Lines.Add('  "agencyDigit": "2",');
    textoEntrada.Lines.Add('  "accountNumber": "3333",');
    textoEntrada.Lines.Add('  "accountNumberDigit": "3",');
    textoEntrada.Lines.Add('  "neighborhood": "Rua Teste",');
    textoEntrada.Lines.Add('  "addressNumber": "123",');
    textoEntrada.Lines.Add('  "addressComplement": "",');
    textoEntrada.Lines.Add('  "city": "Maringa",');
    textoEntrada.Lines.Add('  "state": "PR",');
    textoEntrada.Lines.Add('  "zipcode": "87000000"');
    textoEntrada.Lines.Add('},');
    textoEntrada.Lines.Add('"tags": [');
    textoEntrada.Lines.Add('  "string"');
    textoEntrada.Lines.Add(']');
    textoEntrada.Lines.Add('}');
  end;
end;

procedure TForm1.Button11Click(Sender: TObject);
begin
  textoEntrada.Lines.Clear;
  textoEntrada.Lines.Add('Insira aqui seu IDintegração');
end;

procedure TForm1.Button12Click(Sender: TObject);
begin
  textoEntrada.Lines.Clear;
  textoEntrada.Lines.Add
    ('Insira aqui seu IDintegração aqui para gerar sua remessa');
end;

procedure TForm1.Button13Click(Sender: TObject);
var
  _ss: TStringStream;
begin
  if OpenDialogRetorno.Execute then
  begin
    textoEntrada.Lines.Clear;
    textoEntrada.Lines.Text := OpenDialogRetorno.FileName;
  end;
end;

procedure TForm1.Button14Click(Sender: TObject);
begin
  textoEntrada.Lines.Clear;
  textoEntrada.Lines.Add('Insira aqui seu protocolo');
end;

procedure TForm1.Button15Click(Sender: TObject);
var
  _ss: TStringStream;
begin
  if OpenDialogRetorno.Execute then
  begin
    textoEntrada.Lines.Clear;
    textoEntrada.Lines.Text := OpenDialogRetorno.FileName;
  end;
end;

procedure TForm1.Button16Click(Sender: TObject);
begin
  textoEntrada.Lines.Clear;
  textoEntrada.Lines.Add('{Insira o protocolo');
end;

procedure TForm1.Button18Click(Sender: TObject);
begin
  textoEntrada.Lines.Clear;
  textoEntrada.Lines.Add('{Insira o protocolo');
end;

procedure TForm1.Button1Click(Sender: TObject);
begin
  textoEntrada.Lines.Clear;
  textoEntrada.Lines.Add('{');
  textoEntrada.Lines.Add('  "name": "CNPJ PARA TESTES",');
  textoEntrada.Lines.Add('  "cpfCnpj": "01001001000113",');
  textoEntrada.Lines.Add('  "neighborhood": "DUQUE DE CAXIAS",');
  textoEntrada.Lines.Add('  "addressNumber": "882",');
  textoEntrada.Lines.Add('  "zipcode": "87020025",');
  textoEntrada.Lines.Add('  "state": "PR",');
  textoEntrada.Lines.Add('  "city": "MARINGA"');
  textoEntrada.Lines.Add('}');
end;

procedure TForm1.Button2Click(Sender: TObject);
begin
  textoEntrada.Lines.Clear;
  textoEntrada.Lines.Add('{');
  textoEntrada.Lines.Add('  "name": "CNPJ PARA TESTES",');
  textoEntrada.Lines.Add('  "cpfCnpj": "01001001000113",');
  textoEntrada.Lines.Add('  "neighborhood": "DUQUE DE CAXIAS",');
  textoEntrada.Lines.Add('  "addressNumber": "882",');
  textoEntrada.Lines.Add('  "zipcode": "87020025",');
  textoEntrada.Lines.Add('  "state": "PR",');
  textoEntrada.Lines.Add('  "city": "MARINGA"');
  textoEntrada.Lines.Add('}');
end;

procedure TForm1.Button3Click(Sender: TObject);
begin
  textoEntrada.Lines.Clear;
  textoEntrada.Lines.Add('{');
  textoEntrada.Lines.Add('"bankCode": "001",');
  textoEntrada.Lines.Add('"agency": "1111",');
  textoEntrada.Lines.Add('"agencyDigit": "1",');
  textoEntrada.Lines.Add('"accountNumber": "0001",');
  textoEntrada.Lines.Add('"accountNumberDigit": "1",');
  textoEntrada.Lines.Add('"accountDac": "1",');
  textoEntrada.Lines.Add('"convenioAgency": "",');
  textoEntrada.Lines.Add('"convenioNumber": "22",');
  textoEntrada.Lines.Add('"remessaSequential": "0"');
  textoEntrada.Lines.Add('}');
end;

procedure TForm1.Button4Click(Sender: TObject);
begin
  textoEntrada.Lines.Clear;
  textoEntrada.Lines.Add('{');
  textoEntrada.Lines.Add('"bankCode": "001",');
  textoEntrada.Lines.Add('"agency": "1111",');
  textoEntrada.Lines.Add('"agencyDigit": "1",');
  textoEntrada.Lines.Add('"accountNumber": "0001",');
  textoEntrada.Lines.Add('"accountNumberDigit": "1",');
  textoEntrada.Lines.Add('"accountDac": "1",');
  textoEntrada.Lines.Add('"convenioAgency": "",');
  textoEntrada.Lines.Add('"convenioNumber": "22",');
  textoEntrada.Lines.Add('"remessaSequential": "0"');
  textoEntrada.Lines.Add('}');
end;

procedure TForm1.Button5Click(Sender: TObject);
begin
  textoEntrada.Lines.Clear;
  textoEntrada.Lines.Add('Inclua o ID da conta aqui');
end;

procedure TForm1.btnConsultarRetornoClick(Sender: TObject);
var
  json, envio, url: string;
  _ObjetoResposta, _ObjetoEnvio, _ObjetoSucesso: ISuperObject;
  _StringStream: TStringStream;
  I: integer;
begin
  if ambienteHomologacao.Checked = True then
    url := 'https://staging.pagamentobancario.com.br/api/v1/reconciliation/'
  else if ambienteProducao.Checked = True then
    url := 'https://api.pagamentobancario.com.br/api/v1/reconciliation/';

  _StringStream := HttpRequest(NullAsStringValue, 'GET',
    url + boxProtocoloRetorno.Text, 10000, 'application/json');

  _ObjetoResposta := SO(Utf8ToAnsi(_StringStream.DataString));

  _ObjetoResposta.AsJSon(True);
  envio := _ObjetoResposta.AsString;
  textoEntrada.Text := SO(Utf8ToAnsi(envio)).AsString;

end;

procedure TForm1.btnIncluirExtratoClick(Sender: TObject);
var
  _StringStream: TStringStream;
  teste, teste2: TStringList;
  Retorno, json, url: string;
  _Objeto: ISuperObject;
  IdHTTP1: TIdHTTP;
  formData: TIdMultiPartFormDataStream;

begin
  if textoEntrada.Text = '' then
    ShowMessage('Por favor leia um arquivo de retorno')
  else
  begin
    if ambienteHomologacao.Checked = True then
      url := 'https://staging.pagamentobancario.com.br/api/v1/statement/parser'
    else if ambienteProducao.Checked = True then
      url := 'https://api.pagamentobancario.com.br/api/v1/statement/parser';

    IdHTTP1 := TIdHTTP.Create(nil);
    formData := TIdMultiPartFormDataStream.Create;
    try
      formData.AddFile('file', textoEntrada.Text);
      IdHTTP1.Request.ContentType := 'multipart/form-data';
      Retorno := IdHTTP1.Post(url, formData);
      textoResposta.Text := Retorno;
    finally
      formData.Free;
      IdHTTP1.Free;
    end;

  end;
end;

end.
