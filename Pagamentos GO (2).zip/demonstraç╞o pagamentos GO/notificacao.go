package main

import (
	"bytes"
	"encoding/json"
	"fmt"
	"io"
	"io/ioutil"
	"log"
	"net/http"
)

func criaNotificacao(url, cnpjsh, tokensh, payercpfcnpj string, notification Notification) {
	client := &http.Client{}

	payloadBytes, err := json.Marshal(notification)
	if err != nil {
		log.Fatalf("Erro ao serializar o payload: %v", err)
	}
	req, err := http.NewRequest("POST", url, bytes.NewBuffer(payloadBytes))
	if err != nil {
		log.Fatalf("Erro ao criar a requisição POST: %v", err)
	}
	req.Header.Add("cnpjsh", cnpjsh)
	req.Header.Add("payercpfcnpj", payercpfcnpj)
	req.Header.Add("tokensh", tokensh)
	req.Header.Add("Content-Type", "application/json")

	resp, err := client.Do(req)
	if err != nil {
		log.Fatalf("Erro ao fazer a requisição POST: %v", err)
	}
	defer resp.Body.Close()

	body, err := ioutil.ReadAll(resp.Body)
	if err != nil {
		log.Fatalf("Erro ao ler a resposta da requisição POST: %v", err)
	}

	fmt.Println("Resposta: ", string(body))
}

func listaNotificacoes(url, cnpjsh, tokensh, payercpfcnpj string) {
	client := &http.Client{}

	req, err := http.NewRequest("GET", url+"/notification", nil)
	if err != nil {
		log.Fatalf("Erro ao criar a requisição GET: %v", err)
	}

	req.Header.Add("Content-Type", "application/json")
	req.Header.Add("cnpjSh", cnpjsh)
	req.Header.Add("payercpfcnpj", payercpfcnpj)
	req.Header.Add("tokenSh", tokensh)

	resp, err := client.Do(req)
	if err != nil {
		log.Fatalf("Erro ao realizar a requisição GET: %v", err)
	}
	defer resp.Body.Close()

	body, err := io.ReadAll(resp.Body)
	if err != nil {
		log.Fatalf("Erro ao ler a resposta da requisição GET: %v", err)
	}

	fmt.Println("Resposta GET: ", string(body))
}

func apagaNotificacoes(url, cnpjsh, tokensh, payercpfcnpj string, uniqueIds []string) {
	client := &http.Client{}

	data := map[string][]string{
		"uniqueId": uniqueIds,
	}

	jsonData, err := json.Marshal(data)
	if err != nil {
		log.Fatalf("Erro ao converter os dados para JSON: %v", err)
	}

	req, err := http.NewRequest("DELETE", url+"/notification", bytes.NewBuffer(jsonData))
	if err != nil {
		log.Fatalf("Erro ao criar a requisição DELETE: %v", err)
	}

	req.Header.Add("Content-Type", "application/json")
	req.Header.Add("cnpjSh", cnpjsh)
	req.Header.Add("payercpfcnpj", payercpfcnpj)
	req.Header.Add("tokenSh", tokensh)

	resp, err := client.Do(req)
	if err != nil {
		log.Fatalf("Erro ao realizar a requisição DELETE: %v", err)
	}
	defer resp.Body.Close()

	body, err := io.ReadAll(resp.Body)
	if err != nil {
		log.Fatalf("Erro ao ler a resposta da requisição DELETE: %v", err)
	}

	fmt.Println("Resposta DELETE: ", string(body))
}

func atualizaNotificacoes(url, cnpjsh, payercpfcnpj, tokensh string, atualizaNotification AtualizaNotification) {
	client := &http.Client{}
	notificationData, err := json.Marshal(atualizaNotification)
	if err != nil {
		log.Fatalf("Erro ao converter os dados do pagador para JSON: %v", err)
	}

	req, err := http.NewRequest("PUT", url, bytes.NewBuffer(notificationData))
	if err != nil {
		log.Fatalf("Erro ao criar a requisição PUT: %v", err)
	}

	req.Header.Add("Content-Type", "application/json")
	req.Header.Add("cnpjsh", cnpjsh)
	req.Header.Add("tokensh", tokensh)
	req.Header.Add("payercpfcnpj", payercpfcnpj)

	resp, err := client.Do(req)
	if err != nil {
		log.Fatalf("Erro ao realizar a requisição PUT: %v", err)
	}
	defer resp.Body.Close()

	body, err := ioutil.ReadAll(resp.Body)
	if err != nil {
		log.Fatalf("Erro ao ler a resposta da requisição PUT: %v", err)
	}

	fmt.Println("Resposta PUT:", string(body))
}

func rotaNoticacao(urlNotificacao string) {
	var rota int
	fmt.Printf(
		"\n" +
			"1. Criar Notificação\n" +
			"2. Listar Notificações\n" +
			"3. Apagar Notificação\n" +
			"4. Atualizar Notificações\n" +
			"5. SAIR\n" +
			"----------------------------------\n\n",
	)

	fmt.Print("Digite o número correspondente à rota que deseja utilizar: ")
	fmt.Scanln(&rota)

	switch rota {
	case 1:
		var cnpjsh, tokensh, payerCpfCnpj string
		var notification Notification

		fmt.Print("CNPJ da Software House: ")
		fmt.Scanln(&cnpjsh)
		fmt.Print("Token da Software House: ")
		fmt.Scanln(&tokensh)
		fmt.Print("CNPJ do pagador: ")
		fmt.Scanln(&payerCpfCnpj)

		fmt.Print("Tipo de Notificação (Obrigatório - WebHook): ")
		fmt.Scanln(&notification.Type)
		fmt.Print("E-mail: ")
		fmt.Scanln(&notification.Email)
		fmt.Print("Cópia Oculta: ")
		fmt.Scanln(&notification.CC)
		fmt.Print("Digite o cabeçalho da Notificação: ")
		fmt.Scanln(&notification.Headers)
		fmt.Print("URL do WebHook: ")
		fmt.Scanln(&notification.URL)
		fmt.Print("Telefone da SH: ")
		fmt.Scanln(&notification.Mobile)
		fmt.Print("Digite os eventos separados por vírgula: ")
		fmt.Scanln(&notification.Happen)

		url := urlNotificacao

		criaNotificacao(url, cnpjsh, tokensh, payerCpfCnpj, notification)

	case 2:
		var cnpjsh, tokensh, payercpfcnpj string
		fmt.Print("CNPJ da Software House: ")
		fmt.Scanln(&cnpjsh)
		fmt.Print("CNPJ ou CPF do Pagador: ")
		fmt.Scanln(&payercpfcnpj)
		fmt.Print("Token da Software House: ")
		fmt.Scanln(&tokensh)

		url := urlNotificacao
		listaNotificacoes(url, cnpjsh, tokensh, payercpfcnpj)
	case 3:
		var cnpjsh, tokensh, payercpfcnpj string
		fmt.Print("CNPJ da Software House: ")
		fmt.Scanln(&cnpjsh)
		fmt.Print("CNPJ ou CPF do Pagador: ")
		fmt.Scanln(&payercpfcnpj)
		fmt.Print("Token da Software House: ")
		fmt.Scanln(&tokensh)
		fmt.Print("uniqueIds: ")
		var uniqueIds []string
		fmt.Scanln(&uniqueIds)

		url := urlNotificacao
		deletarConta(url, cnpjsh, tokensh, payercpfcnpj, uniqueIds)
	case 4:
		var cnpjsh, tokensh, payerCpfCnpj string
		var atualizaNotification AtualizaNotification

		fmt.Print("CNPJ da Software House: ")
		fmt.Scanln(&cnpjsh)
		fmt.Print("Token da Software House: ")
		fmt.Scanln(&tokensh)
		fmt.Print("CNPJ do pagador: ")
		fmt.Scanln(&payerCpfCnpj)

		fmt.Print("UniqueId da Notificação  (Obrigatório): ")
		fmt.Scanln(atualizaNotification.UniqueId)
		fmt.Print("Tipo de Notificação: ")
		fmt.Scanln(&atualizaNotification.Type)
		fmt.Print("E-mail: ")
		fmt.Scanln(&atualizaNotification.Email)
		fmt.Print("Cópia Oculta: ")
		fmt.Scanln(&atualizaNotification.CC)
		fmt.Print("Digite o cabeçalho da Notificação: ")
		fmt.Scanln(&atualizaNotification.Headers)
		fmt.Print("URL do WebHook: ")
		fmt.Scanln(&atualizaNotification.URL)
		fmt.Print("Telefone da SH: ")
		fmt.Scanln(&atualizaNotification.Mobile)
		fmt.Print("Digite os eventos separados por vírgula: ")
		fmt.Scanln(&atualizaNotification.Happen)

		url := urlNotificacao
		atualizaNotificacoes(url, cnpjsh, payerCpfCnpj, tokensh, atualizaNotification)
	case 5:
		selecionaAmbiente()
	default:
		fmt.Print("SEÇÃO INVÁLIDA")
		rotaNoticacao(urlNotificacao)
	}
}
