package main

import (
	"bufio"
	"bytes"
	"encoding/json"
	"fmt"
	"io/ioutil"
	"log"
	"net/http"
	"os"
	"strings"
)

func geraRemessa(url, cnpjsh, tokensh, payercpfcnpj string, payments []string) {
	client := &http.Client{}

	requestBody, err := json.Marshal(map[string]interface{}{
		"payments": payments,
	})
	if err != nil {
		log.Fatalf("Erro ao criar o corpo da requisição: %v", err)
	}

	req, err := http.NewRequest("POST", url, bytes.NewBuffer(requestBody))
	if err != nil {
		log.Fatalf("Erro ao criar a requisição POST: %v", err)
	}

	req.Header.Add("Content-Type", "application/json")
	req.Header.Add("cnpjsh", cnpjsh)
	req.Header.Add("payercpfcnpj", payercpfcnpj)
	req.Header.Add("tokensh", tokensh)

	resp, err := client.Do(req)
	if err != nil {
		log.Fatalf("Erro ao realizar a requisição POST: %v", err)
	}
	defer resp.Body.Close()

	body, err := ioutil.ReadAll(resp.Body)
	if err != nil {
		log.Fatalf("Erro ao ler a resposta da requisição: %v", err)
	}

	fmt.Println("Resposta POST: ", string(body))
}

func consultaRemessaPorPeriodo(url, cnpjsh, tokensh, payercpfcnpj string) {
	client := &http.Client{}

	req, err := http.NewRequest("GET", url, nil)
	if err != nil {
		log.Fatalf("Erro ao criar a requisição GET: %v", err)
	}

	req.Header.Add("cnpjsh", cnpjsh)
	req.Header.Add("payercpfcnpj", payercpfcnpj)
	req.Header.Add("tokensh", tokensh)

	resp, err := client.Do(req)
	if err != nil {
		log.Fatalf("Erro ao realizar a requisição GET: %v", err)
	}
	defer resp.Body.Close()

	body, err := ioutil.ReadAll(resp.Body)
	if err != nil {
		log.Fatalf("Erro ao ler a resposta da requisição: %v", err)
	}

	fmt.Println("Resposta GET: ", string(body))
}

func consultaRemessa(url, cnpjsh, tokensh, payercpfcnpj string) {
	client := &http.Client{}

	req, err := http.NewRequest("GET", url, nil)
	if err != nil {
		log.Fatalf("Erro ao criar a requisição GET: %v", err)
	}

	req.Header.Add("cnpjSh", cnpjsh)
	req.Header.Add("payercpfcnpj", payercpfcnpj)
	req.Header.Add("tokenSh", tokensh)

	resp, err := client.Do(req)
	if err != nil {
		log.Fatalf("Erro ao realizar a requisição GET: %v", err)
	}
	defer resp.Body.Close()

	body, err := ioutil.ReadAll(resp.Body)
	if err != nil {
		log.Fatalf("Erro ao ler a resposta da requisição: %v", err)
	}

	fmt.Println("Resposta GET: ", string(body))
}

func baixarRemessa(url, cnpjsh, tokensh, payercpfcnpj string) {
	client := &http.Client{}

	req, err := http.NewRequest("GET", url, nil)
	if err != nil {
		log.Fatalf("Erro ao criar a requisição GET: %v", err)
	}

	req.Header.Add("cnpjSh", cnpjsh)
	req.Header.Add("payercpfcnpj", payercpfcnpj)
	req.Header.Add("tokenSh", tokensh)

	resp, err := client.Do(req)
	if err != nil {
		log.Fatalf("Erro ao realizar a requisição GET: %v", err)
	}
	defer resp.Body.Close()

	body, err := ioutil.ReadAll(resp.Body)
	if err != nil {
		log.Fatalf("Erro ao ler a resposta da requisição: %v", err)
	}

	var remittanceId string
	err = ioutil.WriteFile("remessa_baixada"+remittanceId+".txt", body, 0644)
	if err != nil {
		log.Fatalf("Erro ao salvar o arquivo: %v", err)
	}

	fmt.Println("Remessa baixada e salva como remessa_baixada" + remittanceId + ".txt")
}

func cancelaPaymentAgendado(url, cnpjsh, tokensh, payercpfcnpj, paymentID string) {
	client := &http.Client{}

	data := map[string]interface{}{
		"payments": []string{paymentID},
	}

	jsonData, err := json.Marshal(data)
	if err != nil {
		log.Fatalf("Erro ao converter dados para JSON: %v", err)
	}

	req, err := http.NewRequest("POST", url, bytes.NewBuffer(jsonData))
	if err != nil {
		log.Fatalf("Erro ao criar a requisição POST: %v", err)
	}

	req.Header.Add("Content-Type", "application/json")
	req.Header.Add("cnpjsh", cnpjsh)
	req.Header.Add("payercpfcnpj", payercpfcnpj)
	req.Header.Add("tokensh", tokensh)

	resp, err := client.Do(req)
	if err != nil {
		log.Fatalf("Erro ao realizar a requisição POST: %v", err)
	}

	defer resp.Body.Close()

	body, err := ioutil.ReadAll(resp.Body)
	if err != nil {
		log.Fatalf("Erro ao ler a resposta da requisição POST: %v", err)
	}

	fmt.Println("Resposta POST (Cancelar Pagamentos Agendados): ", string(body))
}

func rotaRemessa(urlRemessa string) {
	var rota int
	fmt.Printf(
		"\n" +
			"1. Enviar Remessa\n" +
			"2. Consultar Remessa por Período\n" +
			"3. Consultar Remessa\n" +
			"4. Baixar Remessa\n" +
			"5. Cancelar Pagamento Agendado\n" +
			"6. SAIR\n" +
			"----------------------------------\n\n",
	)

	fmt.Print("Digite o número correspondente à rota que deseja utilizar: ")
	fmt.Scanln(&rota)

	var cnpjsh, tokensh, payerCpfCnpj string

	fmt.Print("CNPJ da Software House: ")
	fmt.Scanln(&cnpjsh)
	fmt.Print("Token da Software House: ")
	fmt.Scanln(&tokensh)
	fmt.Print("CNPJ do pagador: ")
	fmt.Scanln(&payerCpfCnpj)

	switch rota {
	case 1:
		var payments []string
		reader := bufio.NewReader(os.Stdin)

		for {
			fmt.Print("Código do pagamento (deixe em branco para terminar): ")
			payment, _ := reader.ReadString('\n')
			payment = strings.TrimSpace(payment)
			if payment == "" {
				break
			}
			payments = append(payments, payment)
		}

		url := urlRemessa
		geraRemessa(url, cnpjsh, tokensh, payerCpfCnpj, payments)
	case 2:
		var dateStart, dateEnd string

		fmt.Print("Data Inicial (AAAA-MM-DD): ")
		fmt.Scanln(&dateStart)
		fmt.Print("Data Final (AAAA-MM-DD): ")
		fmt.Scanln(&dateEnd)

		url := urlRemessa + "?dateStart=" + dateStart + "&dateEnd=" + dateEnd
		consultaRemessaPorPeriodo(url, cnpjsh, tokensh, payerCpfCnpj)
	case 3:
		var remittanceId string

		fmt.Print("ID da Remessa: ")
		fmt.Scanln(&remittanceId)

		url := urlRemessa + "/" + remittanceId
		consultaRemessa(url, cnpjsh, tokensh, payerCpfCnpj)
	case 4:
		var remittanceId string

		fmt.Print("ID da Remessa: ")
		fmt.Scanln(&remittanceId)

		url := urlRemessa + "/" + remittanceId + "/download"
		baixarRemessa(url, cnpjsh, tokensh, payerCpfCnpj)
	case 5:
		var paymentID string
		fmt.Print("ID do Pagamento a Cancelar: ")
		fmt.Scanln(&paymentID)
		url := urlRemessa + "/cancel"
		cancelaPaymentAgendado(url, cnpjsh, tokensh, payerCpfCnpj, paymentID)
	case 6:
		selecionaAmbiente()
	default:
		fmt.Print("Rota Inválida.")
		rotaRemessa(urlRemessa)
	}
}
