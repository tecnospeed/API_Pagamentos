package main

import (
	"fmt"
)

type Beneficiary struct {
	Name               string `json:"name,omitempty"`
	CpfCnpj            string `json:"cpfCnpj,omitempty"`
	BankCode           string `json:"bankCode,omitempty"`
	Agency             string `json:"agency,omitempty"`
	AgencyDigit        string `json:"agencyDigit,omitempty"`
	AccountNumber      string `json:"accountNumber,omitempty"`
	AccountNumberDigit string `json:"accountNumberDigit,omitempty"`
	AccountDac         string `json:"accountDac,omitempty"`
	Street             string `json:"street,omitempty"`
	Neighborhood       string `json:"neighborhood,omitempty"`
	AddressNumber      string `json:"addressNumber,omitempty"`
	AddressComplement  string `json:"addressComplement,omitempty"`
	City               string `json:"city,omitempty"`
	State              string `json:"state,omitempty"`
	Zipcode            string `json:"zipcode,omitempty"`
	AccountType        string `json:"accountType,omitempty"`
	TransferOptions    string `json:"transferOptions,omitempty"`
}

type Payment struct {
	AccountHash       string      `json:"accountHash,omitempty"`
	PaymentForm       int         `json:"paymentForm,omitempty"`
	Description       string      `json:"description,omitempty"`
	Barcode           string      `json:"barCode,omitempty"`
	PaymentDate       string      `json:"paymentDate,omitempty"`
	DueDate           string      `json:"dueDate,omitempty"`
	Amount            float64     `json:"amount,omitempty"`
	InterestAmount    float64     `json:"interestAmount,omitempty"`
	DiscountAmount    float64     `json:"discountAmount,omitempty"`
	FineAmount        string      `json:"fineAmount,omitempty"`
	NominalAmount     float64     `json:"nominalAmount,omitempty"`
	FeeAmount         float64     `json:"feeAmount,omitempty"`
	MovimentCode      string      `json:"movimentCode,omitempty"`
	AvalistaName      string      `json:"avalistaName,omitempty"`
	AvalistaCpfCnpj   string      `json:"avalistaCpfCnpj,omitempty"`
	CompromiseType    int         `json:"compromiseType,omitempty"`
	TransmissionParam int         `json:"transmissionParam,omitempty"`
	Compensation      int         `json:"compensation,omitempty"`
	Beneficiary       Beneficiary `json:"beneficiary,omitempty"`
	Tags              []string    `json:"tags,omitempty"`
}

type PaymentBillet struct {
	AccountHash       string      `json:"accountHash,omitempty"`
	PaymentForm       string      `json:"paymentForm,omitempty"`
	Description       string      `json:"description,omitempty"`
	Barcode           string      `json:"barcode,omitempty"`
	DueDate           string      `json:"dueDate,omitempty"`
	PaymentDate       string      `json:"paymentDate,omitempty"`
	NominalAmount     float64     `json:"nominalAmount,omitempty"`
	DiscountAmount    float64     `json:"discountAmount,omitempty"`
	FeeAmount         float64     `json:"feeAmount,omitempty"`
	Amount            float64     `json:"amount,omitempty"`
	MovimentCode      string      `json:"movimentCode,omitempty"`
	AvalistaName      string      `json:"avalistaName,omitempty"`
	AvalistaCpfCnpj   string      `json:"avalistaCpfCnpj,omitempty"`
	CompromiseType    int         `json:"compromiseType,omitempty"`
	TransmissionParam int         `json:"transmissionParam,omitempty"`
	Beneficiary       Beneficiary `json:"beneficiary,omitempty"`
	Tags              []string    `json:"tag,omitempty"`
}

type PaymentTransfer struct {
	AccountHash       string      `json:"accountHash,omitempty"`
	Description       string      `json:"description,omitempty"`
	PaymentForm       string      `json:"paymentForm,omitempty"`
	PaymentDate       string      `json:"paymentDate,omitempty"`
	DueDate           string      `json:"dueDate,omitempty"`
	Amount            float64     `json:"amount,omitempty"`
	NominalAmount     float64     `json:"nominalAmount,omitempty"`
	RebateAmount      float64     `json:"rebateAmount,omitempty"`
	InterestAmount    float64     `json:"interestAmount,omitempty"`
	DiscountAmount    float64     `json:"discountAmount,omitempty"`
	FineAmount        float64     `json:"fineAmount,omitempty"`
	Compensation      int         `json:"compensation,omitempty"`
	MovimentCode      string      `json:"movimentCode,omitempty"`
	ComplementaryCode string      `json:"complementaryCode,omitempty"`
	InstallmentForm   int         `json:"installmentForm,omitempty"`
	PeriodicDueDate   int         `json:"periodicDueDate,omitempty"`
	CompromiseType    int         `json:"compromiseType,omitempty"`
	TransmissionParam int         `json:"transmissionParam,omitempty"`
	Beneficiary       Beneficiary `json:"beneficiary,omitempty"`
	Tags              []string    `json:"tags,omitempty"`
}

type Paycheck struct {
	AccountHash       string      `json:"accountHash,omitempty"`
	Description       string      `json:"description,omitempty"`
	PaymentForm       string      `json:"paymentForm,omitempty"`
	PaymentDate       string      `json:"paymentDate,omitempty"`
	DueDate           string      `json:"dueDate,omitempty"`
	Amount            float64     `json:"amount,omitempty"`
	RebateAmount      float64     `json:"rebateAmount,omitempty"`
	InterestAmount    float64     `json:"interestAmount,omitempty"`
	DiscountAmount    float64     `json:"discountAmount,omitempty"`
	FineAmount        float64     `json:"fineAmount,omitempty"`
	MovimentCode      string      `json:"movimentCode,omitempty"`
	ComplementaryCode string      `json:"complementaryCode,omitempty"`
	CompromiseType    string      `json:"compromiseType,omitempty"`
	TransmissionParam int         `json:"transmissionParam,omitempty"`
	TransferOptions   int         `json:"transferOptions,omitempty"`
	Beneficiary       Beneficiary `json:"beneficiary,omitempty"`
	Tags              []string    `json:"tags,omitempty"`
}

type GARE struct {
	AccountHash         string   `json:"accountHash,omitempty"`
	RevenueCode         string   `json:"revenueCode,omitempty"`
	PaymentDate         string   `json:"paymentDate,omitempty"`
	DueDate             string   `json:"dueDate,omitempty"`
	Amount              float64  `json:"amount,omitempty"`
	Description         string   `json:"description,omitempty"`
	ContributorDocument string   `json:"contributorDocument,omitempty"`
	StateRegistration   string   `json:"stateRegistration,omitempty"`
	ActiveDebite        string   `json:"activeDebite,omitempty"`
	ReferencePeriod     string   `json:"referencePeriod,omitempty"`
	Installment         string   `json:"installment,omitempty"`
	InterestAmount      float64  `json:"interestAmount,omitempty"`
	FineAmount          float64  `json:"fineAmount,omitempty"`
	NominalAmount       float64  `json:"nominalAmount,omitempty"`
	IncreaseAmount      float64  `json:"increaseAmount,omitempty"`
	HonoraryAmount      float64  `json:"honoraryAmount,omitempty"`
	Tags                []string `json:"tags,omitempty"`
}

type IPVA struct {
	AccountHash          string   `json:"accountHash,omitempty"`
	RevenueCode          string   `json:"revenueCode,omitempty"`
	PaymentDate          string   `json:"paymentDate,omitempty"`
	ContributorDocument  string   `json:"contributorDocument,omitempty"`
	Description          string   `json:"description,omitempty"`
	NominalAmount        float64  `json:"nominalAmount,omitempty"`
	ContributorName      string   `json:"contributorName,omitempty"`
	CalculationYear      string   `json:"calculationYear,omitempty"`
	Amount               float64  `json:"amount,omitempty"`
	DueDate              string   `json:"dueDate,omitempty"`
	MunicipalCode        string   `json:"municipalCode,omitempty"`
	DiscountAmount       float64  `json:"discountAmount,omitempty"`
	State                string   `json:"state,omitempty"`
	VehiclePlate         string   `json:"vehiclePlate,omitempty"`
	PaymentOption        int      `json:"paymentOption,omitempty"`
	VehicleRenavam       string   `json:"vehicleRenavam,omitempty"`
	CRVLWithdrawalOption int      `json:"CRVLWithdrawalOption,omitempty"`
	Tags                 []string `json:"tags,omitempty"`
}
type DPVAT struct {
	AccountHash          string   `json:"accountHash,omitempty"`
	RevenueCode          string   `json:"revenueCode,omitempty"`
	PaymentDate          string   `json:"paymentDate,omitempty"`
	Description          string   `json:"description,omitempty"`
	ContributorDocument  string   `json:"contributorDocument,omitempty"`
	NominalAmount        float64  `json:"nominalAmount,omitempty"`
	ContributorName      string   `json:"contributorName,omitempty"`
	CalculationYear      string   `json:"calculationYear,omitempty"`
	Amount               float64  `json:"amount,omitempty"`
	DueDate              string   `json:"dueDate,omitempty"`
	MunicipalCode        string   `json:"municipalCode,omitempty"`
	DiscountAmount       float64  `json:"discountAmount,omitempty"`
	City                 string   `json:"city,omitempty"`
	State                string   `json:"state,omitempty"`
	VehiclePlate         string   `json:"vehiclePlate,omitempty"`
	PaymentOption        int      `json:"paymentOption,omitempty"`
	VehicleRenavam       string   `json:"vehicleRenavam,omitempty"`
	CRVLWithdrawalOption int      `json:"CRVLWithdrawalOption,omitempty"`
	Tags                 []string `json:"tags,omitempty"`
}

type DARF struct {
	AccountHash         string   `json:"accountHash,omitempty"`
	RevenueCode         string   `json:"revenueCode,omitempty"`
	PaymentDate         string   `json:"paymentDate,omitempty"`
	ContributorDocument string   `json:"contributorDocument,omitempty"`
	Description         string   `json:"description,omitempty"`
	ReportingPeriod     string   `json:"reportingPeriod,omitempty"`
	ReferencePeriod     string   `json:"referencePeriod,omitempty"`
	ReferenceNumber     string   `json:"referenceNumber,omitempty"`
	InterestAmount      float64  `json:"interestAmount,omitempty"`
	FineAmount          float64  `json:"fineAmount,omitempty"`
	NominalAmount       float64  `json:"nominalAmount,omitempty"`
	DueDate             string   `json:"dueDate,omitempty"`
	Tags                []string `json:"tags,omitempty"`
	FeeAmount           float64  `json:"feeAmount,omitempty"`
	OtherAmount         float64  `json:"otherAmount,omitempty"`
	ContributorName     string   `json:"contributorName,omitempty"`
	MovimentCode        string   `json:"movimentCode,omitempty"`
}

type GPS struct {
	AccountHash         string   `json:"accountHash,omitempty"`
	PaymentForm         string   `json:"paymentForm,omitempty"`
	RevenueCode         string   `json:"revenueCode,omitempty"`
	ContributorDocument string   `json:"contributorDocument,omitempty"`
	PaymentDate         string   `json:"paymentDate,omitempty"`
	Amount              float64  `json:"amount,omitempty"`
	Description         string   `json:"description,omitempty"`
	ReferencePeriod     string   `json:"referencePeriod,omitempty"`
	TaxAmount           float64  `json:"taxAmount,omitempty"`
	OtherAmount         float64  `json:"otherAmount,omitempty"`
	MonetaryAdjustment  float64  `json:"monetaryAdjustment"`
	Tags                []string `json:"tags,omitempty"`
}

type FGTS struct {
	AccountHash                 string   `json:"accountHash,omitempty"`
	PaymentForm                 string   `json:"paymentForm,omitempty"`
	Description                 string   `json:"description,omitempty"`
	BarCode                     string   `json:"barcode,omitempty"`
	PaymentDate                 string   `json:"paymentDate,omitempty"`
	DueDate                     string   `json:"dueDate,omitempty"`
	Amount                      float64  `json:"amount,omitempty"`
	ContributorDocument         string   `json:"contributorDocument,omitempty"`
	ContributorName             string   `json:"contributorName,omitempty"`
	RevenueCode                 string   `json:"revenueCode,omitempty"`
	FgtsIdentifier              string   `json:"fgtsIdentifier,omitempty"`
	SealSocialConnectivity      int      `json:"sealSocialConnectivity,omitempty"`
	SealSocialConnectivityDigit int      `json:"sealSocialConnectivityDigit,omitempty"`
	Tags                        []string `json:"tags,omitempty"`
}

type Diversos struct {
	AccountHash            string      `json:"accountHash,omitempty"`
	Description            string      `json:"description,omitempty"`
	PaymentForm            string      `json:"paymentForm,omitempty"`
	PaymentDate            string      `json:"paymentDate,omitempty"`
	PaymentType            string      `json:"paymentType,omitempty"`
	DueDate                string      `json:"dueDate,omitempty"`
	Amount                 float64     `json:"amount,omitempty"`
	RebateAmount           float64     `json:"rebateAmount,omitempty"`
	InterestAmount         float64     `json:"interestAmount,omitempty"`
	DiscountAmount         float64     `json:"discountAmount,omitempty"`
	FineAmount             float64     `json:"fineAmount,omitempty"`
	MovimentCode           string      `json:"movimentCode,omitempty"`
	ComplementaryCode      string      `json:"complementaryCode,omitempty"`
	CompromiseType         int         `json:"compromiseType,omitempty"`
	TransmissionParam      int         `json:"transmissionParam,omitempty"`
	PixType                int         `json:"pixType,omitempty"`
	PixKey                 string      `json:"pixKey,omitempty"`
	IspbCode               string      `json:"ispbCode,omitempty"`
	RegistrationComplement int         `json:"registrationComplement,omitempty"`
	PixUrl                 string      `json:"pixUrl,omitempty"`
	PixTxid                string      `json:"pixTxid,omitempty"`
	Beneficiary            Beneficiary `json:"beneficiary,omitempty"`
	Tags                   []string    `json:"tags,omitempty"`
}

type PaymentDeleteRequest struct {
	Payments []string `json:"payments"`
}

type Account struct {
	BankCode           string `json:"bankCode,omitempty"`
	Agency             string `json:"agency,omitempty"`
	AgencyDigit        string `json:"agencyDigit,omitempty"`
	AccountNumber      string `json:"accountNumber,omitempty"`
	AccountNumberDigit string `json:"accountNumberDigit,omitempty"`
	AccountDac         string `json:"accountDac,omitempty"`
	AccountType        int    `json:"accountType,omitempty"`
	AccountPayment     bool   `json:"accountPayment,omitempty"`
	ConvenioAgency     int    `json:"convenioAgency,omitempty"`
	ConvenioNumber     string `json:"convenioNumber,omitempty"`
	RemessaSequential  int    `json:"remessaSequential,omitempty"`
	Webservice         bool   `json:"webservice,omitempty"`
	CodeContract       string `json:"codeContract,omitempty"`
	ClientKey          string `json:"clientKey,omitempty"`
	ClientSecret       string `json:"clientSecret,omitempty"`
	ClientId           string `json:"clientId,omitempty"`
}

type Payer struct {
	Name              string  `json:"name,omitempty"`
	Email             string  `json:"email,omitempty"`
	CpfCnpj           string  `json:"cpfCnpj,omitempty"`
	Accounts          Account `json:"accounts,omitempty"`
	Street            string  `json:"street,omitempty"`
	Neighborhood      string  `json:"neighborhood,omitempty"`
	AddressNumber     string  `json:"addressNumber,omitempty"`
	AddressComplement string  `json:"addressComplement,omitempty"`
	City              string  `json:"city,omitempty"`
	State             string  `json:"state,omitempty"`
	Zipcode           string  `json:"zipcode,omitempty"`
}

type Notification struct {
	Type    string            `json:"type"`
	Email   string            `json:"email,omitempty"`
	CC      string            `json:"cc,omitempty"`
	Headers map[string]string `json:"headers,omitempty"`
	URL     string            `json:"url,omitempty"`
	Mobile  string            `json:"mobile,omitempty"`
	Happen  []string          `json:"happen,omitempty"`
}

type AtualizaNotification struct {
	UniqueId string            `json:"uniqueId,omitempty"`
	Type     string            `json:"type,omitempty"`
	Email    string            `json:"email,omitempty"`
	CC       string            `json:"cc,omitempty"`
	Headers  map[string]string `json:"headers,omitempty"`
	URL      string            `json:"url,omitempty"`
	Mobile   string            `json:"mobile,omitempty"`
	Happen   []string          `json:"happen,omitempty"`
}

func selecionaAmbiente() {
	var ambiente int
	fmt.Printf(
		"\n" +
			"1. Homologação\n" +
			"2. Produção\n" +
			"3. SAIR\n" +
			"--------------------------\n\n",
	)

	fmt.Print("Digite o número correspondente ao ambiente que deseja utilizar: ")
	fmt.Scanln(&ambiente)

	switch ambiente {
	case 1:
		print("Atenção: Você está utilizando o ambiente de homologação.\n\n\n")
		baseUrl := "https://staging.pagamentobancario.com.br/api/v1/"
		selecionaSecao(baseUrl)
	case 2:
		print("Atenção: Você está utilizando o ambiente de PRODUÇÃO.\n\n\n")
		baseUrl := "https://api.pagamentobancario.com.br/api/v1/"
		selecionaSecao(baseUrl)
	case 3:
		break
	}
}

func selecionaSecao(baseUrl string) {
	var secao int
	fmt.Printf(
		"\n" +
			"1. Pagador\n" +
			"2. Conta\n" +
			"3. Certificado\n" +
			"4. Pagamento\n" +
			"5. Pagamento em lote\n" +
			"6. Remessa\n" +
			"7. Retorno\n" +
			"8. Comprovante\n" +
			"9. Bilhetagem\n" +
			"10. Notificação\n" +
			"11. Extrato Bancário\n" +
			"12. SAIR.\n" +
			"--------------------------\n\n",
	)
	fmt.Print("Digite o número correspondente à seção que deseja utilizar: ")
	fmt.Scanln(&secao)

	switch secao {
	case 1:
		print("Você está utilizando a seção 'Pagador'\n")
		urlPagador := baseUrl + "payer"
		rotaPagador(urlPagador)
	case 2:
		print("Você está utilizando a seção 'Conta'\n")
		urlConta := baseUrl + "account"
		rotaConta(urlConta)
	case 3:
		print("Você está utilizando a seção 'Certificado'\n")
	case 4:
		print("Você está utilizando a seção 'Pagamento'\n")
		urlPagamento := baseUrl + "payment"
		rotaPagamento(urlPagamento)
	case 5:
		print("Você está utilizando a seção 'Pagamento em Lote'\n")
		urlPagamentoLote := baseUrl + "payment"
		rotaPagamentoLote(urlPagamentoLote)
	case 6:
		print("Você está utilizando a seção 'Remessa'\n")
		urlRemessa := baseUrl + "remittance"
		rotaRemessa(urlRemessa)
	case 7:
		print("Você está utilizando a seção 'Retorno'\n")
		urlRetorno := baseUrl + "reconciliation"
		rotaRetorno(urlRetorno)
	case 8:
		print("Você está utilizando a seção 'Comprovante'\n")
		urlComprovante := baseUrl + "voucher"
		rotaComprovante(urlComprovante)
	case 9:
		print("Você está utilizando a seção 'Bilhetagem'\n")
		urlBilhetagem := baseUrl + "report"
		rotaBilhetagem(urlBilhetagem)
	case 10:
		print("Você está utilizando a seção 'Notificação'\n")
		urlNotificacao := baseUrl + "notification"
		rotaNoticacao(urlNotificacao)
	case 11:
		print("Você está utilizando a seção 'Extrato Bancário'\n")
		urlExtrato := baseUrl + "statement"
		rotaExtratoBancario(urlExtrato)
	case 12:
		break
	default:
		fmt.Print("SEÇÃO INVÁLIDA")
		selecionaAmbiente()
	}
}

func main() {
	selecionaAmbiente()
}
