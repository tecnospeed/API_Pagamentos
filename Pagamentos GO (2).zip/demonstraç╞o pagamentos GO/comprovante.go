package main

import (
	"bytes"
	"encoding/json"
	"fmt"
	"io/ioutil"
	"log"
	"net/http"
)

func solicitaComprovante(url, cnpjsh, payercpfcnpj, tokensh string, payments []string) {
	client := &http.Client{}

	requestBody, err := json.Marshal(map[string][]string{
		"payments": payments,
	})
	if err != nil {
		log.Fatalf("Erro ao criar o corpo da requisição POST: %v", err)
	}

	req, err := http.NewRequest("POST", url, bytes.NewBuffer(requestBody))
	if err != nil {
		log.Fatalf("Erro ao criar a requisição POST: %v", err)
	}

	req.Header.Add("Content-Type", "application/json")
	req.Header.Add("cnpjSh", cnpjsh)
	req.Header.Add("payercpfcnpj", payercpfcnpj)
	req.Header.Add("tokenSh", tokensh)

	resp, err := client.Do(req)
	if err != nil {
		log.Fatalf("Erro ao realizar a requisição POST: %v", err)
	}

	defer resp.Body.Close()

	body, err := ioutil.ReadAll(resp.Body)
	if err != nil {
		log.Fatalf("Erro ao ler a resposta da requisição POST: %v", err)
	}

	fmt.Println("Resposta POST: ", string(body))
}

func consultaComprovante(url, cnpjsh, payercpfcnpj, tokensh string) {
	client := &http.Client{}

	req, err := http.NewRequest("GET", url, nil)
	if err != nil {
		log.Fatalf("Erro ao criar a requisição GET: %v", err)
	}

	req.Header.Add("cnpjSh", cnpjsh)
	req.Header.Add("payercpfcnpj", payercpfcnpj)
	req.Header.Add("tokenSh", tokensh)

	resp, err := client.Do(req)
	if err != nil {
		log.Fatalf("Erro ao realizar a requisição GET: %v", err)
	}

	defer resp.Body.Close()

	body, err := ioutil.ReadAll(resp.Body)
	if err != nil {
		log.Fatalf("Erro ao ler a resposta da requisição GET: %v", err)
	}

	fmt.Println("Resposta GET: ", string(body))
}

func rotaComprovante(urlComprovante string) {
	var rota int
	fmt.Printf(
		"\n" +
			"1. Enviar Comprovante\n" +
			"2. Consultar Comprovante\n" +
			"3. SAIR\n" +
			"--------------------------\n\n",
	)

	fmt.Print("Selecione o número correspondente à sua opção: ")
	fmt.Scanln(&rota)

	switch rota {
	case 1:
		var cnpjsh, payercpfcnpj, tokensh, payment string
		var payments []string

		fmt.Print("CNPJ da Software House: ")
		fmt.Scanln(&cnpjsh)
		fmt.Print("CNPJ ou CPF do Pagador: ")
		fmt.Scanln(&payercpfcnpj)
		fmt.Print("Token da Software House: ")
		fmt.Scanln(&tokensh)
		fmt.Print("Código do Pagamento: ")
		fmt.Scanln(&payment)
		payments = append(payments, payment)

		solicitaComprovante(urlComprovante, cnpjsh, payercpfcnpj, tokensh, payments)
	case 2:
		var cnpjsh, payercpfcnpj, tokensh, id string

		fmt.Print("CNPJ da Software House: ")
		fmt.Scanln(&cnpjsh)
		fmt.Print("CNPJ ou CPF do Pagador: ")
		fmt.Scanln(&payercpfcnpj)
		fmt.Print("Token da Software House: ")
		fmt.Scanln(&tokensh)
		fmt.Print("ID do Comprovante: ")
		fmt.Scanln(&id)

		consultaComprovante(urlComprovante+"/"+id, cnpjsh, payercpfcnpj, tokensh)
	case 3:
		selecionaAmbiente()
	default:
		fmt.Print("Seção Inválida")
		rotaComprovante(urlComprovante)
	}
}
