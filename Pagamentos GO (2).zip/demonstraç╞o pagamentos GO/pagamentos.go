package main

import (
	"bytes"
	"encoding/json"
	"fmt"
	"io/ioutil"
	"log"
	"net/http"
	"strings"
)

func paymentBillet(url, cnpjsh, payercpfcnpj, tokensh string, payment PaymentBillet) {
	client := &http.Client{}

	payloadBytes, err := json.Marshal(payment)
	if err != nil {
		log.Fatalf("Erro ao serializar o payload: %v", err)
	}
	req, err := http.NewRequest("POST", url, bytes.NewBuffer(payloadBytes))
	if err != nil {
		log.Fatalf("Erro ao criar a requisição POST: %v", err)
	}
	req.Header.Add("cnpjsh", cnpjsh)
	req.Header.Add("payercpfcnpj", payercpfcnpj)
	req.Header.Add("tokensh", tokensh)
	req.Header.Add("Content-Type", "application/json")

	resp, err := client.Do(req)
	if err != nil {
		log.Fatalf("Erro ao fazer a requisição POST: %v", err)
	}
	defer resp.Body.Close()

	body, err := ioutil.ReadAll(resp.Body)
	if err != nil {
		log.Fatalf("Erro ao ler a resposta da requisição POST: %v", err)
	}

	fmt.Println("Resposta: ", string(body))
}

func paymentTransfer(url, cnpjsh, payercpfcnpj, tokensh string, payment PaymentTransfer) {
	client := &http.Client{}

	payloadBytes, err := json.Marshal(payment)
	if err != nil {
		log.Fatalf("Erro ao serializar o payload: %v", err)
	}
	req, err := http.NewRequest("POST", url, bytes.NewBuffer(payloadBytes))
	if err != nil {
		log.Fatalf("Erro ao criar a requisição POST: %v", err)
	}
	req.Header.Add("cnpjsh", cnpjsh)
	req.Header.Add("payercpfcnpj", payercpfcnpj)
	req.Header.Add("tokensh", tokensh)
	req.Header.Add("Content-Type", "application/json")

	resp, err := client.Do(req)
	if err != nil {
		log.Fatalf("Erro ao fazer a requisição POST: %v", err)
	}
	defer resp.Body.Close()

	body, err := ioutil.ReadAll(resp.Body)
	if err != nil {
		log.Fatalf("Erro ao ler a resposta da requisição POST: %v", err)
	}

	fmt.Println("Resposta: ", string(body))
}

func paymentPaycheck(url, cnpjsh, payercpfcnpj, tokensh string, salario Paycheck) {
	client := &http.Client{}

	payloadBytes, err := json.Marshal(salario)
	if err != nil {
		log.Fatalf("Erro ao serializar o payload: %v", err)
	}
	req, err := http.NewRequest("POST", url, bytes.NewBuffer(payloadBytes))
	if err != nil {
		log.Fatalf("Erro ao criar a requisição POST: %v", err)
	}
	req.Header.Add("cnpjsh", cnpjsh)
	req.Header.Add("payercpfcnpj", payercpfcnpj)
	req.Header.Add("tokensh", tokensh)
	req.Header.Add("Content-Type", "application/json")

	resp, err := client.Do(req)
	if err != nil {
		log.Fatalf("Erro ao fazer a requisição POST: %v", err)
	}
	defer resp.Body.Close()

	body, err := ioutil.ReadAll(resp.Body)
	if err != nil {
		log.Fatalf("Erro ao ler a resposta da requisição POST: %v", err)
	}

	fmt.Println("Resposta: ", string(body))
}

func paymentGARE(url, cnpjsh, payercpfcnpj, tokensh string, gare GARE) {
	client := &http.Client{}

	payloadBytes, err := json.Marshal(gare)
	if err != nil {
		log.Fatalf("Erro ao serializar o payload: %v", err)
	}
	req, err := http.NewRequest("POST", url, bytes.NewBuffer(payloadBytes))
	if err != nil {
		log.Fatalf("Erro ao criar a requisição POST: %v", err)
	}
	req.Header.Add("cnpjsh", cnpjsh)
	req.Header.Add("payercpfcnpj", payercpfcnpj)
	req.Header.Add("tokensh", tokensh)
	req.Header.Add("Content-Type", "application/json")

	resp, err := client.Do(req)
	if err != nil {
		log.Fatalf("Erro ao fazer a requisição POST: %v", err)
	}
	defer resp.Body.Close()

	body, err := ioutil.ReadAll(resp.Body)
	if err != nil {
		log.Fatalf("Erro ao ler a resposta da requisição POST: %v", err)
	}

	fmt.Println("Resposta: ", string(body))
}

func paymentIPVA(url, cnpjsh, payercpfcnpj, tokensh string, ipva IPVA) {
	client := &http.Client{}

	payloadBytes, err := json.Marshal(ipva)
	if err != nil {
		log.Fatalf("Erro ao serializar o payload: %v", err)
	}
	req, err := http.NewRequest("POST", url, bytes.NewBuffer(payloadBytes))
	if err != nil {
		log.Fatalf("Erro ao criar a requisição POST: %v", err)
	}
	req.Header.Add("cnpjsh", cnpjsh)
	req.Header.Add("payercpfcnpj", payercpfcnpj)
	req.Header.Add("tokensh", tokensh)
	req.Header.Add("Content-Type", "application/json")

	resp, err := client.Do(req)
	if err != nil {
		log.Fatalf("Erro ao fazer a requisição POST: %v", err)
	}
	defer resp.Body.Close()

	body, err := ioutil.ReadAll(resp.Body)
	if err != nil {
		log.Fatalf("Erro ao ler a resposta da requisição POST: %v", err)
	}

	fmt.Println("Resposta: ", string(body))
}

func paymentDPVAT(url, cnpjsh, payercpfcnpj, tokensh string, dpvat DPVAT) {
	client := &http.Client{}

	payloadBytes, err := json.Marshal(dpvat)
	if err != nil {
		log.Fatalf("Erro ao serializar o payload: %v", err)
	}
	req, err := http.NewRequest("POST", url, bytes.NewBuffer(payloadBytes))
	if err != nil {
		log.Fatalf("Erro ao criar a requisição POST: %v", err)
	}
	req.Header.Add("cnpjsh", cnpjsh)
	req.Header.Add("payercpfcnpj", payercpfcnpj)
	req.Header.Add("tokensh", tokensh)
	req.Header.Add("Content-Type", "application/json")

	resp, err := client.Do(req)
	if err != nil {
		log.Fatalf("Erro ao fazer a requisição POST: %v", err)
	}
	defer resp.Body.Close()

	body, err := ioutil.ReadAll(resp.Body)
	if err != nil {
		log.Fatalf("Erro ao ler a resposta da requisição POST: %v", err)
	}

	fmt.Println("Resposta: ", string(body))
}

func paymentDARF(url, cnpjsh, payercpfcnpj, tokensh string, darf DARF) {
	client := &http.Client{}

	payloadBytes, err := json.Marshal(darf)
	if err != nil {
		log.Fatalf("Erro ao serializar o payload: %v", err)
	}
	req, err := http.NewRequest("POST", url, bytes.NewBuffer(payloadBytes))
	if err != nil {
		log.Fatalf("Erro ao criar a requisição POST: %v", err)
	}
	req.Header.Add("cnpjsh", cnpjsh)
	req.Header.Add("payercpfcnpj", payercpfcnpj)
	req.Header.Add("tokensh", tokensh)
	req.Header.Add("Content-Type", "application/json")

	resp, err := client.Do(req)
	if err != nil {
		log.Fatalf("Erro ao fazer a requisição POST: %v", err)
	}
	defer resp.Body.Close()

	body, err := ioutil.ReadAll(resp.Body)
	if err != nil {
		log.Fatalf("Erro ao ler a resposta da requisição POST: %v", err)
	}

	fmt.Println("Resposta: ", string(body))
}

func paymentGPS(url, cnpjsh, payercpfcnpj, tokensh string, gps GPS) {
	client := &http.Client{}

	payloadBytes, err := json.Marshal(gps)
	if err != nil {
		log.Fatalf("Erro ao serializar o payload: %v", err)
	}
	req, err := http.NewRequest("POST", url, bytes.NewBuffer(payloadBytes))
	if err != nil {
		log.Fatalf("Erro ao criar a requisição POST: %v", err)
	}
	req.Header.Add("cnpjsh", cnpjsh)
	req.Header.Add("payercpfcnpj", payercpfcnpj)
	req.Header.Add("tokensh", tokensh)
	req.Header.Add("Content-Type", "application/json")

	resp, err := client.Do(req)
	if err != nil {
		log.Fatalf("Erro ao fazer a requisição POST: %v", err)
	}
	defer resp.Body.Close()

	body, err := ioutil.ReadAll(resp.Body)
	if err != nil {
		log.Fatalf("Erro ao ler a resposta da requisição POST: %v", err)
	}

	fmt.Println("Resposta: ", string(body))
}

func paymentFGTS(url, cnpjsh, payercpfcnpj, tokensh string, fgts FGTS) {
	client := &http.Client{}

	payloadBytes, err := json.Marshal(fgts)
	if err != nil {
		log.Fatalf("Erro ao serializar o payload: %v", err)
	}
	req, err := http.NewRequest("POST", url, bytes.NewBuffer(payloadBytes))
	if err != nil {
		log.Fatalf("Erro ao criar a requisição POST: %v", err)
	}
	req.Header.Add("cnpjsh", cnpjsh)
	req.Header.Add("payercpfcnpj", payercpfcnpj)
	req.Header.Add("tokensh", tokensh)
	req.Header.Add("Content-Type", "application/json")

	resp, err := client.Do(req)
	if err != nil {
		log.Fatalf("Erro ao fazer a requisição POST: %v", err)
	}
	defer resp.Body.Close()

	body, err := ioutil.ReadAll(resp.Body)
	if err != nil {
		log.Fatalf("Erro ao ler a resposta da requisição POST: %v", err)
	}

	fmt.Println("Resposta: ", string(body))
}

func paymentVarious(url, cnpjsh, payercpfcnpj, tokensh string, various Diversos) {
	client := &http.Client{}

	payloadBytes, err := json.Marshal(various)
	if err != nil {
		log.Fatalf("Erro ao serializar o payload: %v", err)
	}
	req, err := http.NewRequest("POST", url, bytes.NewBuffer(payloadBytes))
	if err != nil {
		log.Fatalf("Erro ao criar a requisição POST: %v", err)
	}
	req.Header.Add("cnpjsh", cnpjsh)
	req.Header.Add("payercpfcnpj", payercpfcnpj)
	req.Header.Add("tokensh", tokensh)
	req.Header.Add("Content-Type", "application/json")

	resp, err := client.Do(req)
	if err != nil {
		log.Fatalf("Erro ao fazer a requisição POST: %v", err)
	}
	defer resp.Body.Close()

	body, err := ioutil.ReadAll(resp.Body)
	if err != nil {
		log.Fatalf("Erro ao ler a resposta da requisição POST: %v", err)
	}

	fmt.Println("Resposta: ", string(body))
}

func consultaPagamento(url, cnpjsh, payercpfcnpj, tokensh string) {
	client := &http.Client{}

	req, err := http.NewRequest("GET", url, nil)
	if err != nil {
		log.Fatalf("Erro ao criar a requisição GET: %v", err)
	}

	req.Header.Add("cnpjsh", cnpjsh)
	req.Header.Add("payercpfcnpj", payercpfcnpj)
	req.Header.Add("tokensh", tokensh)

	resp, err := client.Do(req)
	if err != nil {
		log.Fatalf("Erro ao realizar a requisição GET: %v", err)
	}
	defer resp.Body.Close()

	body, err := ioutil.ReadAll(resp.Body)
	if err != nil {
		log.Fatalf("Erro ao ler a resposta da requisição: %v", err)
	}

	fmt.Println("Resposta GET: ", string(body))
}

func deletaPagamento(url, cnpjsh, payercpfcnpj, tokensh string, paymentIDs []string) {
	client := &http.Client{}

	payload := PaymentDeleteRequest{
		Payments: paymentIDs,
	}

	payloadBytes, err := json.Marshal(payload)
	if err != nil {
		log.Fatalf("Erro ao serializar o payload: %v", err)
	}

	req, err := http.NewRequest("DELETE", url, bytes.NewBuffer(payloadBytes))
	if err != nil {
		log.Fatalf("Erro ao criar a requisição DELETE: %v", err)
	}

	req.Header.Add("Content-Type", "application/json")
	req.Header.Add("cnpjSh", cnpjsh)
	req.Header.Add("payercpfcnpj", payercpfcnpj)
	req.Header.Add("tokensh", tokensh)

	resp, err := client.Do(req)
	if err != nil {
		log.Fatalf("Erro ao fazer a requisição DELETE: %v", err)
	}
	defer resp.Body.Close()

	if resp.StatusCode == http.StatusOK {
		fmt.Println("Pagamento(s) excluído(s) com sucesso.")
	} else {
		fmt.Printf("Erro ao excluir pagamento(s). Status: %d\n", resp.StatusCode)
	}
}
func rotaPagamento(urlPagamento string) {
	var rota int
	fmt.Printf(
		"\n" +
			"1. Títulos, concessionárias e tributos com código de barras\n" +
			"2. Transferência bancária\n" +
			"3. Salários\n" +
			"4. GARE\n" +
			"5. IPVA\n" +
			"6. DPVAT\n" +
			"7. DARF\n" +
			"8. GPS\n" +
			"9. FGTS\n" +
			"10. Diversos\n" +
			"11. Consultar Pagamentos Gerados\n" +
			"12. Excluir Pagamento\n" +
			"13. SAIR\n" +
			"--------------------------\n\n",
	)
	fmt.Print("Digite o número correspondente à rota que deseja utilizar: ")
	fmt.Scanln(&rota)

	switch rota {
	case 1:
		var payment PaymentBillet
		var cnpjsh, tokensh, payercpfcnpj string

		fmt.Print("CNPJ da Software House: ")
		fmt.Scanln(&cnpjsh)
		fmt.Print("Token da Software House: ")
		fmt.Scanln(&tokensh)
		fmt.Print("CNPJ do Pagador: ")
		fmt.Scanln(&payercpfcnpj)

		fmt.Print("Hash da conta (obrigatório): ")
		fmt.Scanln(&payment.AccountHash)
		fmt.Print("paymentForm(obrigatório): ")
		fmt.Scanln(&payment.PaymentForm)
		fmt.Print("Descrição: ")
		fmt.Scanln(&payment.Description)
		fmt.Print("Código de barras (obrigatório): ")
		fmt.Scanln(&payment.Barcode)
		fmt.Print("Data de Vencimento (obrigatório): ")
		fmt.Scanln(&payment.DueDate)
		fmt.Print("Data do pagamento: ")
		fmt.Scanln(&payment.PaymentDate)
		fmt.Print("Valor nominal (obrigatório): ")
		fmt.Scanln(&payment.NominalAmount)
		fmt.Print("Valor de desconto: ")
		fmt.Scanln(&payment.DiscountAmount)
		fmt.Print("Valor montante dos Juros: ")
		fmt.Scanln(&payment.FeeAmount)
		fmt.Print("Valor líquido: ")
		fmt.Scanln(&payment.Amount)
		fmt.Print("Código da Instrução do Movimento: ")
		fmt.Scanln(&payment.MovimentCode)
		fmt.Print("Nome do Avalista: ")
		fmt.Scanln(&payment.AvalistaName)
		fmt.Print("CPF ou CNPJ do Avalista: ")
		fmt.Scanln(&payment.AvalistaCpfCnpj)
		fmt.Print("Tipo de Compromisso (APENAS CAIXA): ")
		fmt.Scanln(&payment.CompromiseType)
		fmt.Print("Parâmetro de Transmissão (APENAS CAIXA): ")
		fmt.Scanln(&payment.TransmissionParam)
		fmt.Print("Nome do Beneficiário (obrigatório): ")
		fmt.Scanln(&payment.Beneficiary.Name)
		fmt.Print("CPF/CNPJ do Beneficiário (Obrigatório): ")
		fmt.Scanln(&payment.Beneficiary.CpfCnpj)
		fmt.Print("Código do Banco: ")
		fmt.Scanln(&payment.Beneficiary.BankCode)
		fmt.Print("Agência: ")
		fmt.Scanln(&payment.Beneficiary.Agency)
		fmt.Print("Dígito da Agência: ")
		fmt.Scanln(&payment.Beneficiary.AgencyDigit)
		fmt.Print("Número da Conta: ")
		fmt.Scanln(&payment.Beneficiary.AccountNumber)
		fmt.Print("Rua: ")
		fmt.Scanln(&payment.Beneficiary.Street)
		fmt.Print("DV da conta: ")
		fmt.Scanln(&payment.Beneficiary.AccountNumberDigit)
		fmt.Print("DAC da conta: ")
		fmt.Scanln(&payment.Beneficiary.AccountDac)
		fmt.Print("Bairro: ")
		fmt.Scanln(&payment.Beneficiary.Neighborhood)
		fmt.Print("Número: ")
		fmt.Scanln(&payment.Beneficiary.AddressNumber)
		fmt.Print("Complemento do endereço: ")
		fmt.Scanln(&payment.Beneficiary.AddressComplement)
		fmt.Print("Cidade: ")
		fmt.Scanln(&payment.Beneficiary.City)
		fmt.Print("Estado: ")
		fmt.Scanln(&payment.Beneficiary.State)
		fmt.Print("CEP: ")
		fmt.Scanln(&payment.Beneficiary.Zipcode)
		fmt.Print("Digite as tags separadas por vírgula: ")

		var tagsInput string
		fmt.Scanln(&tagsInput)
		payment.Tags = strings.Split(tagsInput, ",")

		url := urlPagamento + "/billet"

		paymentBillet(url, cnpjsh, payercpfcnpj, tokensh, payment)
	case 2:
		var payment PaymentTransfer
		var cnpjsh, tokensh, payercpfcnpj string

		fmt.Print("CNPJ da Software House: ")
		fmt.Scanln(&cnpjsh)
		fmt.Print("Token da Software House: ")
		fmt.Scanln(&tokensh)
		fmt.Print("CNPJ do Pagador: ")
		fmt.Scanln(&payercpfcnpj)

		fmt.Print("accountHash (Obrigatório): ")
		fmt.Scanln(&payment.AccountHash)
		fmt.Print("Descrição: ")
		fmt.Scanln(&payment.Description)
		fmt.Print("PaymentForm (Obrigatório): ")
		fmt.Scanln(&payment.PaymentForm)
		fmt.Print("PaymentDate: ")
		fmt.Scanln(&payment.PaymentDate)
		fmt.Print("Data de Vencimento: ")
		fmt.Scanln(&payment.DueDate)
		fmt.Print("Valor (Obrigatório): ")
		fmt.Scanln(&payment.Amount)
		fmt.Print("Valor Nominal: ")
		fmt.Scanln(&payment.NominalAmount)
		fmt.Print("Valor de abatimento: ")
		fmt.Scanln(&payment.RebateAmount)
		fmt.Print("Valor de juros: ")
		fmt.Scanln(&payment.InterestAmount)
		fmt.Print("Valor da multa: ")
		fmt.Scanln(&payment.FineAmount)
		fmt.Print("Valor de desconto: ")
		fmt.Scanln(&payment.DiscountAmount)
		fmt.Print("Compensation: ")
		fmt.Scanln(&payment.Compensation)
		fmt.Print("Código de movimento: ")
		fmt.Scanln(&payment.MovimentCode)
		fmt.Print("Código Complementar: ")
		fmt.Scanln(&payment.ComplementaryCode)
		fmt.Print("Forma Parcelamento: ")
		fmt.Scanln(&payment.InstallmentForm)
		fmt.Print("Período ou Dia do Vencimento (CAIXA): ")
		fmt.Scanln(&payment.PeriodicDueDate)
		fmt.Print("Parâmetro de transmissão (CAIXA): ")
		fmt.Scanln(&payment.CompromiseType)
		fmt.Print("Parâmetro de transmissão (CAIXA): ")
		fmt.Scanln(&payment.TransmissionParam)
		fmt.Print("Nome do Beneficiário (Obrigatório): ")
		fmt.Scanln(&payment.Beneficiary.Name)
		fmt.Print("CPF/CNPJ do Beneficiário (Obrigatório): ")
		fmt.Scanln(&payment.Beneficiary.CpfCnpj)
		fmt.Print("Código do Banco (Obrigatório): ")
		fmt.Scanln(&payment.Beneficiary.BankCode)
		fmt.Print("Agência (Obrigatório): ")
		fmt.Scanln(&payment.Beneficiary.Agency)
		fmt.Print("Dígito da Agência: ")
		fmt.Scanln(&payment.Beneficiary.AgencyDigit)
		fmt.Print("Número da Conta (Obrigatório): ")
		fmt.Scanln(&payment.Beneficiary.AccountNumber)
		fmt.Print("Rua: ")
		fmt.Scanln(&payment.Beneficiary.Street)
		fmt.Print("DV da conta: ")
		fmt.Scanln(&payment.Beneficiary.AccountNumberDigit)
		fmt.Print("DAC da conta: ")
		fmt.Scanln(&payment.Beneficiary.AccountDac)
		fmt.Print("Bairro: ")
		fmt.Scanln(&payment.Beneficiary.Neighborhood)
		fmt.Print("Número: ")
		fmt.Scanln(&payment.Beneficiary.AddressNumber)
		fmt.Print("Complemento do endereço: ")
		fmt.Scanln(&payment.Beneficiary.AddressComplement)
		fmt.Print("Cidade: ")
		fmt.Scanln(&payment.Beneficiary.City)
		fmt.Print("Estado: ")
		fmt.Scanln(&payment.Beneficiary.State)
		fmt.Print("CEP: ")
		fmt.Scanln(&payment.Beneficiary.Zipcode)
		fmt.Print("Tipo da conta: ")
		fmt.Scanln(&payment.Beneficiary.AccountType)
		fmt.Print("Opções de Transferência: ")
		fmt.Scanln(&payment.Beneficiary.TransferOptions)
		fmt.Print("Digite as tags separadas por vírgula: ")
		fmt.Scanln(&payment.Tags)

		var tagsInput string
		fmt.Scanln(&tagsInput)
		payment.Tags = strings.Split(tagsInput, ",")

		url := urlPagamento + "/transfer"
		paymentTransfer(url, cnpjsh, payercpfcnpj, tokensh, payment)

	case 3:
		var paycheck Paycheck
		var cnpjsh, tokensh, payercpfcnpj string

		fmt.Print("CNPJ da Software House: ")
		fmt.Scanln(&cnpjsh)
		fmt.Print("Token da Software House: ")
		fmt.Scanln(&tokensh)
		fmt.Print("CNPJ do Pagador: ")
		fmt.Scanln(&payercpfcnpj)
		fmt.Print("accountHash (Obrigatório): ")
		fmt.Scanln(&paycheck.AccountHash)
		fmt.Print("Descrição: ")
		fmt.Scanln(&paycheck.Description)
		fmt.Print("Forma de Pagamento (Obrigatório): ")
		fmt.Scanln(&paycheck.PaymentForm)
		fmt.Print("Dia do pagamento (Obrigatório): ")
		fmt.Scanln(&paycheck.PaymentDate)
		fmt.Print("Data de Vencimento (Obrigatório): ")
		fmt.Scanln(&paycheck.DueDate)
		fmt.Print("Valor (Obrigatório): ")
		fmt.Scanln(&paycheck.Amount)
		fmt.Print("Valor de abatimento: ")
		fmt.Scanln(&paycheck.RebateAmount)
		fmt.Print("Valor de juros: ")
		fmt.Scanln(&paycheck.InterestAmount)
		fmt.Print("Valor de desconto: ")
		fmt.Scanln(&paycheck.DiscountAmount)
		fmt.Print("Valor da multa: ")
		fmt.Scanln(&paycheck.FineAmount)
		fmt.Print("Código de Movimento: ")
		fmt.Scanln(&paycheck.MovimentCode)
		fmt.Print("Código Complementar: ")
		fmt.Scanln(&paycheck.ComplementaryCode)
		fmt.Print("Compromise Type (CAIXA): ")
		fmt.Scanln(&paycheck.CompromiseType)
		fmt.Print("Parâmetro de Transmissão (CAIXA): ")
		fmt.Scanln(&paycheck.TransmissionParam)
		fmt.Print("Opção de Transferência (Sicoob e Caixa): ")
		fmt.Scanln(&paycheck.TransferOptions)

		fmt.Print("Nome do Beneficiário (Obrigatório): ")
		fmt.Scanln(&paycheck.Beneficiary.Name)
		fmt.Print("CPF/CNPJ do Beneficiário (Obrigatório): ")
		fmt.Scanln(&paycheck.Beneficiary.CpfCnpj)
		fmt.Print("Código do Banco (Obrigatório): ")
		fmt.Scanln(&paycheck.Beneficiary.BankCode)
		fmt.Print("Agência (Obrigatório): ")
		fmt.Scanln(&paycheck.Beneficiary.Agency)
		fmt.Print("DV da Agência: ")
		fmt.Scanln(&paycheck.Beneficiary.AgencyDigit)
		fmt.Print("Número da conta (Obrigatório): ")
		fmt.Scanln(&paycheck.Beneficiary.AccountNumber)
		fmt.Print("DV da Conta: ")
		fmt.Scanln(&paycheck.Beneficiary.AccountNumberDigit)
		fmt.Print("Rua: ")
		fmt.Scanln(&paycheck.Beneficiary.Street)
		fmt.Print("Bairro: ")
		fmt.Scanln(&paycheck.Beneficiary.Neighborhood)
		fmt.Print("Número: ")
		fmt.Scanln(&paycheck.Beneficiary.AddressNumber)
		fmt.Print("Complemento: ")
		fmt.Scanln(&paycheck.Beneficiary.AddressComplement)
		fmt.Print("Cidade: ")
		fmt.Scanln(&paycheck.Beneficiary.City)
		fmt.Print("Estado: ")
		fmt.Scanln(&paycheck.Beneficiary.State)
		fmt.Print("CEP: ")
		fmt.Scanln(&paycheck.Beneficiary.Zipcode)

		fmt.Print("Digite as tags separadas por vírgula: ")
		fmt.Scanln(&paycheck.Tags)

		var tagsInput string
		fmt.Scanln(&tagsInput)
		paycheck.Tags = strings.Split(tagsInput, ",")

		url := urlPagamento + "/paycheck"
		paymentPaycheck(url, cnpjsh, payercpfcnpj, tokensh, paycheck)

	case 4:
		var gare GARE
		var cnpjsh, tokensh, payercpfcnpj string

		fmt.Print("CNPJ da Software House: ")
		fmt.Scanln(&cnpjsh)
		fmt.Print("Token da Software House: ")
		fmt.Scanln(&tokensh)
		fmt.Print("CNPJ do Pagador: ")
		fmt.Scanln(&payercpfcnpj)
		fmt.Print("AccountHash (Obrigatório): ")
		fmt.Scanln(&gare.AccountHash)
		fmt.Print("Código de Pagamento: ")
		fmt.Scanln(&gare.RevenueCode)
		fmt.Print("Data do Pagamento (Obrigatório): ")
		fmt.Scanln(&gare.PaymentDate)
		fmt.Print("Data de Vencimento (Obrigatório): ")
		fmt.Scanln(&gare.DueDate)
		fmt.Print("Valor (Obrigatório): ")
		fmt.Scanln(&gare.Amount)
		fmt.Print("Descrição: ")
		fmt.Scanln(&gare.Description)
		fmt.Print("Identificação do Contribuinte (Obrigatório): ")
		fmt.Scanln(&gare.ContributorDocument)
		fmt.Print("Número de Inscrição Estadual (Obrigatório): ")
		fmt.Scanln(&gare.StateRegistration)
		fmt.Print("Código da Dívida Ativa (Obrigatório): ")
		fmt.Scanln(&gare.ActiveDebite)
		fmt.Print("Período de Referência (Obrigatório): ")
		fmt.Scanln(&gare.ReferencePeriod)
		fmt.Print("Número da Parcela (Obrigatório): ")
		fmt.Scanln(&gare.Installment)
		fmt.Print("Valor dos juros: ")
		fmt.Scanln(&gare.InterestAmount)
		fmt.Print("Valor da multa: ")
		fmt.Scanln(&gare.FineAmount)
		fmt.Print("Valor nominal (Obrigatório): ")
		fmt.Scanln(&gare.NominalAmount)
		fmt.Print("Valor de Acréscimos: ")
		fmt.Scanln(&gare.IncreaseAmount)
		fmt.Print("Valor de Honorários: ")
		fmt.Scanln(&gare.HonoraryAmount)
		fmt.Print("Digite as tags separadas por vírgula: ")
		fmt.Scanln(&gare.Tags)

		var tagsInput string
		fmt.Scanln(&tagsInput)
		gare.Tags = strings.Split(tagsInput, ",")

		url := urlPagamento + "/taxes/gare"
		paymentGARE(url, cnpjsh, payercpfcnpj, tokensh, gare)
	case 5:
		var ipva IPVA
		var cnpjsh, tokensh, payercpfcnpj string

		fmt.Print("CNPJ da Software House: ")
		fmt.Scanln(&cnpjsh)
		fmt.Print("Token da Software House: ")
		fmt.Scanln(&tokensh)
		fmt.Print("CNPJ do Pagador: ")
		fmt.Scanln(&payercpfcnpj)
		fmt.Print("AccountHash (Obrigatório): ")
		fmt.Scanln(&ipva.AccountHash)
		fmt.Print("Código de Pagamento: ")
		fmt.Scanln(&ipva.RevenueCode)
		fmt.Print("Data do Pagamento (Obrigatório): ")
		fmt.Scanln(&ipva.PaymentDate)
		fmt.Print("Identificação do Contribuinte (Obrigatório): ")
		fmt.Scanln(&ipva.ContributorDocument)
		fmt.Print("Descrição: ")
		fmt.Scanln(&ipva.Description)
		fmt.Print("Valor nominal (Obrigatório): ")
		fmt.Scanln(&ipva.NominalAmount)
		fmt.Print("Nome do Contribuinte (Obrigatório): ")
		fmt.Scanln(&ipva.ContributorName)
		fmt.Print("Ano de Cálculo (Obrigatório): ")
		fmt.Scanln(&ipva.CalculationYear)
		fmt.Print("Valor (Obrigatório): ")
		fmt.Scanln(&ipva.Amount)
		fmt.Print("Data de Vencimento (Obrigatório): ")
		fmt.Scanln(&ipva.DueDate)
		fmt.Print("Código Municipal (Obrigatório): ")
		fmt.Scanln(&ipva.MunicipalCode)
		fmt.Print("Valor do Desconto: ")
		fmt.Scanln(&ipva.DiscountAmount)
		fmt.Print("Estado (Obrigatório): ")
		fmt.Scanln(&ipva.State)
		fmt.Print("Placa do Veículo (Obrigatório): ")
		fmt.Scanln(&ipva.VehiclePlate)
		fmt.Print("Opções de Pagamento (Obrigatório): ")
		fmt.Scanln(&ipva.PaymentOption)
		fmt.Print("Renavam do Veículo (Obrigatório): ")
		fmt.Scanln(&ipva.VehicleRenavam)
		fmt.Print("Opção de Retirada CRVL: ")
		fmt.Scanln(&ipva.CRVLWithdrawalOption)
		fmt.Print("Digite as tags separadas por vírgula: ")
		fmt.Scanln(&ipva.Tags)

		var tagsInput string
		fmt.Scanln(&tagsInput)
		ipva.Tags = strings.Split(tagsInput, ",")

		url := urlPagamento + "/taxes/ipva"
		paymentIPVA(url, cnpjsh, payercpfcnpj, tokensh, ipva)

	case 6:
		var dpvat DPVAT
		var cnpjsh, tokensh, payercpfcnpj string

		fmt.Print("CNPJ da Software House: ")
		fmt.Scanln(&cnpjsh)
		fmt.Print("Token da Software House: ")
		fmt.Scanln(&tokensh)
		fmt.Print("CNPJ do Pagador: ")
		fmt.Scanln(&payercpfcnpj)
		fmt.Print("AccountHash (Obrigatório): ")
		fmt.Scanln(&dpvat.AccountHash)
		fmt.Print("Código de Pagamento: ")
		fmt.Scanln(&dpvat.RevenueCode)
		fmt.Print("Data do Pagamento (Obrigatório): ")
		fmt.Scanln(&dpvat.PaymentDate)
		fmt.Print("Identificação do Contribuinte (Obrigatório): ")
		fmt.Scanln(&dpvat.ContributorDocument)
		fmt.Print("Descrição: ")
		fmt.Scanln(&dpvat.Description)
		fmt.Print("Valor nominal (Obrigatório): ")
		fmt.Scanln(&dpvat.NominalAmount)
		fmt.Print("Nome do Contribuinte (Obrigatório): ")
		fmt.Scanln(&dpvat.ContributorName)
		fmt.Print("Ano de Cálculo (Obrigatório): ")
		fmt.Scanln(&dpvat.CalculationYear)
		fmt.Print("Valor (Obrigatório): ")
		fmt.Scanln(&dpvat.Amount)
		fmt.Print("Data de Vencimento (Obrigatório): ")
		fmt.Scanln(&dpvat.DueDate)
		fmt.Print("Código Municipal (Obrigatório): ")
		fmt.Scanln(&dpvat.MunicipalCode)
		fmt.Print("Valor do Desconto: ")
		fmt.Scanln(&dpvat.DiscountAmount)
		fmt.Print("Cidade (Obrigatório): ")
		fmt.Scanln(&dpvat.City)
		fmt.Print("Estado (Obrigatório): ")
		fmt.Scanln(&dpvat.State)
		fmt.Print("Placa do Veículo (Obrigatório): ")
		fmt.Scanln(&dpvat.VehiclePlate)
		fmt.Print("Opções de Pagamento (Obrigatório): ")
		fmt.Scanln(&dpvat.PaymentOption)
		fmt.Print("Renavam do Veículo (Obrigatório): ")
		fmt.Scanln(&dpvat.VehicleRenavam)
		fmt.Print("Opção de Retirada CRVL (Obrigatório): ")
		fmt.Scanln(&dpvat.CRVLWithdrawalOption)
		fmt.Print("Digite as tags separadas por vírgula: ")
		fmt.Scanln(&dpvat.Tags)

		var tagsInput string
		fmt.Scanln(&tagsInput)
		dpvat.Tags = strings.Split(tagsInput, ",")

		url := urlPagamento + "/taxes/dpvat"
		paymentDPVAT(url, cnpjsh, payercpfcnpj, tokensh, dpvat)

	case 7:
		var darf DARF
		var cnpjsh, tokensh, payercpfcnpj string

		fmt.Print("CNPJ da Software House: ")
		fmt.Scanln(&cnpjsh)
		fmt.Print("Token da Software House: ")
		fmt.Scanln(&tokensh)
		fmt.Print("CNPJ do Pagador: ")
		fmt.Scanln(&payercpfcnpj)
		fmt.Print("AccountHash (Obrigatório): ")
		fmt.Scanln(&darf.AccountHash)
		fmt.Print("Código de Pagamento: ")
		fmt.Scanln(&darf.RevenueCode)
		fmt.Print("Data do Pagamento (Obrigatório): ")
		fmt.Scanln(&darf.PaymentDate)
		fmt.Print("Documento do Contribuinte: ")
		fmt.Scanln(&darf.ContributorDocument)
		fmt.Print("Descrição: ")
		fmt.Scanln(&darf.Description)
		fmt.Print("Período de Apuração: ")
		fmt.Scanln(&darf.ReportingPeriod)
		fmt.Print("Período de Referência (Obrigatório): ")
		fmt.Scanln(&darf.ReferencePeriod)
		fmt.Print("Número de Referência (Obrigatório): ")
		fmt.Scanln(&darf.ReferenceNumber)
		fmt.Print("Valor dos Juros: ")
		fmt.Scanln(&darf.InterestAmount)
		fmt.Print("Valor da multa: ")
		fmt.Scanln(&darf.FineAmount)
		fmt.Print("Valor Nominal (Obrigatório): ")
		fmt.Scanln(&darf.NominalAmount)
		fmt.Print("Data do Vencimento (Obrigatório): ")
		fmt.Scanln(&darf.DueDate)
		fmt.Print("Digite as tags separadas por vírgula: ")
		fmt.Scanln(&darf.Tags)
		fmt.Print("Taxa: ")
		fmt.Scanln(&darf.FeeAmount)
		fmt.Print("Outros valores: ")
		fmt.Scanln(&darf.OtherAmount)
		fmt.Print("Nome do Contribuinte (Obrigatório): ")
		fmt.Scanln(&darf.ContributorName)
		fmt.Print("Código de Movimento: ")
		fmt.Scanln(&darf.MovimentCode)

		var tagsInput string
		fmt.Scanln(&tagsInput)
		darf.Tags = strings.Split(tagsInput, ",")

		url := urlPagamento + "/taxes/darf"
		paymentDARF(url, cnpjsh, payercpfcnpj, tokensh, darf)

	case 8:
		var gps GPS
		var cnpjsh, tokensh, payercpfcnpj string

		fmt.Print("CNPJ da Software House: ")
		fmt.Scanln(&cnpjsh)
		fmt.Print("Token da Software House: ")
		fmt.Scanln(&tokensh)
		fmt.Print("CNPJ do Pagador: ")
		fmt.Scanln(&payercpfcnpj)
		fmt.Print("AccountHash (Obrigatório): ")
		fmt.Scanln(&gps.AccountHash)
		fmt.Print("Forma de Pagamento (Obrigatório): ")
		fmt.Scanln(&gps.PaymentForm)
		fmt.Print("Código do Pagamento: ")
		fmt.Scanln(&gps.RevenueCode)
		fmt.Print("Documento do Contribuinte (Obrigatório): ")
		fmt.Scanln(&gps.ContributorDocument)
		fmt.Print("Data do Pagamento (Obrigatório): ")
		fmt.Scanln(&gps.PaymentDate)
		fmt.Print("Valor (Obrigatório): ")
		fmt.Scanln(&gps.Amount)
		fmt.Print("Descrição: ")
		fmt.Scanln(&gps.Description)
		fmt.Print("Período de Referência (Obrigatório): ")
		fmt.Scanln(&gps.ReferencePeriod)
		fmt.Print("Valor de Outras Entidades (Obrigatório): ")
		fmt.Scanln(&gps.TaxAmount)
		fmt.Print("Outros valores: ")
		fmt.Scanln(&gps.OtherAmount)
		fmt.Print("Valor da Atualização Monetária (Obrigatório): ")
		fmt.Scanln(&gps.MonetaryAdjustment)
		fmt.Print("Digite as tags separadas por vírgula: ")
		fmt.Scanln(&gps.Tags)

		var tagsInput string
		fmt.Scanln(&tagsInput)
		gps.Tags = strings.Split(tagsInput, ",")

		url := urlPagamento + "/taxes/gps"
		paymentGPS(url, cnpjsh, payercpfcnpj, tokensh, gps)

	case 9:
		var fgts FGTS
		var cnpjsh, tokensh, payercpfcnpj string

		fmt.Print("CNPJ da Software House: ")
		fmt.Scanln(&cnpjsh)
		fmt.Print("Token da Software House: ")
		fmt.Scanln(&tokensh)
		fmt.Print("CNPJ do Pagador: ")
		fmt.Scanln(&payercpfcnpj)
		fmt.Print("AccountHash (Obrigatório): ")
		fmt.Scanln(&fgts.AccountHash)
		fmt.Print("Forma de Pagamento (Obrigatório): ")
		fmt.Scanln(&fgts.PaymentForm)
		fmt.Print("Descrição: ")
		fmt.Scanln(&fgts.Description)
		fmt.Print("Código de Barras (Obrigatório): ")
		fmt.Scanln(&fgts.BarCode)
		fmt.Print("Data de Pagamento (Obrigatório): ")
		fmt.Scanln(&fgts.PaymentDate)
		fmt.Print("Data de Vencimento: ")
		fmt.Scanln(&fgts.DueDate)
		fmt.Print("Valor (Obrigatório): ")
		fmt.Scanln(&fgts.Amount)
		fmt.Print("Documento do Contribuinte (Obrigatório): ")
		fmt.Scanln(&fgts.ContributorDocument)
		fmt.Print("Nome do Contribuinte (Obrigatório): ")
		fmt.Scanln(&fgts.ContributorName)
		fmt.Print("Código de Pagamento (Obrigatório): ")
		fmt.Scanln(&fgts.RevenueCode)
		fmt.Print("Identificador do FGTS (Obrigatório): ")
		fmt.Scanln(&fgts.FgtsIdentifier)
		fmt.Print("Lacre da Conectividade Social (Obrigatório): ")
		fmt.Scanln(&fgts.SealSocialConnectivity)
		fmt.Print("Dígito do Lacre da Conectividade Social (Obrigatório): ")
		fmt.Scanln(&fgts.SealSocialConnectivityDigit)
		fmt.Print("Digite as tags separadas por vírgula: ")
		fmt.Scanln(&fgts.Tags)

		var tagsInput string
		fmt.Scanln(&tagsInput)
		fgts.Tags = strings.Split(tagsInput, ",")

		url := urlPagamento + "/taxes/fgts"
		paymentFGTS(url, cnpjsh, payercpfcnpj, tokensh, fgts)

	case 10:
		var various Diversos
		var cnpjsh, tokensh, payercpfcnpj string

		fmt.Print("CNPJ da Software House: ")
		fmt.Scanln(&cnpjsh)
		fmt.Print("Token da Software House: ")
		fmt.Scanln(&tokensh)
		fmt.Print("CNPJ do Pagador: ")
		fmt.Scanln(&payercpfcnpj)
		fmt.Print("AccountHash (Obrigatório): ")
		fmt.Scanln(&various.AccountHash)
		fmt.Print("Descrição: ")
		fmt.Scanln(&various.Description)
		fmt.Print("Forma de Pagamento (Obrigatório): ")
		fmt.Scanln(&various.PaymentForm)
		fmt.Print("Data de Pagamento (Obrigatório): ")
		fmt.Scanln(&various.PaymentDate)
		fmt.Print("Tipo de Pagamento: ")
		fmt.Scanln(&various.PaymentType)
		fmt.Print("Data de Vencimento: ")
		fmt.Scanln(&various.DueDate)
		fmt.Print("Valor (Obrigatório): ")
		fmt.Scanln(&various.Amount)
		fmt.Print("Valor do Abatimento: ")
		fmt.Scanln(&various.RebateAmount)
		fmt.Print("Valor de Juros: ")
		fmt.Scanln(&various.InterestAmount)
		fmt.Print("Valor de Desconto: ")
		fmt.Scanln(&various.DiscountAmount)
		fmt.Print("Valor da Multa: ")
		fmt.Scanln(&various.FineAmount)
		fmt.Print("Código de Movimento: ")
		fmt.Scanln(&various.MovimentCode)
		fmt.Print("Código Complementar: ")
		fmt.Scanln(&various.ComplementaryCode)
		fmt.Print("Compromise Type (CAIXA): ")
		fmt.Scanln(&various.CompromiseType)
		fmt.Print("Parâmetro de Transmissão (CAIXA): ")
		fmt.Scanln(&various.TransmissionParam)
		fmt.Print("Tipo de Chave Pix: ")
		fmt.Scanln(&various.PixType)
		fmt.Print("Chave Pix: ")
		fmt.Scanln(&various.PixKey)
		fmt.Print("Código ISPB: ")
		fmt.Scanln(&various.IspbCode)
		fmt.Print("Complemento de Registro: ")
		fmt.Scanln(&various.RegistrationComplement)
		fmt.Print("URL do Pix: ")
		fmt.Scanln(&various.PixUrl)
		fmt.Print("Código de Identificação QR-CODE: ")
		fmt.Scanln(&various.PixTxid)

		fmt.Print("Nome do Beneficiário (Obrigatório): ")
		fmt.Scanln(&various.Beneficiary.Name)
		fmt.Print("CNPJ/CPF do Beneficiário (Obrigatório): ")
		fmt.Scanln(&various.Beneficiary.CpfCnpj)
		fmt.Print("Código do Banco (Obrigatório): ")
		fmt.Scanln(&various.Beneficiary.BankCode)
		fmt.Print("Agência (Obrigatório): ")
		fmt.Scanln(&various.Beneficiary.Agency)
		fmt.Print("Dígito da Agência: ")
		fmt.Scanln(&various.Beneficiary.AgencyDigit)
		fmt.Print("Número da Conta (Obrigatório): ")
		fmt.Scanln(&various.Beneficiary.AccountNumber)
		fmt.Print("Dígito da Conta: ")
		fmt.Scanln(&various.Beneficiary.AccountNumberDigit)
		fmt.Print("Rua: ")
		fmt.Scanln(&various.Beneficiary.Street)
		fmt.Print("Bairro: ")
		fmt.Scanln(&various.Beneficiary.Neighborhood)
		fmt.Print("Número: ")
		fmt.Scanln(&various.Beneficiary.AddressNumber)
		fmt.Print("Complemento: ")
		fmt.Scanln(&various.Beneficiary.AddressComplement)
		fmt.Print("Cidade: ")
		fmt.Scanln(&various.Beneficiary.City)
		fmt.Print("Estado: ")
		fmt.Scanln(&various.Beneficiary.State)
		fmt.Print("CEP: ")
		fmt.Scanln(&various.Beneficiary.Zipcode)
		fmt.Print("Digite as tags separadas por vírgula: ")
		fmt.Scanln(&various.Tags)

		var tagsInput string
		fmt.Scanln(&tagsInput)
		various.Tags = strings.Split(tagsInput, ",")

		url := urlPagamento + "/various"
		paymentVarious(url, cnpjsh, payercpfcnpj, tokensh, various)
	case 11:
		var uniqueId string
		var cnpjsh, tokensh, payercpfcnpj string

		fmt.Print("CNPJ da Software House: ")
		fmt.Scanln(&cnpjsh)
		fmt.Print("Token da Software House: ")
		fmt.Scanln(&tokensh)
		fmt.Print("CNPJ do Pagador: ")
		fmt.Scanln(&payercpfcnpj)
		fmt.Print("Informe o uniqueId que você deseja consultar: ")
		fmt.Scanln(&uniqueId)

		url := urlPagamento + "?uniqueId=" + uniqueId

		consultaPagamento(url, cnpjsh, payercpfcnpj, tokensh)
	case 12:
		var uniqueIdInput string
		var cnpjsh, tokensh, payercpfcnpj string

		fmt.Print("CNPJ da Software House: ")
		fmt.Scanln(&cnpjsh)
		fmt.Print("Token da Software House: ")
		fmt.Scanln(&tokensh)
		fmt.Print("CNPJ do Pagador: ")
		fmt.Scanln(&payercpfcnpj)
		fmt.Print("Digite os IDs dos pagamentos a serem excluídos, separados por vírgula: ")
		fmt.Scanln(&uniqueIdInput)

		paymentIDs := strings.Split(uniqueIdInput, ",")

		url := urlPagamento
		deletaPagamento(url, cnpjsh, payercpfcnpj, tokensh, paymentIDs)

	case 13:
		selecionaAmbiente()
	default:
		fmt.Print("Seção Inválida.")
		rotaPagamento(urlPagamento)
	}
}
