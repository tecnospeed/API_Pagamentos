package main

import (
	"bytes"
	"fmt"
	"io"
	"io/ioutil"
	"log"
	"mime/multipart"
	"net/http"
	"os"
)

func enviaRetorno(url, cnpjsh, tokensh, payercpfcnpj, filePath string) {
	file, err := os.Open(filePath)
	if err != nil {
		log.Fatalf("Erro ao abrir o arquivo: %v", err)
	}
	defer file.Close()

	body := &bytes.Buffer{}
	writer := multipart.NewWriter(body)
	part, err := writer.CreateFormFile("file", filePath)
	if err != nil {
		log.Fatalf("Erro ao criar parte do formulário: %v", err)
	}
	_, err = io.Copy(part, file)
	if err != nil {
		log.Fatalf("Erro ao copiar o arquivo para o formulário: %v", err)
	}

	err = writer.Close()
	if err != nil {
		log.Fatalf("Erro ao fechar o writer do formulário: %v", err)
	}

	req, err := http.NewRequest("POST", url, body)
	if err != nil {
		log.Fatalf("Erro ao criar a requisição POST: %v", err)
	}

	req.Header.Set("Content-Type", writer.FormDataContentType())
	req.Header.Set("cnpjsh", cnpjsh)
	req.Header.Set("tokensh", tokensh)
	req.Header.Set("payercpfcnpj", payercpfcnpj)

	client := &http.Client{}
	resp, err := client.Do(req)
	if err != nil {
		log.Fatalf("Erro ao enviar a requisição POST: %v", err)
	}
	defer resp.Body.Close()

	respBody, err := io.ReadAll(resp.Body)
	if err != nil {
		log.Fatalf("Erro ao ler a resposta: %v", err)
	}

	fmt.Println("Resposta:", string(respBody))
}

func consultaRetornoPeriodo(url, cnpjsh, tokensh, payercpfcnpj string) {
	client := &http.Client{}

	req, err := http.NewRequest("GET", url, nil)
	if err != nil {
		log.Fatalf("Erro ao criar a requisição GET: %v", err)
	}

	req.Header.Add("cnpjsh", cnpjsh)
	req.Header.Add("payercpfcnpj", payercpfcnpj)
	req.Header.Add("tokensh", tokensh)

	resp, err := client.Do(req)
	if err != nil {
		log.Fatalf("Erro ao realizar a requisição GET: %v", err)
	}
	defer resp.Body.Close()

	body, err := ioutil.ReadAll(resp.Body)
	if err != nil {
		log.Fatalf("Erro ao ler a resposta da requisição: %v", err)
	}

	fmt.Println("Resposta GET: ", string(body))
}

func consultaRetorno(url, cnpjsh, tokensh, payercpfcnpj string) {
	client := &http.Client{}

	req, err := http.NewRequest("GET", url, nil)
	if err != nil {
		log.Fatalf("Erro ao criar a requisição GET: %v", err)
	}

	req.Header.Set("cnpjsh", cnpjsh)
	req.Header.Set("tokensh", tokensh)
	req.Header.Set("payercpfcnpj", payercpfcnpj)

	resp, err := client.Do(req)
	if err != nil {
		log.Fatalf("Erro ao enviar a requisição GET: %v", err)
	}
	defer resp.Body.Close()

	respBody, err := io.ReadAll(resp.Body)
	if err != nil {
		log.Fatalf("Erro ao ler a resposta: %v", err)
	}

	fmt.Println("Resposta:", string(respBody))
}

func baixarRetorno(url, cnpjsh, tokensh, payercpfcnpj string) {
	client := &http.Client{}

	req, err := http.NewRequest("GET", url, nil)
	if err != nil {
		log.Fatalf("Erro ao criar a requisição GET: %v", err)
	}

	req.Header.Add("cnpjSh", cnpjsh)
	req.Header.Add("payercpfcnpj", payercpfcnpj)
	req.Header.Add("tokenSh", tokensh)

	resp, err := client.Do(req)
	if err != nil {
		log.Fatalf("Erro ao realizar a requisição GET: %v", err)
	}
	defer resp.Body.Close()

	body, err := ioutil.ReadAll(resp.Body)
	if err != nil {
		log.Fatalf("Erro ao ler a resposta da requisição: %v", err)
	}

	err = ioutil.WriteFile("retorno_baixado.txt", body, 0644)
	if err != nil {
		log.Fatalf("Erro ao salvar o arquivo: %v", err)
	}

	fmt.Println("Remessa baixada e salva como retorno_baixado.txt")
}

func rotaRetorno(urlRetorno string) {
	var rota int
	fmt.Printf(
		"\n" +
			"1. Enviar Retorno\n" +
			"2. Consultar Retorno por Período\n" +
			"3. Consultar Retorno\n" +
			"4. Baixar Retorno\n" +
			"5. SAIR\n" +
			"----------------------------------\n\n",
	)

	fmt.Print("Digite o número correspondente à rota que deseja utilizar: ")
	fmt.Scanln(&rota)

	var cnpjsh, tokensh, payerCpfCnpj string

	fmt.Print("CNPJ da Software House: ")
	fmt.Scanln(&cnpjsh)
	fmt.Print("Token da Software House: ")
	fmt.Scanln(&tokensh)
	fmt.Print("CNPJ do pagador: ")
	fmt.Scanln(&payerCpfCnpj)

	switch rota {
	case 1:
		var filePath string
		fmt.Print("Caminho do Arquivo de Retorno: ")
		fmt.Scanln(&filePath)

		url := urlRetorno
		enviaRetorno(url, cnpjsh, tokensh, payerCpfCnpj, filePath)
	case 2:
		var dateStart, dateEnd string
		var page, limit int

		fmt.Print("Data Inicial (AAAA-MM-DD): ")
		fmt.Scanln(&dateStart)
		fmt.Print("Data Final (AAAA-MM-DD): ")
		fmt.Scanln(&dateEnd)
		fmt.Print("Página: ")
		fmt.Scanln(&page)
		fmt.Print("Limite: ")
		fmt.Scanln(&limit)

		url := urlRetorno + "?dateStart=" + dateStart + "&dateEnd=" + dateEnd
		consultaRetornoPeriodo(url, cnpjsh, tokensh, payerCpfCnpj)
	case 3:
		var reconciliationId string
		fmt.Print("uniqueId do retorno: ")
		fmt.Scanln(&reconciliationId)

		url := urlRetorno + "/" + reconciliationId

		consultaRetorno(url, cnpjsh, tokensh, payerCpfCnpj)
	case 4:
		var reconciliationId string
		fmt.Print("uniqueId do retorno: ")
		fmt.Scanln(&reconciliationId)

		url := urlRetorno + "/" + reconciliationId + "/download"
		baixarRetorno(url, cnpjsh, tokensh, payerCpfCnpj)
	case 5:
		selecionaAmbiente()
	default:
		fmt.Print("Seção Inválida.")
		rotaRetorno(urlRetorno)
	}
}
