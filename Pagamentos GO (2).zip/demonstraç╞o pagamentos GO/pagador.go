package main

import (
	"bytes"
	"encoding/json"
	"fmt"
	"io"
	"io/ioutil"
	"log"
	"net/http"
)

func cadastrarPagador(url, cnpjsh, tokensh string, payer Payer) {
	client := &http.Client{}

	payloadBytes, err := json.Marshal(payer)
	if err != nil {
		log.Fatalf("Erro ao serializar o payload: %v", err)
	}
	req, err := http.NewRequest("POST", url, bytes.NewBuffer(payloadBytes))
	if err != nil {
		log.Fatalf("Erro ao criar a requisição POST: %v", err)
	}
	req.Header.Add("cnpjsh", cnpjsh)
	req.Header.Add("tokensh", tokensh)

	resp, err := client.Do(req)
	if err != nil {
		log.Fatalf("Erro ao fazer a requisição POST: %v", err)
	}
	defer resp.Body.Close()

	body, err := ioutil.ReadAll(resp.Body)
	if err != nil {
		log.Fatalf("Erro ao ler a resposta da requisição POST: %v", err)
	}

	fmt.Println("Resposta: ", string(body))
}

func consultarPagador(url, cnpjsh, tokensh, payerCpfCnpj string) {
	client := &http.Client{}

	req, err := http.NewRequest("GET", url, nil)
	if err != nil {
		log.Fatalf("Erro ao criar a requisição GET: %v", err)
	}

	req.Header.Add("Content-Type", "application/json")
	req.Header.Add("cnpjsh", cnpjsh)
	req.Header.Add("tokensh", tokensh)
	req.Header.Add("payercpfcnpj", payerCpfCnpj)

	resp, err := client.Do(req)
	if err != nil {
		log.Fatalf("Erro ao realizar a requisição GET: %v", err)
	}

	defer resp.Body.Close()

	body, err := ioutil.ReadAll(resp.Body)
	if err != nil {
		log.Fatalf("Erro ao ler a resposta da requisição GET: %v", err)
	}

	fmt.Println("Resposta GET: ", string(body))
}

func listaPagadores(url, cnpjsh, tokensh string) {
	client := &http.Client{}

	req, err := http.NewRequest("GET", url, nil)
	if err != nil {
		log.Fatalf("Erro ao criar a requisição GET: %v", err)
	}

	req.Header.Add("cnpjsh", cnpjsh)
	req.Header.Add("tokensh", tokensh)

	resp, err := client.Do(req)
	if err != nil {
		log.Fatalf("Erro ao realizar a requisição GET: %v", err)
	}
	defer resp.Body.Close()

	body, err := ioutil.ReadAll(resp.Body)
	if err != nil {
		log.Fatalf("Erro ao ler a resposta da requisição GET: %v", err)
	}

	fmt.Println("Resposta GET:", string(body))
}

func atualizaPagador(url, cnpjsh, tokensh, payercpfcnpj string, atualizaPayer Payer) {
	client := &http.Client{}
	payerData, err := json.Marshal(atualizaPayer)
	if err != nil {
		log.Fatalf("Erro ao converter os dados do pagador para JSON: %v", err)
	}

	req, err := http.NewRequest("PUT", url, bytes.NewBuffer(payerData))
	if err != nil {
		log.Fatalf("Erro ao criar a requisição PUT: %v", err)
	}

	// Adicionando headers
	req.Header.Add("Content-Type", "application/json")
	req.Header.Add("cnpjsh", cnpjsh)
	req.Header.Add("tokensh", tokensh)
	req.Header.Add("payercpfcnpj", payercpfcnpj)

	resp, err := client.Do(req)
	if err != nil {
		log.Fatalf("Erro ao realizar a requisição PUT: %v", err)
	}
	defer resp.Body.Close()

	body, err := io.ReadAll(resp.Body)
	if err != nil {
		log.Fatalf("Erro ao ler a resposta da requisição PUT: %v", err)
	}

	fmt.Println("Resposta PUT:", string(body))
}

func rotaPagador(urlPagador string) {
	var rota int
	fmt.Printf(
		"\n" +
			"1. Cadastrar Pagador\n" +
			"2. Consultar pagador\n" +
			"3. Atualizar dados do pagador\n" +
			"4. Listar pagadores\n" +
			"5. SAIR\n" +
			"--------------------------\n\n",
	)

	fmt.Print("Digite o número correspondente à rota que deseja utilizar: ")
	fmt.Scanln(&rota)

	switch rota {
	case 1:
		var cnpjsh, tokensh string
		var payer Payer
		fmt.Print("CNPJ da Software House: ")
		fmt.Scanln(&cnpjsh)
		fmt.Print("Token da Software House: ")
		fmt.Scanln(&tokensh)

		fmt.Print("Nome do Pagador: ")
		fmt.Scanln(&payer.Name)

		fmt.Print("Email do Pagador: ")
		fmt.Scanln(&payer.Email)

		fmt.Print("CPF/CNPJ do Pagador: ")
		fmt.Scanln(&payer.CpfCnpj)

		fmt.Print("Deseja adicionar a conta no cadastro? (s/n): ")
		var escolha string
		fmt.Scanln(&escolha)
		if escolha == "s" || escolha == "S" {
			fmt.Print("Código do banco (Obrigatório): ")
			fmt.Scanln(&payer.Accounts.BankCode)
			fmt.Print("Número da Agência (Obrigatório): ")
			fmt.Scanln(&payer.Accounts.Agency)
			fmt.Print("DV da Agência: ")
			fmt.Scanln(&payer.Accounts.AgencyDigit)
			fmt.Print("Número da Conta (Obrigatório): ")
			fmt.Scanln(&payer.Accounts.AccountNumber)
			fmt.Print("DV da Conta: ")
			fmt.Scanln(&payer.Accounts.AccountNumberDigit)
			fmt.Print("DAC da Agência/Conta: ")
			fmt.Scanln(&payer.Accounts.AccountDac)
			fmt.Print("convenioAgency: ")
			fmt.Scanln(&payer.Accounts.ConvenioAgency)
			fmt.Print("convenioNumber: ")
			fmt.Scanln(&payer.Accounts.ConvenioNumber)
			fmt.Print("Sequencial da Remessa: ")
			fmt.Scanln(&payer.Accounts.RemessaSequential)

		}

		fmt.Print("Rua: ")
		fmt.Scanln(&payer.Street)

		fmt.Print("Bairro: ")
		fmt.Scanln(&payer.Neighborhood)

		fmt.Print("Número do Endereço: ")
		fmt.Scanln(&payer.AddressNumber)

		fmt.Print("Complemento do Endereço: ")
		fmt.Scanln(&payer.AddressComplement)

		fmt.Print("Cidade: ")
		fmt.Scanln(&payer.City)

		fmt.Print("Estado: ")
		fmt.Scanln(&payer.State)

		fmt.Print("CEP: ")
		fmt.Scanln(&payer.Zipcode)
		cadastrarPagador(urlPagador, cnpjsh, tokensh, payer)
	case 2:
		var cnpjsh, tokensh string

		fmt.Print("CNPJ da Software House: ")
		fmt.Scanln(&cnpjsh)
		fmt.Print("Token da Software House: ")
		fmt.Scanln(&tokensh)
		fmt.Print("CPF/CNPJ do Pagador: ")
		var payerCpfCnpj string
		fmt.Scanln(&payerCpfCnpj)

		consultarPagador(urlPagador, cnpjsh, tokensh, payerCpfCnpj)
	case 3:
		var cnpjsh, tokensh string

		fmt.Print("CNPJ da Software House: ")
		fmt.Scanln(&cnpjsh)
		fmt.Print("Token da Software House: ")
		fmt.Scanln(&tokensh)
		fmt.Print("CPF/CNPJ do Pagador: ")
		var payerCpfCnpj string
		fmt.Scanln(&payerCpfCnpj)

		var atualizaPayer Payer
		fmt.Print("Deseja atualizar o nome? (s/n): ")
		var atualizaNome string
		fmt.Scanln(&atualizaNome)
		if atualizaNome == "s" || atualizaNome == "S" {
			fmt.Print("Novo nome do pagador: ")
			fmt.Scanln(&atualizaPayer.Name)
		}

		fmt.Print("Deseja atualizar o email? (s/n): ")
		var atualizaEmail string
		fmt.Scanln(&atualizaEmail)
		if atualizaEmail == "s" || atualizaEmail == "S" {
			fmt.Print("Novo nome do pagador: ")
			fmt.Scanln(&atualizaPayer.Email)
		}

		fmt.Print("Deseja atualizar a rua? (s/n): ")
		var atualizaRua string
		fmt.Scanln(&atualizaRua)
		if atualizaRua == "s" || atualizaRua == "S" {
			fmt.Print("Nova rua: ")
			fmt.Scanln(&atualizaPayer.Street)
		}

		fmt.Print("Deseja atualizar o bairro? (s/n): ")
		var atualizaBairro string
		fmt.Scanln(&atualizaBairro)
		if atualizaBairro == "s" || atualizaBairro == "S" {
			fmt.Print("Novo Bairro: ")
			fmt.Scanln(&atualizaPayer.Neighborhood)
		}

		fmt.Print("Deseja atualizar o número do endereço do pagador? (s/n): ")
		var atualizaNumeroEndereco string
		fmt.Scanln(&atualizaNumeroEndereco)
		if atualizaNumeroEndereco == "s" || atualizaNumeroEndereco == "S" {
			fmt.Print("Novo Número: ")
			fmt.Scanln(&atualizaPayer.AddressNumber)
		}

		fmt.Print("Deseja atualizar o complemento do endereço do pagador? (s/n): ")
		var atualizaComplementoEndereco string
		fmt.Scanln(&atualizaComplementoEndereco)
		if atualizaComplementoEndereco == "s" || atualizaComplementoEndereco == "S" {
			fmt.Print("Novo Complemento: ")
			fmt.Scanln(&atualizaPayer.AddressComplement)
		}

		fmt.Print("Deseja atualizar a cidade do pagador? (s/n): ")
		var atualizaCidade string
		fmt.Scanln(&atualizaCidade)
		if atualizaCidade == "s" || atualizaCidade == "S" {
			fmt.Print("Nova Cidade: ")
			fmt.Scanln(&atualizaPayer.City)
		}

		fmt.Print("Deseja atualizar o Estado do pagador? (s/n): ")
		var atualizaEstado string
		fmt.Scanln(&atualizaEstado)
		if atualizaEstado == "s" || atualizaEstado == "S" {
			fmt.Print("Novo Estado: ")
			fmt.Scanln(&atualizaPayer.State)
		}

		fmt.Print("Deseja atualizar o CEP do pagador? (s/n): ")
		var atualizaCEP string
		fmt.Scanln(&atualizaCEP)
		if atualizaCEP == "s" || atualizaCEP == "S" {
			fmt.Print("Novo CEP: ")
			fmt.Scanln(&atualizaPayer.Zipcode)
		}

		atualizaPagador(urlPagador, cnpjsh, tokensh, payerCpfCnpj, atualizaPayer)
	case 4:
		var cnpjsh, tokensh string

		fmt.Print("CNPJ da Software House: ")
		fmt.Scanln(&cnpjsh)
		fmt.Print("Token da Software House: ")
		fmt.Scanln(&tokensh)
		url := urlPagador + "/list"
		listaPagadores(url, cnpjsh, tokensh)
	case 5:
		selecionaAmbiente()
	default:
		fmt.Print("Rota Inválida.")
		rotaPagador(urlPagador)
	}
}
