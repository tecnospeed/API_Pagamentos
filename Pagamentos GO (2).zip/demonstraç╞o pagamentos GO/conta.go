package main

import (
	"bufio"
	"bytes"
	"encoding/json"
	"fmt"
	"io"
	"io/ioutil"
	"log"
	"net/http"
	"os"
	"strconv"
	"strings"
)

func criarConta(url, cnpjsh, tokensh, payercpfcnpj string, accounts []Account) {
	client := &http.Client{}
	accountData, err := json.Marshal(accounts)
	if err != nil {
		log.Fatalf("Erro ao converter os dados da conta para JSON: %v", err)
	}

	req, err := http.NewRequest("POST", url, bytes.NewBuffer(accountData))
	if err != nil {
		log.Fatalf("Erro ao criar a requisição POST: %v", err)
	}

	req.Header.Add("Content-Type", "application/json")
	req.Header.Add("cnpjsh", cnpjsh)
	req.Header.Add("tokensh", tokensh)
	req.Header.Add("payercpfcnpj", payercpfcnpj)

	resp, err := client.Do(req)
	if err != nil {
		log.Fatalf("Erro ao realizar a requisiçaão POST: %v", err)
	}
	defer resp.Body.Close()

	body, err := ioutil.ReadAll(resp.Body)
	if err != nil {
		log.Fatalf("Erro ao ler a resposta da requisição POST: %v", err)
	}

	fmt.Println("Resposta POST: ", string(body))
}

func deletarConta(url, cnpjsh, tokensh, payercpfcnpj string, accountHashes []string) {
	client := http.Client{}

	payload := map[string][]string{
		"accountHash": accountHashes,
	}

	payloadBytes, err := json.Marshal(payload)
	if err != nil {
		log.Fatalf("Erro ao criar o payload JSON: %v", err)
	}

	req, err := http.NewRequest("DELETE", url, bytes.NewBuffer(payloadBytes))
	if err != nil {
		log.Fatalf("Erro ao criar a requisição DELETE: %v", err)
	}

	req.Header.Add("Content-Type", "application/json")
	req.Header.Add("cnpjsh", cnpjsh)
	req.Header.Add("tokensh", tokensh)
	req.Header.Add("payercpfcnpj", payercpfcnpj)

	resp, err := client.Do(req)
	if err != nil {
		log.Fatalf("Erro ao realizar a requisição DELETE: %v", err)
	}

	defer resp.Body.Close()

	if resp.StatusCode != http.StatusOK {
		log.Fatalf("Erro na requisição DELETE: StatusCode = %d", resp.StatusCode)
	}

	body, err := io.ReadAll(resp.Body)
	if err != nil {
		log.Fatalf("Erro ao ler a resposta da requisição DELETE: %v", err)
	}

	fmt.Println("Resposta DELETE: ", string(body))
}

func listarContas(url, cnpjsh, tokensh, payercpfcnpj string) {
	client := &http.Client{}

	req, err := http.NewRequest("GET", url, nil)
	if err != nil {
		log.Fatalf("Erro ao criar a requisição GET: %v", err)
	}

	req.Header.Add("Content-Type", "application/json")
	req.Header.Add("cnpjsh", cnpjsh)
	req.Header.Add("tokensh", tokensh)
	req.Header.Add("payercpfcnpj", payercpfcnpj)

	resp, err := client.Do(req)
	if err != nil {
		log.Fatalf("Erro ao realizar a requisição GET: %v", err)
	}

	defer resp.Body.Close()

	body, err := ioutil.ReadAll(resp.Body)
	if err != nil {
		log.Fatalf("Erro ao ler a resposta da requisição GET: %v", err)
	}

	fmt.Println("Resposta GET: ", string(body))
}

func listarContasAHash(url, cnpjsh, tokensh, payercpfcnpj, accountHash string) {
	client := &http.Client{}

	req, err := http.NewRequest("GET", url, nil)
	if err != nil {
		log.Fatalf("Erro ao criar a requisição GET: %v", err)
	}

	req.Header.Add("Content-Type", "application/json")
	req.Header.Add("cnpjsh", cnpjsh)
	req.Header.Add("tokensh", tokensh)
	req.Header.Add("payercpfcnpj", payercpfcnpj)
	req.Header.Add("accountHash", accountHash)

	resp, err := client.Do(req)
	if err != nil {
		log.Fatalf("Erro ao realizar a requisição GET: %v", err)
	}

	defer resp.Body.Close()

	body, err := ioutil.ReadAll(resp.Body)
	if err != nil {
		log.Fatalf("Erro ao ler a resposta da requisição GET: %v", err)
	}

	fmt.Println("Resposta GET: ", string(body))
}

func atualizarConta(url, cnpjsh, tokensh, payercpfcnpj string, atualizaConta Account) {
	client := &http.Client{}
	accountData, err := json.Marshal(atualizaConta)
	if err != nil {
		log.Fatalf("Erro ao converter os dados do pagador para JSON: %v", err)
	}

	req, err := http.NewRequest("PUT", url, bytes.NewBuffer(accountData))
	if err != nil {
		log.Fatalf("Erro ao criar a requisição PUT: %v", err)
	}

	req.Header.Add("Content-Type", "application/json")
	req.Header.Add("cnpjsh", cnpjsh)
	req.Header.Add("tokensh", tokensh)
	req.Header.Add("payercpfcnpj", payercpfcnpj)

	resp, err := client.Do(req)
	if err != nil {
		log.Fatalf("Erro ao realizar a requisição PUT: %v", err)
	}
	defer resp.Body.Close()

	body, err := ioutil.ReadAll(resp.Body)
	if err != nil {
		log.Fatalf("Erro ao ler a resposta da requisição PUT: %v", err)
	}

	fmt.Println("Resposta PUT:", string(body))
}

func rotaConta(urlConta string) {
	reader := bufio.NewReader(os.Stdin)
	var rota int
	fmt.Printf(
		"\n" +
			"1. Criar Conta\n" +
			"2. Deletar Conta\n" +
			"3. Listar Contas\n" +
			"4. Listar Contas Utilizando accountHash\n" +
			"5. Atualizar Conta\n" +
			"6. SAIR\n" +
			"--------------------------\n\n",
	)

	fmt.Print("Digite o número correspondente à rota que deseja utilizar: ")
	fmt.Scanln(&rota)

	switch rota {
	case 1:
		var cnpjsh, tokensh, payerCpfCnpj string

		fmt.Print("CNPJ da Software House: ")
		fmt.Scanln(&cnpjsh)
		fmt.Print("Token da Software House: ")
		fmt.Scanln(&tokensh)
		fmt.Print("CNPJ do pagador: ")
		fmt.Scanln(&payerCpfCnpj)
		var account Account
		var accounts []Account

		fmt.Print("Código do banco: ")
		account.BankCode, _ = reader.ReadString('\n')
		account.BankCode = strings.TrimSpace(account.BankCode)

		fmt.Print("Agência: ")
		account.Agency, _ = reader.ReadString('\n')
		account.Agency = strings.TrimSpace(account.Agency)

		fmt.Print("Dígito da agência (opcional): ")
		account.AgencyDigit, _ = reader.ReadString('\n')
		account.AgencyDigit = strings.TrimSpace(account.AgencyDigit)

		fmt.Print("Número da conta: ")
		account.AccountNumber, _ = reader.ReadString('\n')
		account.AccountNumber = strings.TrimSpace(account.AccountNumber)

		fmt.Print("Dígito da conta (opcional): ")
		account.AccountNumberDigit, _ = reader.ReadString('\n')
		account.AccountNumberDigit = strings.TrimSpace(account.AccountNumberDigit)

		fmt.Print("DAC da conta (opcional): ")
		account.AccountDac, _ = reader.ReadString('\n')
		account.AccountDac = strings.TrimSpace(account.AccountDac)

		if account.BankCode == "104" {
			fmt.Print("Tipo de conta: ")
			accountTypeStr, _ := reader.ReadString('\n')
			accountTypeStr = strings.TrimSpace(accountTypeStr)
			accountType, err := strconv.Atoi(accountTypeStr)
			if err != nil {
				log.Fatalf("Erro ao converter Tipo de conta para inteiro: %v", err)
			}
			account.AccountType = accountType
		}

		if account.BankCode == "033" {
			fmt.Print("Conta de pagamento (true/false) [default: false]: ")
			accountPaymentStr, _ := reader.ReadString('\n')
			accountPaymentStr = strings.TrimSpace(accountPaymentStr)
			if accountPaymentStr == "" {
				account.AccountPayment = false
			} else {
				accountPayment, err := strconv.ParseBool(accountPaymentStr)
				if err != nil {
					log.Fatalf("Erro ao converter Conta de Pagamento para booleano: %v", err)
				}
				account.AccountPayment = accountPayment
			}
		}

		fmt.Print("Agência do Convênio (opcional): ")
		convenioAgencyStr, _ := reader.ReadString('\n')
		convenioAgencyStr = strings.TrimSpace(convenioAgencyStr)
		if convenioAgencyStr != "" {
			convenioAgency, err := strconv.Atoi(convenioAgencyStr)
			if err != nil {
				log.Fatalf("Erro ao converter Agência do Convênio para inteiro: %v", err)
			}
			account.ConvenioAgency = convenioAgency
		}

		fmt.Print("Número do Convênio (opcional): ")
		account.ConvenioNumber, _ = reader.ReadString('\n')
		account.ConvenioNumber = strings.TrimSpace(account.ConvenioNumber)

		fmt.Print("Sequencial da Remessa (opcional): ")
		remessaSequentialStr, _ := reader.ReadString('\n')
		remessaSequentialStr = strings.TrimSpace(remessaSequentialStr)
		if remessaSequentialStr != "" {
			remessaSequential, err := strconv.Atoi(remessaSequentialStr)
			if err != nil {
				log.Fatalf("Erro ao converter Sequencial da Remessa para inteiro: %v", err)
			}
			account.RemessaSequential = remessaSequential
		}

		if account.BankCode == "077" {
			fmt.Print("Webservice (true/false): ")
			webserviceStr, _ := reader.ReadString('\n')
			webserviceStr = strings.TrimSpace(webserviceStr)
			webservice, err := strconv.ParseBool(webserviceStr)
			if err != nil {
				log.Fatalf("Erro ao converter Webservice para booleano: %v", err)
			}
			account.Webservice = webservice
		}

		fmt.Print("Código do Contrato (opcional): ")
		account.CodeContract, _ = reader.ReadString('\n')
		account.CodeContract = strings.TrimSpace(account.CodeContract)

		fmt.Print("ClientKey (opcional): ")
		account.ClientKey, _ = reader.ReadString('\n')
		account.ClientKey = strings.TrimSpace(account.ClientKey)

		fmt.Print("ClientSecret (opcional): ")
		account.ClientSecret, _ = reader.ReadString('\n')
		account.ClientSecret = strings.TrimSpace(account.ClientSecret)

		fmt.Print("ClientId (opcional): ")
		account.ClientId, _ = reader.ReadString('\n')
		account.ClientId = strings.TrimSpace(account.ClientId)

		accounts = append(accounts, account)
		criarConta(urlConta, cnpjsh, tokensh, payerCpfCnpj, accounts)

	case 2:
		var cnpjsh, tokensh, payerCpfCnpj string

		fmt.Print("CNPJ da Software House: ")
		fmt.Scanln(&cnpjsh)
		fmt.Print("Token da Software House: ")
		fmt.Scanln(&tokensh)
		fmt.Print("CNPJ do pagador: ")
		fmt.Scanln(&payerCpfCnpj)
		fmt.Print("accountHash: ")
		var accountHash []string
		fmt.Scanln(&accountHash)
		deletarConta(urlConta, cnpjsh, tokensh, payerCpfCnpj, accountHash)

	case 3:
		var cnpjsh, tokensh, payerCpfCnpj string

		fmt.Print("CNPJ da Software House: ")
		fmt.Scanln(&cnpjsh)
		fmt.Print("Token da Software House: ")
		fmt.Scanln(&tokensh)
		fmt.Print("CNPJ do pagador: ")
		fmt.Scanln(&payerCpfCnpj)
		listarContas(urlConta, cnpjsh, tokensh, payerCpfCnpj)
	case 4:
		var cnpjsh, tokensh, payerCpfCnpj string

		fmt.Print("CNPJ da Software House: ")
		fmt.Scanln(&cnpjsh)
		fmt.Print("Token da Software House: ")
		fmt.Scanln(&tokensh)
		fmt.Print("CNPJ do pagador: ")
		fmt.Scanln(&payerCpfCnpj)
		fmt.Print("accountHash: ")
		var accountHash string
		fmt.Scanln(&accountHash)
		listarContasAHash(urlConta, cnpjsh, tokensh, payerCpfCnpj, accountHash)
	case 5:
		var cnpjsh, tokensh, payerCpfCnpj string

		fmt.Print("CNPJ da Software House: ")
		fmt.Scanln(&cnpjsh)
		fmt.Print("Token da Software House: ")
		fmt.Scanln(&tokensh)
		fmt.Print("CNPJ do pagador: ")
		fmt.Scanln(&payerCpfCnpj)
		var atualizaConta Account
		updateData := make(map[string]interface{})

		fmt.Print("accountHash: ")
		var aHash string
		fmt.Scanln(&aHash)

		fmt.Print("Deseja atualizar o Código do banco? (s/n): ")
		var updateBankCode string
		fmt.Scanln(&updateBankCode)
		if updateBankCode == "s" || updateBankCode == "S" {
			fmt.Print("Código do banco: ")
			atualizaConta.BankCode, _ = reader.ReadString('\n')
			atualizaConta.BankCode = strings.TrimSpace(atualizaConta.BankCode)
			if atualizaConta.BankCode != "" {
				updateData["bankCode"] = atualizaConta.BankCode
			}
		}

		fmt.Print("Deseja atualizar a Agência? (s/n): ")
		var updateAgency string
		fmt.Scanln(&updateAgency)
		if updateAgency == "s" || updateAgency == "S" {
			fmt.Print("Agência: ")
			atualizaConta.Agency, _ = reader.ReadString('\n')
			atualizaConta.Agency = strings.TrimSpace(atualizaConta.Agency)
			if atualizaConta.Agency != "" {
				updateData["agency"] = atualizaConta.Agency
			}
		}

		fmt.Print("Deseja atualizar o Dígito da agência? (s/n): ")
		var updateAgencyDigit string
		fmt.Scanln(&updateAgencyDigit)
		if updateAgencyDigit == "s" || updateAgencyDigit == "S" {
			fmt.Print("Dígito da agência (opcional): ")
			atualizaConta.AgencyDigit, _ = reader.ReadString('\n')
			atualizaConta.AgencyDigit = strings.TrimSpace(atualizaConta.AgencyDigit)
			if atualizaConta.AgencyDigit != "" {
				updateData["agencyDigit"] = atualizaConta.AgencyDigit
			}
		}

		fmt.Print("Deseja atualizar o Número da conta? (s/n): ")
		var updateAccountNumber string
		fmt.Scanln(&updateAccountNumber)
		if updateAccountNumber == "s" || updateAccountNumber == "S" {
			fmt.Print("Número da conta: ")
			atualizaConta.AccountNumber, _ = reader.ReadString('\n')
			atualizaConta.AccountNumber = strings.TrimSpace(atualizaConta.AccountNumber)
			if atualizaConta.AccountNumber != "" {
				updateData["accountNumber"] = atualizaConta.AccountNumber
			}
		}

		fmt.Print("Deseja atualizar o Dígito da conta? (s/n): ")
		var updateAccountNumberDigit string
		fmt.Scanln(&updateAccountNumberDigit)
		if updateAccountNumberDigit == "s" || updateAccountNumberDigit == "S" {
			fmt.Print("Dígito da conta (opcional): ")
			atualizaConta.AccountNumberDigit, _ = reader.ReadString('\n')
			atualizaConta.AccountNumberDigit = strings.TrimSpace(atualizaConta.AccountNumberDigit)
			if atualizaConta.AccountNumberDigit != "" {
				updateData["accountNumberDigit"] = atualizaConta.AccountNumberDigit
			}
		}

		fmt.Print("Deseja atualizar o DAC da conta? (s/n): ")
		var updateAccountDac string
		fmt.Scanln(&updateAccountDac)
		if updateAccountDac == "s" || updateAccountDac == "S" {
			fmt.Print("DAC da conta (opcional): ")
			atualizaConta.AccountDac, _ = reader.ReadString('\n')
			atualizaConta.AccountDac = strings.TrimSpace(atualizaConta.AccountDac)
			if atualizaConta.AccountDac != "" {
				updateData["accountDac"] = atualizaConta.AccountDac
			}
		}

		if updateBankCode == "s" || updateBankCode == "S" {
			if atualizaConta.BankCode == "104" {
				fmt.Print("Deseja atualizar o Tipo de conta? (s/n): ")
				var updateAccountType string
				fmt.Scanln(&updateAccountType)
				if updateAccountType == "s" || updateAccountType == "S" {
					fmt.Print("Tipo de conta: ")
					accountTypeStr, _ := reader.ReadString('\n')
					accountTypeStr = strings.TrimSpace(accountTypeStr)
					accountType, err := strconv.Atoi(accountTypeStr)
					if err != nil {
						log.Fatalf("Erro ao converter Tipo de conta para inteiro: %v", err)
					}
					updateData["accountType"] = accountType
				}
			}
		}

		fmt.Print("Deseja atualizar a Agência do Convênio? (s/n): ")
		var updateConvenioAgency string
		fmt.Scanln(&updateConvenioAgency)
		if updateConvenioAgency == "s" || updateConvenioAgency == "S" {
			fmt.Print("Agência do Convênio (opcional): ")
			convenioAgencyStr, _ := reader.ReadString('\n')
			convenioAgencyStr = strings.TrimSpace(convenioAgencyStr)
			if convenioAgencyStr != "" {
				convenioAgency, err := strconv.Atoi(convenioAgencyStr)
				if err != nil {
					log.Fatalf("Erro ao converter Agência do Convênio para inteiro: %v", err)
				}
				updateData["convenioAgency"] = convenioAgency
			}
		}

		fmt.Print("Deseja atualizar o Número do Convênio? (s/n): ")
		var updateConvenioNumber string
		fmt.Scanln(&updateConvenioNumber)
		if updateConvenioNumber == "s" || updateConvenioNumber == "S" {
			fmt.Print("Número do Convênio (opcional): ")
			atualizaConta.ConvenioNumber, _ = reader.ReadString('\n')
			atualizaConta.ConvenioNumber = strings.TrimSpace(atualizaConta.ConvenioNumber)
			if atualizaConta.ConvenioNumber != "" {
				updateData["convenioNumber"] = atualizaConta.ConvenioNumber
			}
		}

		fmt.Print("Deseja atualizar o Sequencial da Remessa? (s/n): ")
		var updateRemessaSequential string
		fmt.Scanln(&updateRemessaSequential)
		if updateRemessaSequential == "s" || updateRemessaSequential == "S" {
			fmt.Print("Sequencial da Remessa (opcional): ")
			remessaSequentialStr, _ := reader.ReadString('\n')
			remessaSequentialStr = strings.TrimSpace(remessaSequentialStr)
			if remessaSequentialStr != "" {
				remessaSequential, err := strconv.Atoi(remessaSequentialStr)
				if err != nil {
					log.Fatalf("Erro ao converter Sequencial da Remessa para inteiro: %v", err)
				}
				updateData["remessaSequential"] = remessaSequential
			}
		}

		urlAtualiza := urlConta + "/" + aHash
		atualizarConta(urlAtualiza, cnpjsh, tokensh, payerCpfCnpj, atualizaConta)

	default:
		fmt.Print("Seção inválida\n")
		rotaConta(urlConta)
	}
}
