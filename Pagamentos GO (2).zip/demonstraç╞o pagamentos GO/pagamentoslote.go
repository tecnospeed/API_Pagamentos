package main

import (
	"bytes"
	"encoding/json"
	"fmt"
	"io/ioutil"
	"log"
	"net/http"
)

func salariosLote(url, cnpjsh, tokensh, payercpfcnpj string, salarios []Paycheck) {
	client := &http.Client{}

	// Serializar o slice de pagamentos para JSON
	data, err := json.Marshal(salarios)
	if err != nil {
		log.Fatalf("Erro ao serializar os pagamentos: %v", err)
	}

	req, err := http.NewRequest("POST", url, bytes.NewBuffer(data))
	if err != nil {
		log.Fatalf("Erro ao criar a requisição POST: %v", err)
	}

	req.Header.Add("Content-Type", "application/json")
	req.Header.Add("cnpjSh", cnpjsh)
	req.Header.Add("payercpfcnpj", payercpfcnpj)
	req.Header.Add("tokenSh", tokensh)

	resp, err := client.Do(req)
	if err != nil {
		log.Fatalf("Erro ao realizar a requisição POST: %v", err)
	}
	defer resp.Body.Close()

	// Processar a resposta
	if resp.StatusCode == http.StatusOK {
		fmt.Println("Pagamento em lote enviado com sucesso.")
	} else {
		fmt.Printf("Falha ao enviar o pagamento em lote. Status: %s\n", resp.Status)
	}
}

func batchLote(url, cnpjsh, tokensh, payercpfcnpj string, batch []Payment) {
	client := &http.Client{}

	// Serializar o slice de pagamentos para JSON
	data, err := json.Marshal(batch)
	if err != nil {
		log.Fatalf("Erro ao serializar os pagamentos: %v", err)
	}

	req, err := http.NewRequest("POST", url, bytes.NewBuffer(data))
	if err != nil {
		log.Fatalf("Erro ao criar a requisição POST: %v", err)
	}

	req.Header.Add("Content-Type", "application/json")
	req.Header.Add("cnpjSh", cnpjsh)
	req.Header.Add("payercpfcnpj", payercpfcnpj)
	req.Header.Add("tokenSh", tokensh)

	resp, err := client.Do(req)
	if err != nil {
		log.Fatalf("Erro ao realizar a requisição POST: %v", err)
	}
	defer resp.Body.Close()

	// Processar a resposta
	if resp.StatusCode == http.StatusOK {
		fmt.Println("Transferência de pagamento em lote enviada com sucesso.")
	} else {
		fmt.Printf("Falha ao enviar a transferência de pagamento em lote. Status: %s\n", resp.Status)
	}
}

func consultaPagamentoLote(url, cnpjsh, tokensh, payercpfcnpj, batchId string) {
	client := &http.Client{}

	// Formata a URL substituindo {batchId} pelo valor fornecido
	urlWithBatchId := fmt.Sprintf("%s/payment/batch/%s", url, batchId)

	req, err := http.NewRequest("GET", urlWithBatchId, nil)
	if err != nil {
		log.Fatalf("Erro ao criar a requisição GET: %v", err)
	}

	req.Header.Add("cnpjSh", cnpjsh)
	req.Header.Add("payercpfcnpj", payercpfcnpj)
	req.Header.Add("tokenSh", tokensh)

	resp, err := client.Do(req)
	if err != nil {
		log.Fatalf("Erro ao realizar a requisição GET: %v", err)
	}
	defer resp.Body.Close()

	// Lê o corpo da resposta
	body, err := ioutil.ReadAll(resp.Body)
	if err != nil {
		log.Fatalf("Erro ao ler a resposta: %v", err)
	}

	if resp.StatusCode == http.StatusOK {
		fmt.Println("Status do Lote:")
		fmt.Println(string(body))
	} else {
		fmt.Printf("Falha ao consultar o status do lote. Status: %s\n", resp.Status)
		fmt.Println(string(body))
	}
}

func rotaPagamentoLote(urlPagamentoLote string) {
	var rota int
	fmt.Printf(
		"\n" +
			"1. Salários em lote\n" +
			"2. Transferência Bancária em lote\n" +
			"3. Consultar Pagamentos em Lote\n" +
			"4. SAIR\n" +
			"--------------------------\n\n",
	)

	fmt.Print("Digite o número correspondente à rota que deseja utilizar: ")
	fmt.Scanln(&rota)

	var cnpjsh, tokensh, payercpfcnpj string

	fmt.Print("CNPJ da Software House: ")
	fmt.Scanln(&cnpjsh)
	fmt.Print("Token da Software House: ")
	fmt.Scanln(&tokensh)
	fmt.Print("CNPJ ou CPF do pagador: ")
	fmt.Scanln(&payercpfcnpj)

	switch rota {
	case 1:
		var cnpjsh, tokensh, payercpfcnpj string

		fmt.Print("CNPJ da Software House: ")
		fmt.Scanln(&cnpjsh)
		fmt.Print("Token da Software House: ")
		fmt.Scanln(&tokensh)
		fmt.Print("CNPJ ou CPF do pagador: ")
		fmt.Scanln(&payercpfcnpj)
		var payments []Payment
		for {
			var payment Payment
			fmt.Print("AccountHash (obrigatório): ")
			var accountHash string
			fmt.Scanln(&accountHash)

			fmt.Print("Description: ")
			var description string
			fmt.Scanln(&description)

			fmt.Print("Forma de Pagamento (obrigatório): ")
			var paymentForm string
			fmt.Scanln(&paymentForm)

			fmt.Print("Data do Pagamento (obrigatório): ")
			var paymentDate string
			fmt.Scanln(&paymentDate)

			fmt.Print("Valor do Pagamento (obrigatório): ")
			var amount float64
			fmt.Scanln(&amount)

			fmt.Print("Valor do Abatimento: ")
			var rebateAmount float64
			fmt.Scanln(&rebateAmount)

			fmt.Print("Valor de Juros: ")
			var interestAmount float64
			fmt.Scanln(&interestAmount)

			fmt.Print("Valor de Desconto: ")
			var discountAmount float64
			fmt.Scanln(&discountAmount)

			fmt.Print("Valor da Campo: ")
			var fineAmount float64
			fmt.Scanln(&fineAmount)

			fmt.Print("Código de Movimento: ")
			var movimentCode string
			fmt.Scanln(&movimentCode)

			fmt.Print("Código Complementar: ")
			var complementaryCode string
			fmt.Scanln(&complementaryCode)

			fmt.Print("Tipo de Transmissão (apenas CAIXA): ")
			var transmissionParam int
			fmt.Scanln(&transmissionParam)

			fmt.Print("Nome do Beneficiário: ")
			fmt.Scanln(&payment.Beneficiary.Name)
			fmt.Print("CPF/CNPJ do Beneficiário: ")
			fmt.Scanln(&payment.Beneficiary.CpfCnpj)
			fmt.Print("Código do Banco: ")
			fmt.Scanln(&payment.Beneficiary.BankCode)
			fmt.Print("Agência: ")
			fmt.Scanln(&payment.Beneficiary.Agency)
			fmt.Print("Dígito da Agência: ")
			fmt.Scanln(&payment.Beneficiary.AgencyDigit)
			fmt.Print("Número da Conta: ")
			fmt.Scanln(&payment.Beneficiary.AccountNumber)
			fmt.Print("Dígito da Conta: ")
			fmt.Scanln(&payment.Beneficiary.AccountNumberDigit)
			fmt.Print("DAC da Conta: ")
			fmt.Scanln(&payment.Beneficiary.AccountDac)
			fmt.Print("Rua: ")
			fmt.Scanln(&payment.Beneficiary.Street)
			fmt.Print("Bairro: ")
			fmt.Scanln(&payment.Beneficiary.Neighborhood)
			fmt.Print("Número do Endereço: ")
			fmt.Scanln(&payment.Beneficiary.AddressNumber)
			fmt.Print("Complemento do Endereço: ")
			fmt.Scanln(&payment.Beneficiary.AddressComplement)
			fmt.Print("Cidade: ")
			fmt.Scanln(&payment.Beneficiary.City)
			fmt.Print("Estado: ")
			fmt.Scanln(&payment.Beneficiary.State)
			fmt.Print("CEP: ")
			fmt.Scanln(&payment.Beneficiary.Zipcode)
			fmt.Print("Tipo de Conta: ")
			fmt.Scanln(&payment.Beneficiary.AccountType)
			fmt.Print("Opções de Transferência: ")
			fmt.Scanln(&payment.Beneficiary.TransferOptions)

			var tag string
			fmt.Print("separadas por vírgula): ")
			fmt.Scanln(&tag)
			payment.Tags = append(payment.Tags, tag)

			payments = append(payments, payment)

			fmt.Print("Deseja adicionar mais um pagamento? (s/n): ")
			var addMore string
			fmt.Scanln(&addMore)
			if addMore != "s" {
				break
			}
		}
		batchLote(urlPagamentoLote+"transfer/batch", cnpjsh, payercpfcnpj, tokensh, payments)
	case 2:
		var paychecks []Paycheck

		var cnpjsh, tokensh, payercpfcnpj string

		fmt.Print("CNPJ da Software House: ")
		fmt.Scanln(&cnpjsh)
		fmt.Print("Token da Software House: ")
		fmt.Scanln(&tokensh)
		fmt.Print("CNPJ ou CPF do pagador: ")
		fmt.Scanln(&payercpfcnpj)
		for {
			var paycheck Paycheck
			fmt.Print("Hash da Conta: ")
			fmt.Scanln(&paycheck.AccountHash)
			fmt.Print("Data de Pagamento (YYYY-MM-DD): ")
			fmt.Scanln(&paycheck.PaymentDate)
			fmt.Print("Forma de Pagamento: ")
			fmt.Scanln(&paycheck.PaymentForm)
			fmt.Print("Valor: ")
			fmt.Scanln(&paycheck.Amount)
			fmt.Print("Valor do Juros: ")
			fmt.Scanln(&paycheck.InterestAmount)
			fmt.Print("Valor do Desconto: ")
			fmt.Scanln(&paycheck.DiscountAmount)
			fmt.Print("Valor da Multa: ")
			fmt.Scanln(&paycheck.FineAmount)

			fmt.Print("Nome do Beneficiário: ")
			fmt.Scanln(&paycheck.Beneficiary.Name)
			fmt.Print("CPF/CNPJ do Beneficiário: ")
			fmt.Scanln(&paycheck.Beneficiary.CpfCnpj)
			fmt.Print("Código do Banco: ")
			fmt.Scanln(&paycheck.Beneficiary.BankCode)
			fmt.Print("Agência: ")
			fmt.Scanln(&paycheck.Beneficiary.Agency)
			fmt.Print("Dígito da Agência: ")
			fmt.Scanln(&paycheck.Beneficiary.AgencyDigit)
			fmt.Print("Número da Conta: ")
			fmt.Scanln(&paycheck.Beneficiary.AccountNumber)
			fmt.Print("Dígito da Conta: ")
			fmt.Scanln(&paycheck.Beneficiary.AccountNumberDigit)
			fmt.Print("DAC da Conta: ")
			fmt.Scanln(&paycheck.Beneficiary.AccountDac)
			fmt.Print("Bairro: ")
			fmt.Scanln(&paycheck.Beneficiary.Neighborhood)
			fmt.Print("Número do Endereço: ")
			fmt.Scanln(&paycheck.Beneficiary.AddressNumber)
			fmt.Print("Complemento do Endereço: ")
			fmt.Scanln(&paycheck.Beneficiary.AddressComplement)
			fmt.Print("Cidade: ")
			fmt.Scanln(&paycheck.Beneficiary.City)
			fmt.Print("Estado: ")
			fmt.Scanln(&paycheck.Beneficiary.State)
			fmt.Print("CEP: ")
			fmt.Scanln(&paycheck.Beneficiary.Zipcode)
			fmt.Print("Tipo de Conta: ")
			fmt.Scanln(&paycheck.Beneficiary.AccountType)
			fmt.Print("Opções de Transferência: ")
			fmt.Scanln(&paycheck.Beneficiary.TransferOptions)

			var tag string
			fmt.Print("Tags (separadas por vírgula): ")
			fmt.Scanln(&tag)
			paycheck.Tags = append(paycheck.Tags, tag)

			paychecks = append(paychecks, paycheck)

			fmt.Print("Deseja adicionar mais um pagamento? (s/n): ")
			var addMore string
			fmt.Scanln(&addMore)
			if addMore != "s" {
				break
			}
		}

		salariosLote(urlPagamentoLote+"paycheck/batch", cnpjsh, tokensh, payercpfcnpj, paychecks)
	case 3:
		var batchId string
		var cnpjsh, tokensh, payercpfcnpj string

		fmt.Print("CNPJ da Software House: ")
		fmt.Scanln(&cnpjsh)
		fmt.Print("Token da Software House: ")
		fmt.Scanln(&tokensh)
		fmt.Print("CNPJ ou CPF do pagador: ")
		fmt.Scanln(&payercpfcnpj)

		fmt.Print("Digite o batchId: ")
		fmt.Scanln(&batchId)

		consultaPagamentoLote(urlPagamentoLote, cnpjsh, tokensh, payercpfcnpj, batchId)
	case 4:
		selecionaAmbiente()
	default:
		fmt.Print("Rota Inválida.")
		rotaPagamentoLote(urlPagamentoLote)
	}

}
