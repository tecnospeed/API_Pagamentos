package main

import (
	"fmt"
	"io/ioutil"
	"log"
	"net/http"
	"strconv"
)

func consultaBilhetagem(url, cnpjsh, tokensh, dateStart, dateEnd string, page, limit int) {
	client := &http.Client{}

	req, err := http.NewRequest("GET", url, nil)
	if err != nil {
		log.Fatalf("Erro ao criar a requisição GET: %v", err)
	}

	req.Header.Add("cnpjsh", cnpjsh)
	req.Header.Add("tokensh", tokensh)

	// Adiciona os cabeçalhos opcionais somente se não estiverem vazios
	if dateStart != "" {
		req.Header.Add("dateStart", dateStart)
	}
	if dateEnd != "" {
		req.Header.Add("dateEnd", dateEnd)
	}
	if page > 0 {
		req.Header.Add("page", strconv.Itoa(page))
	}
	if limit > 0 {
		req.Header.Add("limit", strconv.Itoa(limit))
	}

	resp, err := client.Do(req)
	if err != nil {
		log.Fatalf("Erro ao realizar a requisição GET: %v", err)
	}

	defer resp.Body.Close()

	body, err := ioutil.ReadAll(resp.Body)
	if err != nil {
		log.Fatalf("Erro ao ler a resposta da requisição GET: %v", err)
	}

	fmt.Println("Resposta GET: ", string(body))
}

func rotaBilhetagem(urlBilhetagem string) {
	var rota int
	fmt.Printf(
		"\n" +
			"1. Consultar Bilhetagem\n" +
			"2. SAIR\n" +
			"--------------------------\n\n",
	)

	fmt.Print("Selecione o número correspondente à sua opção: ")
	fmt.Scanln(&rota)

	switch rota {
	case 1:
		var cnpjsh, tokensh, dateStart, dateEnd string
		var page, limit int

		fmt.Print("CNPJ da Software House: ")
		fmt.Scanln(&cnpjsh)
		fmt.Print("Token da Software House: ")
		fmt.Scanln(&tokensh)
		fmt.Print("Data Inicial (deixe vazio se não desejar usar): ")
		fmt.Scanln(&dateStart)
		fmt.Print("Data Final (deixe vazio se não desejar usar): ")
		fmt.Scanln(&dateEnd)
		fmt.Print("Página (deixe vazio ou 0 se não desejar usar): ")
		fmt.Scanln(&page)
		fmt.Print("Limite de dados (deixe vazio ou 0 se não desejar usar): ")
		fmt.Scanln(&limit)

		consultaBilhetagem(urlBilhetagem, cnpjsh, tokensh, dateStart, dateEnd, page, limit)
	case 2:
		selecionaAmbiente()
	default:
		fmt.Print("Rota Inválida.")
		rotaBilhetagem(urlBilhetagem)
	}
}
