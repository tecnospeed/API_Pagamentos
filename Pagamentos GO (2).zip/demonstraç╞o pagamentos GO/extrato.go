package main

import (
	"bytes"
	"fmt"
	"io"
	"log"
	"mime/multipart"
	"net/http"
	"os"
)

func enviaExtrato(url, cnpjsh, tokensh, payercpfcnpj, caminhoArquivo string) {
	client := &http.Client{}

	// Cria um buffer para armazenar os dados do formulário
	var body bytes.Buffer
	writer := multipart.NewWriter(&body)

	// Adiciona o arquivo ao formulário
	file, err := os.Open(caminhoArquivo)
	if err != nil {
		log.Fatalf("Erro ao abrir o arquivo: %v", err)
	}
	defer file.Close()

	part, err := writer.CreateFormFile("file", caminhoArquivo)
	if err != nil {
		log.Fatalf("Erro ao criar o campo de arquivo: %v", err)
	}

	_, err = io.Copy(part, file)
	if err != nil {
		log.Fatalf("Erro ao copiar o arquivo para o buffer: %v", err)
	}

	writer.Close()

	req, err := http.NewRequest("POST", url, &body)
	if err != nil {
		log.Fatalf("Erro ao criar a requisição POST: %v", err)
	}

	req.Header.Add("Content-Type", writer.FormDataContentType())
	req.Header.Add("cnpjSh", cnpjsh)
	req.Header.Add("payercpfcnpj", payercpfcnpj)
	req.Header.Add("tokenSh", tokensh)

	resp, err := client.Do(req)
	if err != nil {
		log.Fatalf("Erro ao realizar a requisição POST: %v", err)
	}

	defer resp.Body.Close()

	respBody, err := io.ReadAll(resp.Body)
	if err != nil {
		log.Fatalf("Erro ao ler a resposta da requisição POST: %v", err)
	}

	fmt.Println("Resposta POST: ", string(respBody))
}

func consultaExtrato(url, cnpjsh, payercpfcnpj, tokensh string) {
	client := &http.Client{}

	req, err := http.NewRequest("GET", url, nil)
	if err != nil {
		log.Fatalf("Erro ao criar a requisição GET: %v", err)
	}

	req.Header.Add("cnpjSh", cnpjsh)
	req.Header.Add("payercpfcnpj", payercpfcnpj)
	req.Header.Add("tokenSh", tokensh)

	resp, err := client.Do(req)
	if err != nil {
		log.Fatalf("Erro ao realizar a requisição GET: %v", err)
	}

	defer resp.Body.Close()

	body, err := io.ReadAll(resp.Body)
	if err != nil {
		log.Fatalf("Erro ao ler a resposta da requisição GET: %v", err)
	}

	fmt.Println("Resposta GET: ", string(body))
}

func consultaExtratoPorPeriodo(url, cnpjsh, payercpfcnpj, tokensh, dateStart, dateEnd string) {
	client := &http.Client{}

	req, err := http.NewRequest("GET", fmt.Sprintf("%s?dateStart=%s&dateEnd=%s", url, dateStart, dateEnd), nil)
	if err != nil {
		log.Fatalf("Erro ao criar a requisição GET: %v", err)
	}

	req.Header.Add("cnpjSh", cnpjsh)
	req.Header.Add("payercpfcnpj", payercpfcnpj)
	req.Header.Add("tokenSh", tokensh)

	resp, err := client.Do(req)
	if err != nil {
		log.Fatalf("Erro ao realizar a requisição GET: %v", err)
	}

	defer resp.Body.Close()

	body, err := io.ReadAll(resp.Body)
	if err != nil {
		log.Fatalf("Erro ao ler a resposta da requisição GET: %v", err)
	}

	fmt.Println("Resposta GET: ", string(body))
}

func baixaArquivoExtrato(url, cnpjsh, payercpfcnpj, tokensh string) {
	client := &http.Client{}

	req, err := http.NewRequest("GET", url, nil)
	if err != nil {
		log.Fatalf("Erro ao criar a requisição GET: %v", err)
	}

	req.Header.Add("cnpjSh", cnpjsh)
	req.Header.Add("payercpfcnpj", payercpfcnpj)
	req.Header.Add("tokenSh", tokensh)

	resp, err := client.Do(req)
	if err != nil {
		log.Fatalf("Erro ao realizar a requisição GET: %v", err)
	}

	defer resp.Body.Close()

	body, err := io.ReadAll(resp.Body)
	if err != nil {
		log.Fatalf("Erro ao ler a resposta da requisição GET: %v", err)
	}

	// Salvando o arquivo
	file, err := os.Create("extrato_baixado.ret")
	if err != nil {
		log.Fatalf("Erro ao criar o arquivo: %v", err)
	}
	defer file.Close()

	file.Write(body)

	fmt.Println("Arquivo de extrato baixado com sucesso!")
}

func rotaExtratoBancario(urlExtrato string) {
	var rota int
	fmt.Printf(
		"\n" +
			"1. Enviar Extrato\n" +
			"2. Consultar Extrato\n" +
			"3. Consultar Extrato por Período\n" +
			"4. Baixar Extrato\n" +
			"5. SAIR\n" +
			"----------------------------------\n\n",
	)

	fmt.Print("Digite o número correspondente à rota que deseja utilizar: ")
	fmt.Scanln(&rota)

	switch rota {
	case 1:
		var cnpjsh, payercpfcnpj, tokensh, filePath string

		fmt.Print("CNPJ da Software House: ")
		fmt.Scanln(&cnpjsh)
		fmt.Print("CNPJ ou CPF do Pagador: ")
		fmt.Scanln(&payercpfcnpj)
		fmt.Print("Token da Software House: ")
		fmt.Scanln(&tokensh)
		fmt.Print("Caminho do arquivo: ")
		fmt.Scanln(&filePath)

		enviaExtrato(urlExtrato, cnpjsh, payercpfcnpj, tokensh, filePath)

	case 2:
		var cnpjsh, payercpfcnpj, tokensh, id string

		fmt.Print("CNPJ da Software House: ")
		fmt.Scanln(&cnpjsh)
		fmt.Print("CNPJ ou CPF do Pagador: ")
		fmt.Scanln(&payercpfcnpj)
		fmt.Print("Token da Software House: ")
		fmt.Scanln(&tokensh)
		fmt.Print("ID do Extrato: ")
		fmt.Scanln(&id)

		consultaExtrato(urlExtrato+"/"+id, cnpjsh, payercpfcnpj, tokensh)
	case 3:
		var cnpjsh, payercpfcnpj, tokensh, dateStart, dateEnd string

		fmt.Print("CNPJ da Software House: ")
		fmt.Scanln(&cnpjsh)
		fmt.Print("CNPJ ou CPF do Pagador: ")
		fmt.Scanln(&payercpfcnpj)
		fmt.Print("Token da Software House: ")
		fmt.Scanln(&tokensh)
		fmt.Print("Data Inicial (YYYY-MM-DD): ")
		fmt.Scanln(&dateStart)
		fmt.Print("Data Final (YYYY-MM-DD): ")
		fmt.Scanln(&dateEnd)

		consultaExtratoPorPeriodo(urlExtrato, cnpjsh, payercpfcnpj, tokensh, dateStart, dateEnd)
	case 4:
		var cnpjsh, payercpfcnpj, tokensh, uniqueId string

		fmt.Print("CNPJ da Software House: ")
		fmt.Scanln(&cnpjsh)
		fmt.Print("CNPJ ou CPF do Pagador: ")
		fmt.Scanln(&payercpfcnpj)
		fmt.Print("Token da Software House: ")
		fmt.Scanln(&tokensh)
		fmt.Print("Unique ID do Arquivo de Extrato: ")
		fmt.Scanln(&uniqueId)

		baixaArquivoExtrato(urlExtrato+"/"+uniqueId+"/download", cnpjsh, payercpfcnpj, tokensh)
	case 5:
		selecionaAmbiente()
	default:
		fmt.Print("Rota Inválida.")
		rotaExtratoBancario(urlExtrato)
	}
}
