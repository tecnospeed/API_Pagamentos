require 'net/http'
require 'uri'
require 'json'
require 'base64'

########## Pagador ##########

def criaPagador

  uri = URI('https://staging.pagamentobancario.com.br/api/v1/payer')

  puts "Por favor, insira os dados no formato JSON:"
  ARGV.clear
  json_data = gets.chomp

  begin
    data = JSON.parse(json_data)
  rescue JSON::ParserError => e
    puts "Erro ao analisar o JSON: #{e.message}"
    return
  end

  header = {
    'cnpjSh' => '', ##Informar o CNPJ da SH
    'tokenSh' => '' ##Informar o token da SH
    'Content-Type' => 'application/json'
  }

  puts "Json da requisição: #{data}"

  http = Net::HTTP.new(uri.host, uri.port)
  http.use_ssl = true

  request = Net::HTTP::Post.new(uri.request_uri, header)
  request.body = data.to_json

  response = http.request(request)

  puts "Response #{response.code} #{response.message}: #{response.body}"
end 


def listaPagador

  uri = URI.parse("https://staging.pagamentobancario.com.br/api/v1/payer")

  header = {
     'cnpjSh' => '', ##Informar o CNPJ da SH
    'tokenSh' => '' ##Informar o token da SH
    'cnpjPayer' => '', ##Informar o CNPJ do Pagador  
    'Content-Type' => 'application/json'
  }

  http = Net::HTTP.new(uri.host, uri.port)
  http.use_ssl = true

  request = Net::HTTP::Get.new(uri.request_uri, header)

  response = http.request(request)

  puts "Resposta da requisição:", response.body
end 
  

def updatePayer

  uri = URI.parse("https://staging.pagamentobancario.com.br/api/v1/payer")
  
  puts "Por favor, insira os dados no formato JSON:"
  ARGV.clear
  json_data = gets.chomp

  begin
    data = JSON.parse(json_data)
  rescue JSON::ParserError => e
    puts "Erro ao analisar o JSON: #{e.message}"
    return
  end

  header = {
     'cnpjSh' => '', ##Informar o CNPJ da SH
    'tokenSh' => '' ##Informar o token da SH
    'cnpjPayer' => '', ##Informar o CNPJ do Pagador  
    'Content-Type' => 'application/json'
  }

  puts "Json da requisição: #{data}"

  http = Net::HTTP.new(uri.host, uri.port)
  http.use_ssl = true

  request = Net::HTTP::Post.new(uri.request_uri, header)
  request.body = data.to_json

  response = http.request(request)

  puts "Response #{response.code} #{response.message}: #{response.body}"
end  

########## Conta ##########


def criarConta

  uri = URI.parse("https://staging.pagamentobancario.com.br/api/v1/account")

  puts "Por favor, insira os dados no formato JSON:"
  ARGV.clear
  json_data = gets.chomp

  begin
    data = JSON.parse(json_data)
  rescue JSON::ParserError => e
    puts "Erro ao analisar o JSON: #{e.message}"
    return
  end

  header = {
     'cnpjSh' => '', ##Informar o CNPJ da SH
    'tokenSh' => '' ##Informar o token da SH
    'cnpjPayer' => '', ##Informar o CNPJ do Pagador  
    'Content-Type' => 'application/json'
  }

  puts "Json da requisição: #{data}"

  http = Net::HTTP.new(uri.host, uri.port)
  http.use_ssl = true

  request = Net::HTTP::Post.new(uri.request_uri, header)
  request.body = data.to_json

  response = http.request(request)

  puts "Response #{response.code} #{response.message}: #{response.body}"
end 


def listaConta
 
  uri = URI.parse("https://staging.pagamentobancario.com.br/api/v1/account")

  header = {
     'cnpjSh' => '', ##Informar o CNPJ da SH
    'tokenSh' => '' ##Informar o token da SH
    'cnpjPayer' => '', ##Informar o CNPJ do Pagador  
    'Content-Type' => 'application/json'
  }

  http = Net::HTTP.new(uri.host, uri.port)
  http.use_ssl = true

  request = Net::HTTP::Get.new(uri.request_uri, header)

  response = http.request(request)

  puts "Resposta da requisição:", response.body
end 


def updateConta

  puts "Por favor, informe o accountHash:"
  ARGV.clear
  accountHash = gets.chomp

  uri = URI.parse("https://staging.pagamentobancario.com.br/api/v1/account/#{accountHash}")

  puts "Por favor, insira os dados no formato JSON:"
  ARGV.clear
  json_data = gets.chomp

  begin
    data = JSON.parse(json_data)
  rescue JSON::ParserError => e
    puts "Erro ao analisar o JSON: #{e.message}"
    return
  end

  header = {
     'cnpjSh' => '', ##Informar o CNPJ da SH
    'tokenSh' => '' ##Informar o token da SH
    'cnpjPayer' => '', ##Informar o CNPJ do Pagador  
    'Content-Type' => 'application/json'
  }

  puts "Json da requisição: #{data}"

  http = Net::HTTP.new(uri.host, uri.port)
  http.use_ssl = true

  request = Net::HTTP::Post.new(uri.request_uri, header)
  request.body = data.to_json

  response = http.request(request)

  puts "Response #{response.code} #{response.message}: #{response.body}"
end 


def deleteConta
  uri = URI.parse("https://staging.pagamentobancario.com.br/api/v1/account")

  puts "Por favor, insira os dados no formato JSON:"
  ARGV.clear
  json_data = gets.chomp

  begin
    data = JSON.parse(json_data)
  rescue JSON::ParserError => e
    puts "Erro ao analisar o JSON: #{e.message}"
    return
  end

  header = {
     'cnpjSh' => '', ##Informar o CNPJ da SH
    'tokenSh' => '' ##Informar o token da SH
    'cnpjPayer' => '', ##Informar o CNPJ do Pagador  
    'Content-Type' => 'application/json'
  }

  puts "Json da requisição: #{data}"

  http = Net::HTTP.new(uri.host, uri.port)
  http.use_ssl = true

  request = Net::HTTP::Delete.new(uri.request_uri, header)
  request.body = data.to_json

  response = http.request(request)

  puts "Response #{response.code} #{response.message}: #{response.body}"
end 


########## Certificate ##########

def uploadCertificate
  
  ARGV.clear
  puts "Insira o caminho para o arquivo:"
  ARGV.clear
  file_path = STDIN.gets.chomp

  puts "Insira a senha:"
  ARGV.clear
  password = STDIN.gets.chomp

  puts "Insira a extensão:"
  ARGV.clear
  extension = STDIN.gets.chomp

  puts "Insira o accountHash:"
  ARGV.clear
  accountHash = STDIN.gets.chomp

  uri = URI.parse("https://staging.pagamentobancario.com.br/api/v1/account/#{accountHash}/certificate")

  header = {
     'cnpjSh' => '', ##Informar o CNPJ da SH
    'tokenSh' => '' ##Informar o token da SH
    'cnpjPayer' => '', ##Informar o CNPJ do Pagador  
  }

  http = Net::HTTP.new(uri.host, uri.port)
  http.use_ssl = true

  request = Net::HTTP::Post.new(uri.request_uri, header)
  form_data = [
    ['password', password],
    ['extension', extension],
    ['key', File.open(file_path)],
    ['accountId', account_id],
    ['file', File.open(file_path)]
  ]

  request.set_form form_data, 'multipart/form-data'

  response = http.request(request)

  puts "Resposta da requisição:", response.body
end


def listCertificate
  
  puts "Insira o accountHash:"
  ARGV.clear
  accountHash = STDIN.gets.chomp


  uri = URI.parse("https://staging.pagamentobancario.com.br/api/v1/account/#{accountHash}/certificate")

  header = {
     'cnpjSh' => '', ##Informar o CNPJ da SH
    'tokenSh' => '' ##Informar o token da SH
    'cnpjPayer' => '', ##Informar o CNPJ do Pagador  
    'Content-Type' => 'application/json'
  }

  http = Net::HTTP.new(uri.host, uri.port)
  http.use_ssl = true

  request = Net::HTTP::Get.new(uri.request_uri, header)

  response = http.request(request)

  puts "Resposta da requisição:", response.body
end 


def updateCertificate
  ARGV.clear
  puts "Insira o caminho para o arquivo:"
  ARGV.clear
  file_path = STDIN.gets.chomp

  puts "Insira a senha:"
  ARGV.clear
  password = STDIN.gets.chomp

  puts "Insira a extensão:"
  ARGV.clear
  extension = STDIN.gets.chomp

  puts "Insira o accountHash:"
  ARGV.clear
  accountHash = STDIN.gets.chomp

  uri = URI.parse("https://staging.pagamentobancario.com.br/api/v1/account/#{accountHash}/certificate")

  header = {
     'cnpjSh' => '', ##Informar o CNPJ da SH
    'tokenSh' => '' ##Informar o token da SH
    'cnpjPayer' => '', ##Informar o CNPJ do Pagador  
    'Content-Type' => 'application/json'
  }

  http = Net::HTTP.new(uri.host, uri.port)
  http.use_ssl = true

  request = Net::HTTP::Patch.new(uri.request_uri, header)
  form_data = [
    ['password', password],
    ['extension', extension],
    ['key', File.open(file_path)],
    ['accountId', account_id],
    ['file', File.open(file_path)]
  ]

  request.set_form form_data, 'multipart/form-data'

  response = http.request(request)

  puts "Resposta da requisição:", response.body
end 


def deleteCertificate

  puts "Insira o accountHash:"
  ARGV.clear
  accountHash = STDIN.gets.chomp


  uri = URI.parse("https://staging.pagamentobancario.com.br/api/v1/account/#{accountHash}/certificate")

  header = {
     'cnpjSh' => '', ##Informar o CNPJ da SH
    'tokenSh' => '' ##Informar o token da SH
    'cnpjPayer' => '', ##Informar o CNPJ do Pagador  
    'Content-Type' => 'application/json'
  }


  http = Net::HTTP.new(uri.host, uri.port)
  http.use_ssl = true

  request = Net::HTTP::Delete.new(uri.request_uri, header)

  request.set_form form_data, 'application/json'

  response = http.request(request)

  puts "Resposta da requisição:", response.body
end 


########## WebHook ##########

def creatWebhook
  access_token = autenticaCompany

  uri = URI.parse("https://staging.pagamentobancario.com.br/api/v1/notification")
  
  puts "Por favor, insira os dados no formato JSON:"
  ARGV.clear
  json_data = gets.chomp

  begin
    data = JSON.parse(json_data)
  rescue JSON::ParserError => e
    puts "Erro ao analisar o JSON: #{e.message}"
    return
  end

 {
     'cnpjSh' => '', ##Informar o CNPJ da SH
    'tokenSh' => '' ##Informar o token da SH
    'cnpjPayer' => '', ##Informar o CNPJ do Pagador  
    'Content-Type' => 'application/json'
  }

  puts "Json da requisição: #{data}"

  http = Net::HTTP.new(uri.host, uri.port)
  http.use_ssl = true

  request = Net::HTTP::Post.new(uri.request_uri, header)
  request.body = data.to_json

  response = http.request(request)

  puts "Response #{response.code} #{response.message}: #{response.body}"
end 


def listWebhook
  access_token = autenticaCompany

  uri = URI.parse("https://staging.pagamentobancario.com.br/api/v1/notification")

 {
     'cnpjSh' => '', ##Informar o CNPJ da SH
    'tokenSh' => '' ##Informar o token da SH
    'cnpjPayer' => '', ##Informar o CNPJ do Pagador  
    'Content-Type' => 'application/json'
  }

  http = Net::HTTP.new(uri.host, uri.port)
  http.use_ssl = true

  request = Net::HTTP::Get.new(uri.request_uri, header)

  response = http.request(request)

  puts "Resposta da requisição:", response.body
end 


def updateWebhook
  access_token = autenticaCompany

  uri = URI.parse("https://staging.pagamentobancario.com.br/api/v1/notification")

  puts "Por favor, insira os dados no formato JSON:"
  ARGV.clear
  json_data = gets.chomp

  begin
    data = JSON.parse(json_data)
  rescue JSON::ParserError => e
    puts "Erro ao analisar o JSON: #{e.message}"
    return
  end

 {
     'cnpjSh' => '', ##Informar o CNPJ da SH
    'tokenSh' => '' ##Informar o token da SH
    'cnpjPayer' => '', ##Informar o CNPJ do Pagador  
    'Content-Type' => 'application/json'
  }

  puts "Json da requisição: #{data}"

  http = Net::HTTP.new(uri.host, uri.port)
  http.use_ssl = true

  request = Net::HTTP::Patch.new(uri.request_uri, header)
  request.body = data.to_json

  response = http.request(request)

  puts "Response #{response.code} #{response.message}: #{response.body}"
end 


def disableWebhook
  access_token = autenticaCompany

  uri = URI.parse("https://pix.tecnospeed.com.br/api/v1/webhook")

 {
     'cnpjSh' => '', ##Informar o CNPJ da SH
    'tokenSh' => '' ##Informar o token da SH
    'cnpjPayer' => '', ##Informar o CNPJ do Pagador  
    'Content-Type' => 'application/json'
  }

  http = Net::HTTP.new(uri.host, uri.port)
  http.use_ssl = true

  request = Net::HTTP::Delete.new(uri.request_uri, header)

  response = http.request(request)

  puts "Resposta da requisição:", response.body
end 

########## Pagamentos ##########


def pagamentoBillet
  

  uri = URI.parse("https://staging.pagamentobancario.com.br/api/v1/payment/billet")
  
  puts "Por favor, insira os dados no formato JSON:"
  ARGV.clear
  json_data = gets.chomp

  begin
    data = JSON.parse(json_data)
  rescue JSON::ParserError => e
    puts "Erro ao analisar o JSON: #{e.message}"
    return
  end

 {
     'cnpjSh' => '', ##Informar o CNPJ da SH
    'tokenSh' => '' ##Informar o token da SH
    'cnpjPayer' => '', ##Informar o CNPJ do Pagador  
    'Content-Type' => 'application/json'
  }

  puts "Json da requisição: #{data}"

  http = Net::HTTP.new(uri.host, uri.port)
  http.use_ssl = true

  request = Net::HTTP::Post.new(uri.request_uri, header)
  request.body = data.to_json

  response = http.request(request)

  puts "Response #{response.code} #{response.message}: #{response.body}"
end 

def pagamentoTransfer
  

  uri = URI.parse("https://staging.pagamentobancario.com.br/api/v1/payment/transfer")
  
  puts "Por favor, insira os dados no formato JSON:"
  ARGV.clear
  json_data = gets.chomp

  begin
    data = JSON.parse(json_data)
  rescue JSON::ParserError => e
    puts "Erro ao analisar o JSON: #{e.message}"
    return
  end

 {
     'cnpjSh' => '', ##Informar o CNPJ da SH
    'tokenSh' => '' ##Informar o token da SH
    'cnpjPayer' => '', ##Informar o CNPJ do Pagador  
    'Content-Type' => 'application/json'
  }

  puts "Json da requisição: #{data}"

  http = Net::HTTP.new(uri.host, uri.port)
  http.use_ssl = true

  request = Net::HTTP::Post.new(uri.request_uri, header)
  request.body = data.to_json

  response = http.request(request)

  puts "Response #{response.code} #{response.message}: #{response.body}"
end 

def pagamentoSalario
  

  uri = URI.parse("https://staging.pagamentobancario.com.br/api/v1/payment/paycheck")
  
  puts "Por favor, insira os dados no formato JSON:"
  ARGV.clear
  json_data = gets.chomp

  begin
    data = JSON.parse(json_data)
  rescue JSON::ParserError => e
    puts "Erro ao analisar o JSON: #{e.message}"
    return
  end

 {
     'cnpjSh' => '', ##Informar o CNPJ da SH
    'tokenSh' => '' ##Informar o token da SH
    'cnpjPayer' => '', ##Informar o CNPJ do Pagador  
    'Content-Type' => 'application/json'
  }

  puts "Json da requisição: #{data}"

  http = Net::HTTP.new(uri.host, uri.port)
  http.use_ssl = true

  request = Net::HTTP::Post.new(uri.request_uri, header)
  request.body = data.to_json

  response = http.request(request)

  puts "Response #{response.code} #{response.message}: #{response.body}"
end 

def pagamentoGare
  

  uri = URI.parse("https://staging.pagamentobancario.com.br/api/v1/payment/taxes/gare")
  
  puts "Por favor, insira os dados no formato JSON:"
  ARGV.clear
  json_data = gets.chomp

  begin
    data = JSON.parse(json_data)
  rescue JSON::ParserError => e
    puts "Erro ao analisar o JSON: #{e.message}"
    return
  end

 {
     'cnpjSh' => '', ##Informar o CNPJ da SH
    'tokenSh' => '' ##Informar o token da SH
    'cnpjPayer' => '', ##Informar o CNPJ do Pagador  
    'Content-Type' => 'application/json'
  }

  puts "Json da requisição: #{data}"

  http = Net::HTTP.new(uri.host, uri.port)
  http.use_ssl = true

  request = Net::HTTP::Post.new(uri.request_uri, header)
  request.body = data.to_json

  response = http.request(request)

  puts "Response #{response.code} #{response.message}: #{response.body}"
end 

def pagamentoIPVA
  

  uri = URI.parse("https://staging.pagamentobancario.com.br/api/v1/payment/taxes/ipva")
  
  puts "Por favor, insira os dados no formato JSON:"
  ARGV.clear
  json_data = gets.chomp

  begin
    data = JSON.parse(json_data)
  rescue JSON::ParserError => e
    puts "Erro ao analisar o JSON: #{e.message}"
    return
  end

 {
     'cnpjSh' => '', ##Informar o CNPJ da SH
    'tokenSh' => '' ##Informar o token da SH
    'cnpjPayer' => '', ##Informar o CNPJ do Pagador  
    'Content-Type' => 'application/json'
  }

  puts "Json da requisição: #{data}"

  http = Net::HTTP.new(uri.host, uri.port)
  http.use_ssl = true

  request = Net::HTTP::Post.new(uri.request_uri, header)
  request.body = data.to_json

  response = http.request(request)

  puts "Response #{response.code} #{response.message}: #{response.body}"
end 

def pagamentoDPVAT
  

  uri = URI.parse("https://staging.pagamentobancario.com.br/api/v1/payment/taxes/dpvat")
  
  puts "Por favor, insira os dados no formato JSON:"
  ARGV.clear
  json_data = gets.chomp

  begin
    data = JSON.parse(json_data)
  rescue JSON::ParserError => e
    puts "Erro ao analisar o JSON: #{e.message}"
    return
  end

 {
     'cnpjSh' => '', ##Informar o CNPJ da SH
    'tokenSh' => '' ##Informar o token da SH
    'cnpjPayer' => '', ##Informar o CNPJ do Pagador  
    'Content-Type' => 'application/json'
  }

  puts "Json da requisição: #{data}"

  http = Net::HTTP.new(uri.host, uri.port)
  http.use_ssl = true

  request = Net::HTTP::Post.new(uri.request_uri, header)
  request.body = data.to_json

  response = http.request(request)

  puts "Response #{response.code} #{response.message}: #{response.body}"
end 

def pagamentoDARF
  

  uri = URI.parse("https://staging.pagamentobancario.com.br/api/v1/payment/taxes/darf")
  
  puts "Por favor, insira os dados no formato JSON:"
  ARGV.clear
  json_data = gets.chomp

  begin
    data = JSON.parse(json_data)
  rescue JSON::ParserError => e
    puts "Erro ao analisar o JSON: #{e.message}"
    return
  end

 {
     'cnpjSh' => '', ##Informar o CNPJ da SH
    'tokenSh' => '' ##Informar o token da SH
    'cnpjPayer' => '', ##Informar o CNPJ do Pagador  
    'Content-Type' => 'application/json'
  }

  puts "Json da requisição: #{data}"

  http = Net::HTTP.new(uri.host, uri.port)
  http.use_ssl = true

  request = Net::HTTP::Post.new(uri.request_uri, header)
  request.body = data.to_json

  response = http.request(request)

  puts "Response #{response.code} #{response.message}: #{response.body}"
end 

def pagamentoGPS
  

  uri = URI.parse("https://staging.pagamentobancario.com.br/api/v1/payment/taxes/gps")
  
  puts "Por favor, insira os dados no formato JSON:"
  ARGV.clear
  json_data = gets.chomp

  begin
    data = JSON.parse(json_data)
  rescue JSON::ParserError => e
    puts "Erro ao analisar o JSON: #{e.message}"
    return
  end

 {
     'cnpjSh' => '', ##Informar o CNPJ da SH
    'tokenSh' => '' ##Informar o token da SH
    'cnpjPayer' => '', ##Informar o CNPJ do Pagador  
    'Content-Type' => 'application/json'
  }

  puts "Json da requisição: #{data}"

  http = Net::HTTP.new(uri.host, uri.port)
  http.use_ssl = true

  request = Net::HTTP::Post.new(uri.request_uri, header)
  request.body = data.to_json

  response = http.request(request)

  puts "Response #{response.code} #{response.message}: #{response.body}"
end 

def pagamentoFGTS
  

  uri = URI.parse("https://staging.pagamentobancario.com.br/api/v1/payment/taxes/fgts")
  
  puts "Por favor, insira os dados no formato JSON:"
  ARGV.clear
  json_data = gets.chomp

  begin
    data = JSON.parse(json_data)
  rescue JSON::ParserError => e
    puts "Erro ao analisar o JSON: #{e.message}"
    return
  end

 {
     'cnpjSh' => '', ##Informar o CNPJ da SH
    'tokenSh' => '' ##Informar o token da SH
    'cnpjPayer' => '', ##Informar o CNPJ do Pagador  
    'Content-Type' => 'application/json'
  }

  puts "Json da requisição: #{data}"

  http = Net::HTTP.new(uri.host, uri.port)
  http.use_ssl = true

  request = Net::HTTP::Post.new(uri.request_uri, header)
  request.body = data.to_json

  response = http.request(request)

  puts "Response #{response.code} #{response.message}: #{response.body}"
end 

def pagamentoDiversos
  

  uri = URI.parse("https://staging.pagamentobancario.com.br/api/v1/payment/various")
  
  puts "Por favor, insira os dados no formato JSON:"
  ARGV.clear
  json_data = gets.chomp

  begin
    data = JSON.parse(json_data)
  rescue JSON::ParserError => e
    puts "Erro ao analisar o JSON: #{e.message}"
    return
  end

 {
     'cnpjSh' => '', ##Informar o CNPJ da SH
    'tokenSh' => '' ##Informar o token da SH
    'cnpjPayer' => '', ##Informar o CNPJ do Pagador  
    'Content-Type' => 'application/json'
  }

  puts "Json da requisição: #{data}"

  http = Net::HTTP.new(uri.host, uri.port)
  http.use_ssl = true

  request = Net::HTTP::Post.new(uri.request_uri, header)
  request.body = data.to_json

  response = http.request(request)

  puts "Response #{response.code} #{response.message}: #{response.body}"
end 


def consultaPagamento

  puts "Por favor, informe o uniqueID:"
  ARGV.clear
  uniqueID = gets.chomp

  uri = URI.parse("https://staging.pagamentobancario.com.br/api/v1/payment?uniqueId=#{uniqueID}")

 {
     'cnpjSh' => '', ##Informar o CNPJ da SH
    'tokenSh' => '' ##Informar o token da SH
    'cnpjPayer' => '', ##Informar o CNPJ do Pagador  
    'Content-Type' => 'application/json'
  }

  http = Net::HTTP.new(uri.host, uri.port)
  http.use_ssl = true

  request = Net::HTTP::Get.new(uri.request_uri, header)

  response = http.request(request)

  puts "Resposta da requisição:", response.body
end 


def deletePagamento
  uri = URI.parse("https://staging.pagamentobancario.com.br/api/v1/payment")

  puts "Por favor, insira os dados no formato JSON:"
  ARGV.clear
  json_data = gets.chomp

  begin
    data = JSON.parse(json_data)
  rescue JSON::ParserError => e
    puts "Erro ao analisar o JSON: #{e.message}"
    return
  end

  header = {
     'cnpjSh' => '', ##Informar o CNPJ da SH
    'tokenSh' => '' ##Informar o token da SH
    'cnpjPayer' => '', ##Informar o CNPJ do Pagador  
    'Content-Type' => 'application/json'
  }

  puts "Json da requisição: #{data}"

  http = Net::HTTP.new(uri.host, uri.port)
  http.use_ssl = true

  request = Net::HTTP::Delete.new(uri.request_uri, header)
  request.body = data.to_json

  response = http.request(request)

  puts "Response #{response.code} #{response.message}: #{response.body}"
end 


########## Pagamentos em Lote ##########


def pagamentoSalarioLote
  

  uri = URI.parse("https://staging.pagamentobancario.com.br/api/v1/payment/paycheck/batch")
  
  puts "Por favor, insira os dados no formato JSON:"
  ARGV.clear
  json_data = gets.chomp

  begin
    data = JSON.parse(json_data)
  rescue JSON::ParserError => e
    puts "Erro ao analisar o JSON: #{e.message}"
    return
  end

 {
     'cnpjSh' => '', ##Informar o CNPJ da SH
    'tokenSh' => '' ##Informar o token da SH
    'cnpjPayer' => '', ##Informar o CNPJ do Pagador  
    'Content-Type' => 'application/json'
  }

  puts "Json da requisição: #{data}"

  http = Net::HTTP.new(uri.host, uri.port)
  http.use_ssl = true

  request = Net::HTTP::Post.new(uri.request_uri, header)
  request.body = data.to_json

  response = http.request(request)

  puts "Response #{response.code} #{response.message}: #{response.body}"
end 

def pagamentoTransferLote
  

  uri = URI.parse("https://staging.pagamentobancario.com.br/api/v1/payment/transfer/batch")
  
  puts "Por favor, insira os dados no formato JSON:"
  ARGV.clear
  json_data = gets.chomp

  begin
    data = JSON.parse(json_data)
  rescue JSON::ParserError => e
    puts "Erro ao analisar o JSON: #{e.message}"
    return
  end

 {
     'cnpjSh' => '', ##Informar o CNPJ da SH
    'tokenSh' => '' ##Informar o token da SH
    'cnpjPayer' => '', ##Informar o CNPJ do Pagador  
    'Content-Type' => 'application/json'
  }

  puts "Json da requisição: #{data}"

  http = Net::HTTP.new(uri.host, uri.port)
  http.use_ssl = true

  request = Net::HTTP::Post.new(uri.request_uri, header)
  request.body = data.to_json

  response = http.request(request)

  puts "Response #{response.code} #{response.message}: #{response.body}"
end 

def consultaLote

  puts "Por favor, informe o batchId:"
  ARGV.clear
  batchId = gets.chomp

  uri = URI.parse("https://staging.pagamentobancario.com.br/api/v1/payment/batch/#{batchId}")

 {
     'cnpjSh' => '', ##Informar o CNPJ da SH
    'tokenSh' => '' ##Informar o token da SH
    'cnpjPayer' => '', ##Informar o CNPJ do Pagador  
    'Content-Type' => 'application/json'
  }

  http = Net::HTTP.new(uri.host, uri.port)
  http.use_ssl = true

  request = Net::HTTP::Get.new(uri.request_uri, header)

  response = http.request(request)

  puts "Resposta da requisição:", response.body
end 


########## Remessa ##########


def solicitandoRemessa
  

  uri = URI.parse("https://staging.pagamentobancario.com.br/api/v1/remittance")
  
  puts "Por favor, insira os dados no formato JSON:"
  ARGV.clear
  json_data = gets.chomp

  begin
    data = JSON.parse(json_data)
  rescue JSON::ParserError => e
    puts "Erro ao analisar o JSON: #{e.message}"
    return
  end

 {
     'cnpjSh' => '', ##Informar o CNPJ da SH
    'tokenSh' => '' ##Informar o token da SH
    'cnpjPayer' => '', ##Informar o CNPJ do Pagador  
    'Content-Type' => 'application/json'
  }

  puts "Json da requisição: #{data}"

  http = Net::HTTP.new(uri.host, uri.port)
  http.use_ssl = true

  request = Net::HTTP::Post.new(uri.request_uri, header)
  request.body = data.to_json

  response = http.request(request)

  puts "Response #{response.code} #{response.message}: #{response.body}"
end 

def remessaCancelamento
  

  uri = URI.parse("https://staging.pagamentobancario.com.br/api/v1/remittance/cancel")
  
  puts "Por favor, insira os dados no formato JSON:"
  ARGV.clear
  json_data = gets.chomp

  begin
    data = JSON.parse(json_data)
  rescue JSON::ParserError => e
    puts "Erro ao analisar o JSON: #{e.message}"
    return
  end

 {
     'cnpjSh' => '', ##Informar o CNPJ da SH
    'tokenSh' => '' ##Informar o token da SH
    'cnpjPayer' => '', ##Informar o CNPJ do Pagador  
    'Content-Type' => 'application/json'
  }

  puts "Json da requisição: #{data}"

  http = Net::HTTP.new(uri.host, uri.port)
  http.use_ssl = true

  request = Net::HTTP::Post.new(uri.request_uri, header)
  request.body = data.to_json

  response = http.request(request)

  puts "Response #{response.code} #{response.message}: #{response.body}"
end 

def consultaRemessa

  puts "Por favor, informe o uniqueID:"
  ARGV.clear
  uniqueID = gets.chomp

  uri = URI.parse("https://staging.pagamentobancario.com.br/api/v1/payment/batch/#{uniqueID}")

 {
     'cnpjSh' => '', ##Informar o CNPJ da SH
    'tokenSh' => '' ##Informar o token da SH
    'cnpjPayer' => '', ##Informar o CNPJ do Pagador  
    'Content-Type' => 'application/json'
  }

  http = Net::HTTP.new(uri.host, uri.port)
  http.use_ssl = true

  request = Net::HTTP::Get.new(uri.request_uri, header)

  response = http.request(request)

  puts "Resposta da requisição:", response.body

  # Verificando o campo "remittanceType"
  if response_data['remittanceType'] == 'DEFAULT'
    content = response_data['content']
    unless content.nil? || content.empty?
      decoded_content = Base64.decode64(content)
      puts "Conteúdo decodificado (Base64):", decoded_content
      save_decoded_content_to_file(decoded_content, 'Remessa.txt')
    else
      puts "Campo 'content' está vazio ou nulo."
    end
  elsif response_data['remittanceType'] == 'VAN'
    # Se o tipo for "VAN", apenas exibe o JSON como está
    puts "JSON completo:", response_data
  else
    puts "Tipo de remittanceType desconhecido:", response_data['remittanceType']
  end

end
 def save_decoded_content_to_file(content, filename)
   File.open(filename, 'w') do |file| ##w - write
     file.write(content)
   end
   puts "Conteúdo salvo no arquivo: #{filename}"
end 

########## Retorno ########## 

def uploadRetorno
  
  ARGV.clear
  puts "Insira o caminho para o arquivo de retorno:"
  ARGV.clear
  file_path = STDIN.gets.chomp


  uri = URI.parse("https://staging.pagamentobancario.com.br/api/v1/reconciliation")

  header = {
     'cnpjSh' => '', ##Informar o CNPJ da SH
    'tokenSh' => '' ##Informar o token da SH
    'cnpjPayer' => '', ##Informar o CNPJ do Pagador  
  }

  http = Net::HTTP.new(uri.host, uri.port)
  http.use_ssl = true

  request = Net::HTTP::Post.new(uri.request_uri, header)
  form_data = [
    ['file', File.open(file_path)]
  ]

  request.set_form form_data, 'multipart/form-data'

  response = http.request(request)

  puts "Resposta da requisição:", response.body
end

def consultaRetorno
  puts "Por favor, informe o uniqueID:"
  ARGV.clear
  uniqueID = gets.chomp

  uri = URI.parse("https://staging.pagamentobancario.com.br/api/v1/payment?uniqueId=#{uniqueID}")

 {
     'cnpjSh' => '', ##Informar o CNPJ da SH
    'tokenSh' => '' ##Informar o token da SH
    'cnpjPayer' => '', ##Informar o CNPJ do Pagador  
    'Content-Type' => 'application/json'
  }

  http = Net::HTTP.new(uri.host, uri.port)
  http.use_ssl = true

  request = Net::HTTP::Get.new(uri.request_uri, header)

  response = http.request(request)

  puts "Resposta da requisição:", response.body
  end

end

########## EXTRATO ##########

def uploadExtrato
  
  ARGV.clear
  puts "Insira o caminho para o arquivo de retorno:"
  ARGV.clear
  file_path = STDIN.gets.chomp


  uri = URI.parse("https://staging.pagamentobancario.com.br/api/v1/statement/parser")

  header = {
     'cnpjSh' => '', ##Informar o CNPJ da SH
    'tokenSh' => '' ##Informar o token da SH
    'cnpjPayer' => '', ##Informar o CNPJ do Pagador  
  }

  http = Net::HTTP.new(uri.host, uri.port)
  http.use_ssl = true

  request = Net::HTTP::Post.new(uri.request_uri, header)
  form_data = [
    ['file', File.open(file_path)]
  ]

  request.set_form form_data, 'multipart/form-data'

  response = http.request(request)

  puts "Resposta da requisição:", response.body
end

def consultaExtrato

  puts "Por favor, informe o uniqueID do Extrato:"
  ARGV.clear
  uniqueID = gets.chomp

  uri = URI.parse("https://staging.pagamentobancario.com.br/api/v1/statement/parser/#{uniqueID}")

 {
     'cnpjSh' => '', ##Informar o CNPJ da SH
    'tokenSh' => '' ##Informar o token da SH
    'cnpjPayer' => '', ##Informar o CNPJ do Pagador  
    'Content-Type' => 'application/json'
  }

  http = Net::HTTP.new(uri.host, uri.port)
  http.use_ssl = true

  request = Net::HTTP::Get.new(uri.request_uri, header)

  response = http.request(request)

  puts "Resposta da requisição:", response.body
end

def consultaExtratoPeriodo

  puts "Por favor, informe a data de início (YYYY-MM-DD):"
  ARGV.clear
  date_start = gets.chomp

  puts "Por favor, informe a data de término (YYYY-MM-DD):"
  date_end = gets.chomp

  puts "Por favor, informe o accountHash:"
  account_hash = gets.chomp

  uri = URI.parse("https://api.pagamentobancario.com.br/api/v1/statement?dateStart=#{date_start}&dateEnd=#{date_end}&accountHash=#{account_hash}")

 {
     'cnpjSh' => '', ##Informar o CNPJ da SH
    'tokenSh' => '' ##Informar o token da SH
    'cnpjPayer' => '', ##Informar o CNPJ do Pagador  
    'Content-Type' => 'application/json'
  }

  http = Net::HTTP.new(uri.host, uri.port)
  http.use_ssl = true

  request = Net::HTTP::Get.new(uri.request_uri, header)

  response = http.request(request)

  puts "Resposta da requisição:", response.body
end


if ARGV.length > 0
  command = ARGV[0]
  case command
  when 'criaPagador' 
    criaPagador
  when 'listaPagador'
    listaPagador
  when 'updatePayer'
    updatePayer
  when 'criarConta'
    criarConta 
  when 'listaConta'
    listaConta 
  when 'updateConta'
    updateConta 
  when 'deleteConta'
    deleteConta 
  when 'creatWebhook'
     creatWebhook 
  when 'listWebhook'
     listWebhook 
  when 'updateWebhook'
     updateWebhook 
  when 'disableWebhook'
     disableWebhook 
  when 'pagamentoBillet'
    pagamentoBillet 
  when 'pagamentoTransfer'
    pagamentoTransfer 
  when 'pagamentoSalario'
    pagamentoSalario
  when 'pagamentoGare'
    pagamentoGare 
  when 'pagamentoIPVA'
    pagamentoIPVA 
  when 'pagamentoDPVAT'
    pagamentoDPVAT 
  when 'pagamentoDARF'
    pagamentoDARF 
  when 'pagamentoGPS'
    pagamentoGPS 
  when 'pagamentoFGTS'
    pagamentoFGTS 
  when 'pagamentoDiversos'
    pagamentoDiversos 
  when 'consultaPagamento'
    consultaPagamento 
  when 'deletePagamento'
    deletePagamento 
  when 'pagamentoBilletLote'
    pagamentoBilletLote 
  when 'pagamentoSalarioLote'
    pagamentoSalarioLote 
  when 'consultaLote'
    consultaLote 
  when 'solicitandoRemessa'
    solicitandoRemessa 
  when 'remessaCancelamento'
    remessaCancelamento 
  when 'consultaRemessa'##
    consultaRemessa 
  when 'uploadRetorno'
    uploadRetorno 
  when 'consultaRetorno'
    consultaRetorno 
  when 'uploadExtrato'
    uploadExtrato 
  when 'consultaExtrato'
    consultaExtrato 
  when 'consultaExtratoPeriodo'
    consultaExtratoPeriodo 
  else
    puts "Comando desconhecido: #{command}"
  end
else
  puts "Por favor, forneça um comando: "
end

