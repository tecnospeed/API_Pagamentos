package main

import (
	"bytes"
	"encoding/json"
	"fmt"
	"io/ioutil"
	"log"
	"net/http"
)

// Função para criar DDA
func criarDDA(url, cnpjsh, tokensh, payercpfcnpj, accountHash string) {
	client := &http.Client{}

	requestBody, err := json.Marshal(map[string]interface{}{
		"file":       nil,
		"accountHash": accountHash,
	})
	if err != nil {
		log.Fatalf("Erro ao criar o corpo da requisição POST: %v", err)
	}

	req, err := http.NewRequest("POST", url, bytes.NewBuffer(requestBody))
	if err != nil {
		log.Fatalf("Erro ao criar a requisição POST: %v", err)
	}

	req.Header.Add("Content-Type", "application/json")
	req.Header.Add("cnpjSh", cnpjsh)
	req.Header.Add("tokenSh", tokensh)
	req.Header.Add("payercpfcnpj", payercpfcnpj)

	resp, err := client.Do(req)
	if err != nil {
		log.Fatalf("Erro ao realizar a requisição POST: %v", err)
	}
	defer resp.Body.Close()

	body, err := ioutil.ReadAll(resp.Body)
	if err != nil {
		log.Fatalf("Erro ao ler a resposta da requisição POST: %v", err)
	}

	fmt.Println("Resposta POST: ", string(body))
}

// Função para listar DDA por UniqueID
func listarDDAUniqueID(url, cnpjsh, tokensh, payercpfcnpj string) {
	client := &http.Client{}

	req, err := http.NewRequest("GET", url, nil)
	if err != nil {
		log.Fatalf("Erro ao criar a requisição GET: %v", err)
	}

	req.Header.Add("Content-Type", "application/json")
	req.Header.Add("cnpjSh", cnpjsh)
	req.Header.Add("tokenSh", tokensh)
	req.Header.Add("payercpfcnpj", payercpfcnpj)

	resp, err := client.Do(req)
	if err != nil {
		log.Fatalf("Erro ao realizar a requisição GET: %v", err)
	}
	defer resp.Body.Close()

	body, err := ioutil.ReadAll(resp.Body)
	if err != nil {
		log.Fatalf("Erro ao ler a resposta da requisição GET: %v", err)
	}

	fmt.Println("Resposta GET: ", string(body))
}

// Função para listar últimos arquivos recebidos via DDA
func listarUltimosDDA(url, cnpjsh, tokensh, payercpfcnpj string) {
	listarDDAUniqueID(url, cnpjsh, tokensh, payercpfcnpj)
}

// Função para consultar pagamentos processados via DDA
func consultarPagamentosDDA(url, cnpjsh, tokensh, payercpfcnpj string) {
	listarDDAUniqueID(url, cnpjsh, tokensh, payercpfcnpj)
}

func rotaDDA(urlHomologacao, urlProducao string) {
	var ambiente int
	fmt.Println("1. Homologação\n2. Produção")
	fmt.Print("Escolha o ambiente: ")
	fmt.Scanln(&ambiente)

	var baseURL string
	if ambiente == 1 {
		baseURL = urlHomologacao
	} else {
		baseURL = urlProducao
	}

	fmt.Printf(
		"\n1. Criar DDA\n"+
		"2. Listar DDA por UniqueID\n"+
		"3. Listar últimos arquivos DDA\n"+
		"4. Consultar pagamentos processados via DDA\n"+
		"5. Sair\n"+
		"--------------------------\n\n",
	)

	var opcao int
	fmt.Print("Selecione o número correspondente à sua opção: ")
	fmt.Scanln(&opcao)

	switch opcao {
	case 1:
		var cnpjsh, tokensh, payercpfcnpj, accountHash string
		fmt.Print("CNPJ da Software House: ")
		fmt.Scanln(&cnpjsh)
		fmt.Print("Token da Software House: ")
		fmt.Scanln(&tokensh)
		fmt.Print("CNPJ ou CPF do Pagador: ")
		fmt.Scanln(&payercpfcnpj)
		fmt.Print("Account Hash: ")
		fmt.Scanln(&accountHash)
		criarDDA(baseURL, cnpjsh, tokensh, payercpfcnpj, accountHash)

	case 2:
		var cnpjsh, tokensh, payercpfcnpj, uniqueID string
		fmt.Print("CNPJ da Software House: ")
		fmt.Scanln(&cnpjsh)
		fmt.Print("Token da Software House: ")
		fmt.Scanln(&tokensh)
		fmt.Print("CNPJ ou CPF do Pagador: ")
		fmt.Scanln(&payercpfcnpj)
		fmt.Print("UniqueID: ")
		fmt.Scanln(&uniqueID)
		listarDDAUniqueID(baseURL+"/"+uniqueID, cnpjsh, tokensh, payercpfcnpj)

	case 3:
		var cnpjsh, tokensh, payercpfcnpj string
		fmt.Print("CNPJ da Software House: ")
		fmt.Scanln(&cnpjsh)
		fmt.Print("Token da Software House: ")
		fmt.Scanln(&tokensh)
		fmt.Print("CNPJ ou CPF do Pagador: ")
		fmt.Scanln(&payercpfcnpj)
		listarUltimosDDA(baseURL, cnpjsh, tokensh, payercpfcnpj)

	case 4:
		var cnpjsh, tokensh, payercpfcnpj, uniqueID string
		fmt.Print("CNPJ da Software House: ")
		fmt.Scanln(&cnpjsh)
		fmt.Print("Token da Software House: ")
		fmt.Scanln(&tokensh)
		fmt.Print("CNPJ ou CPF do Pagador: ")
		fmt.Scanln(&payercpfcnpj)
		fmt.Print("UniqueID: ")
		fmt.Scanln(&uniqueID)
		consultarPagamentosDDA(baseURL+"/payment/"+uniqueID, cnpjsh, tokensh, payercpfcnpj)

	case 5:
		fmt.Println("Saindo...")
		return

	default:
		fmt.Println("Opção inválida!")
	}

	rotaDDA(urlHomologacao, urlProducao)
}

func main() {
	rotaDDA("https://staging.pagamentobancario.com.br/api/v1/dda", "https://api.pagamentobancario.com.br/api/v1/dda")
}
